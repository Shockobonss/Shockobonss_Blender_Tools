# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Color space math and harmony generation.

Pure functions, no bpy/bgui imports.
"""
import colorsys


def rgb_to_hsv(r, g, b):
    """Convert RGB (0-1) to HSV (0-1)."""
    return colorsys.rgb_to_hsv(r, g, b)


def hsv_to_rgb(h, s, v):
    """Convert HSV (0-1) to RGB (0-1)."""
    return colorsys.hsv_to_rgb(h, s, v)


def blend_colors(c1, c2, t):
    """Linearly blend two RGBA tuples by factor t (0=c1, 1=c2)."""
    return tuple(c1[i] + (c2[i] - c1[i]) * t for i in range(4))
