# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Core logic layer � pure Python, no bpy/bgui imports.

All functions are pure: input ? output, no side effects.
Designed to be compilable to .pyd via Cython.
"""
from . import data, palette, color, effects

__all__ = ['data', 'palette', 'color', 'effects']
