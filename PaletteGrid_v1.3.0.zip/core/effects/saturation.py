# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Saturation adjustment � shifts saturation of an RGB color.

Pure Python, no bpy/bgui imports.
"""
import colorsys


def apply(r, g, b, value):
    """Adjust saturation by *value* (-1 to 1).

    value=0 ? no change, value=1 ? full saturation, value=-1 ? grayscale.
    Returns (r, g, b) clamped to [0, 1].
    """
    h, s, v_ = colorsys.rgb_to_hsv(r, g, b)
    s = max(0.0, min(1.0, s + value))
    r2, g2, b2 = colorsys.hsv_to_rgb(h, s, v_)
    return (r2, g2, b2)
