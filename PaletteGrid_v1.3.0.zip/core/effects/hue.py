# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Hue shift � rotates the hue of an RGB color.

Pure Python, no bpy/bgui imports.
"""
import colorsys


def apply(r, g, b, value):
    """Shift hue by *value* (-1 to 1, wrapping).

    value=0 ? no change, value=0.5 ? shift 180�, value=-0.5 ? shift -180�.
    Returns (r, g, b) clamped to [0, 1].
    """
    h, s, v_ = colorsys.rgb_to_hsv(r, g, b)
    h = (h + value) % 1.0
    r2, g2, b2 = colorsys.hsv_to_rgb(h, s, v_)
    return (r2, g2, b2)
