# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Contrast adjustment � shifts RGB channels toward or away from mid-gray.

Pure Python, no bpy/bgui imports.
"""


def apply(r, g, b, value):
    """Adjust contrast by *value* (-1 to 1).

    value=0 ? no change. value>0 ? more contrast. value<0 ? less contrast.
    Uses simple linear contrast around 0.5 midpoint.
    Returns (r, g, b) clamped to [0, 1].
    """
    # factor maps [-1,1] to [0,2]: at 0 ? factor=1 (no change)
    factor = 1.0 + value
    return (
        max(0.0, min(1.0, 0.5 + (r - 0.5) * factor)),
        max(0.0, min(1.0, 0.5 + (g - 0.5) * factor)),
        max(0.0, min(1.0, 0.5 + (b - 0.5) * factor)),
    )
