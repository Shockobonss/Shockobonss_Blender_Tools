# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Gamma correction � applies power-curve adjustment to RGB channels.

Pure Python, no bpy/bgui imports.
"""


def apply(r, g, b, value):
    """Apply gamma correction.

    value=1.0 ? no change. value<1 ? brighter, value>1 ? darker.
    Returns (r, g, b) clamped to [0, 1].
    """
    if value <= 0:
        return (r, g, b)
    inv = 1.0 / value
    return (
        max(0.0, min(1.0, r ** inv)),
        max(0.0, min(1.0, g ** inv)),
        max(0.0, min(1.0, b ** inv)),
    )
