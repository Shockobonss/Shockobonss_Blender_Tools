# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Non-destructive effects pipeline for gradient strips.

Each effect is a module with an ``apply(r, g, b, value) -> (r, g, b)`` function.
Effects are applied in EFFECT_ORDER when rendering textures / previews.
Adding a new effect: create a module, register it in EFFECT_ORDER + EFFECT_DEFAULTS.

Pure Python � no bpy/bgui imports.
"""

from . import saturation, gamma, contrast, hue

# Ordered list of (key, apply_fn, default_value).
# Pipeline runs in this order.  Default value = "no change".
EFFECT_ORDER = [
    ("hue",        hue.apply,        0.0),
    ("saturation", saturation.apply, 0.0),
    ("gamma",      gamma.apply,      1.0),
    ("contrast",   contrast.apply,   0.0),
]

# Quick lookup: key ? default value
EFFECT_DEFAULTS = {key: default for key, _, default in EFFECT_ORDER}


def apply_pipeline(r, g, b, effects: dict):
    """Apply all registered effects to an (r, g, b) color.

    *effects* is a sparse dict � only keys that differ from default need
    to be present.  Missing keys are skipped (no-op).

    Returns (r, g, b) with effects applied.
    """
    for key, fn, default in EFFECT_ORDER:
        val = effects.get(key)
        if val is not None and val != default:
            r, g, b = fn(r, g, b, val)
    return (r, g, b)


def apply_pipeline_rgba(color: tuple, effects: dict) -> tuple:
    """Convenience: apply pipeline to an (r, g, b, a) tuple, preserving alpha."""
    if not effects:
        return color
    r, g, b = apply_pipeline(color[0], color[1], color[2], effects)
    a = color[3] if len(color) > 3 else 1.0
    return (r, g, b, a)
