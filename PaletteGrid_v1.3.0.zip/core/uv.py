# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""UV snapping algorithms � pure math, no bpy.

All functions operate on plain Python data (tuples, lists).
The app/ layer extracts bmesh data, calls these functions, and writes back.
"""


def cell_uv_bounds(cols, rows, index, tex_w=0, tex_h=0):
    """Return (u_min, v_min, u_max, v_max) for a grid cell in UV space.

    When *tex_w*/*tex_h* are provided, pixel-aligned bounds are computed
    to match the round()-based cell edges used by texture generation.
    UV origin is bottom-left; rows count top-to-bottom (row 0 = top).
    """
    col = index % cols
    row = index // cols

    if tex_w > 0 and tex_h > 0:
        # Match the round() logic in app/texture._fill_pixels
        cx0 = round(col * tex_w / cols)
        cx1 = round((col + 1) * tex_w / cols)
        ry0 = round(row * tex_h / rows)
        ry1 = round((row + 1) * tex_h / rows)
        u_min = cx0 / tex_w
        u_max = cx1 / tex_w
        v_max = 1.0 - ry0 / tex_h
        v_min = 1.0 - ry1 / tex_h
    else:
        u_min = col / cols
        u_max = (col + 1) / cols
        v_max = 1.0 - row / rows
        v_min = 1.0 - (row + 1) / rows
    return u_min, v_min, u_max, v_max


def compute_snap_transform(src_bounds, dst_bounds, mode, margin=0.01):
    """Compute scale + translation to remap UVs from *src_bounds* to *dst_bounds*.

    Parameters
    ----------
    src_bounds : (u_min, v_min, u_max, v_max)
        Current bounding box of selected UVs.
    dst_bounds : (u_min, v_min, u_max, v_max)
        Target strip cell rect.
    mode : str
        ``'FILL'`` � non-uniform stretch to exactly fill target.
        ``'CONTAIN'`` � uniform scale fitting entirely inside target.
    margin : float
        Fraction of cell size to inset on each side (prevents bleed).

    Returns
    -------
    (sx, sy, cx_src, cy_src, cx_dst, cy_dst)
        Scale factors and center coordinates for the remap.
    """
    su0, sv0, su1, sv1 = src_bounds
    tu0, tv0, tu1, tv1 = dst_bounds

    # Inset to prevent bleed between adjacent strips
    tw_full, th_full = tu1 - tu0, tv1 - tv0
    tu0 += tw_full * margin
    tv0 += th_full * margin
    tu1 -= tw_full * margin
    tv1 -= th_full * margin

    sw = su1 - su0 or 1e-8
    sh = sv1 - sv0 or 1e-8
    tw = tu1 - tu0
    th = tv1 - tv0

    if mode == 'FILL':
        sx, sy = tw / sw, th / sh
    else:  # CONTAIN
        s = min(tw / sw, th / sh)
        sx, sy = s, s

    cx_src = (su0 + su1) / 2
    cy_src = (sv0 + sv1) / 2
    cx_dst = (tu0 + tu1) / 2
    cy_dst = (tv0 + tv1) / 2

    return sx, sy, cx_src, cy_src, cx_dst, cy_dst


def remap_uvs(uv_coords, transform):
    """Apply a snap transform to a list of UV coordinates.

    Parameters
    ----------
    uv_coords : list of (u, v)
    transform : (sx, sy, cx_src, cy_src, cx_dst, cy_dst)

    Returns
    -------
    list of (u, v) � new positions.
    """
    sx, sy, cx_src, cy_src, cx_dst, cy_dst = transform
    return [
        ((u - cx_src) * sx + cx_dst, (v - cy_src) * sy + cy_dst)
        for u, v in uv_coords
    ]


def compute_radial_snap(distances, dst_bounds, direction, margin=0.01,
                        invert=False):
    """Map sorted distances to UV coords along the strip's gradient axis.

    Parameters
    ----------
    distances : list of float
        3D distance from each vertex to a reference point (e.g. cursor).
    dst_bounds : (u_min, v_min, u_max, v_max)
        Target strip cell rect.
    direction : str
        ``'Vertical'`` or ``'Horizontal'`` � the gradient axis.
    margin : float
        Fraction of cell size to inset on each side (prevents bleed).
    invert : bool
        If True, flip the gradient direction (t becomes 1 - t).

    Returns
    -------
    list of (u, v) � one per input distance.
    """
    if not distances:
        return []

    u_min, v_min, u_max, v_max = dst_bounds

    # Inset to prevent bleed between adjacent strips
    w, h = u_max - u_min, v_max - v_min
    u_min += w * margin
    v_min += h * margin
    u_max -= w * margin
    v_max -= h * margin
    u_mid = (u_min + u_max) / 2
    v_mid = (v_min + v_max) / 2

    d_min = min(distances)
    d_max = max(distances)
    d_range = d_max - d_min

    result = []
    for d in distances:
        t = (d - d_min) / d_range if d_range > 0 else 0.5
        if invert:
            t = 1.0 - t
        if direction == 'Vertical':
            result.append((u_mid, v_min + t * (v_max - v_min)))
        else:
            result.append((u_min + t * (u_max - u_min), v_mid))
    return result


def compute_flat_center(dst_bounds):
    """Return the center UV coordinate of the rect.

    Used for flat strips where all vertices collapse to a single color.
    """
    u_min, v_min, u_max, v_max = dst_bounds
    return (u_min + u_max) / 2, (v_min + v_max) / 2


def compute_path_snap(t_values, dst_bounds, direction, margin=0.01,
                      invert=False):
    """Map path parameter values to UV coordinates within a cell.

    Parameters
    ----------
    t_values : list of float
        Normalized [0, 1] position along the drawn path.
    dst_bounds : (u_min, v_min, u_max, v_max)
        Target strip cell rect.
    direction : str
        ``'Vertical'`` or ``'Horizontal'`` � the gradient axis.
    margin : float
        Fraction of cell size to inset on each side (prevents bleed).
    invert : bool
        If True, flip the gradient direction (t becomes 1 - t).

    Returns
    -------
    list of (u, v) � one per input t-value.
    """
    u_min, v_min, u_max, v_max = dst_bounds
    # Inset to prevent bleed between adjacent strips
    w, h = u_max - u_min, v_max - v_min
    u_min += w * margin
    v_min += h * margin
    u_max -= w * margin
    v_max -= h * margin

    u_mid = (u_min + u_max) / 2
    v_mid = (v_min + v_max) / 2

    result = []
    for t in t_values:
        t = max(0.0, min(1.0, t))
        if invert:
            t = 1.0 - t
        if direction == 'Vertical':
            result.append((u_mid, v_min + t * (v_max - v_min)))
        else:
            result.append((u_min + t * (u_max - u_min), v_mid))
    return result
