# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Data classes for Palette Grid entries.

Pure Python � no bpy/bgui imports. Shared between core/ and app/.
"""

from enum import Enum
import uuid


class SPPalette:
    """Data class for a palette entry."""

    def __init__(self, name: str, strips=None, texture_size: int = 1024,
                 direction: str = "Vertical", color_space: str = "sRGB",
                 grid_cols: int = 8, grid_rows: int = 8, palette_id: str = None,
                 texture_width: int = 0, texture_height: int = 0):
        self.id = palette_id or uuid.uuid4().hex[:8]
        self.name = name
        self.strips = strips or []  # list[SPStrip]
        self.texture_size = texture_size
        # Non-square support: 0 means use texture_size (square)
        self.texture_width = texture_width if texture_width > 0 else texture_size
        self.texture_height = texture_height if texture_height > 0 else texture_size
        self.direction = direction      # "Horizontal" or "Vertical"
        self.color_space = color_space  # "sRGB", "Linear", "Raw"
        self.grid_cols = grid_cols
        self.grid_rows = grid_rows
        self.image_name = None          # str � name in bpy.data.images (set by app layer)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "texture_size": self.texture_size,
            "texture_width": self.texture_width,
            "texture_height": self.texture_height,
            "direction": self.direction,
            "color_space": self.color_space,
            "grid_cols": self.grid_cols,
            "grid_rows": self.grid_rows,
            "image_name": self.image_name,
            "strips": [s.to_dict() for s in self.strips],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SPPalette":
        strips = [SPStrip.from_dict(s) for s in d.get("strips", [])]
        p = cls(
            name=d["name"],
            strips=strips,
            texture_size=d.get("texture_size", 1024),
            direction=d.get("direction", "Vertical"),
            color_space=d.get("color_space", "sRGB"),
            grid_cols=d.get("grid_cols", 8),
            grid_rows=d.get("grid_rows", 8),
            palette_id=d.get("id"),
            texture_width=d.get("texture_width", 0),
            texture_height=d.get("texture_height", 0),
        )
        p.image_name = d.get("image_name")
        return p


class StripType(Enum):
    GRADIENT = "gradient"
    FLAT = "flat"


class SPStrip:
    """Data class for a single strip inside a palette.

    stops is a list of (position, (r, g, b, a)) tuples defining gradient control points.
    Position range is 0.0 to 1.0.
    For flat strips, there are 2 stops with the same color.
    """

    def __init__(self, name: str, strip_type: StripType = StripType.FLAT,
                 stops: list = None, direction: str = None,
                 color_mode: str = 'RGB', interpolation: str = 'LINEAR',
                 hue_interpolation: str = 'NEAR', effects: dict = None):
        self.name = name
        self.strip_type = strip_type
        self.direction = direction  # None = use palette direction; "Horizontal"/"Vertical"
        self.color_mode = color_mode        # 'RGB', 'HSV', 'HSL'
        self.interpolation = interpolation  # 'LINEAR', 'EASE', 'CARDINAL', 'B_SPLINE', 'CONSTANT'
        self.hue_interpolation = hue_interpolation  # 'NEAR', 'FAR', 'CW', 'CCW' (HSV/HSL only)
        self.effects = effects or {}  # Non-destructive effects: {"gamma": 1.0, ...}
        # Default to white at both ends
        self.stops = stops or [
            (0.0, (1.0, 1.0, 1.0, 1.0)),
            (1.0, (1.0, 1.0, 1.0, 1.0)),
        ]

    def to_dict(self) -> dict:
        d = {
            "name": self.name,
            "strip_type": self.strip_type.value,
            "stops": [[float(pos), [float(c) for c in color]] for pos, color in self.stops],
        }
        if self.direction is not None:
            d["direction"] = self.direction
        if self.color_mode != 'RGB':
            d["color_mode"] = self.color_mode
        if self.interpolation != 'LINEAR':
            d["interpolation"] = self.interpolation
        if self.hue_interpolation != 'NEAR':
            d["hue_interpolation"] = self.hue_interpolation
        if self.effects:
            d["effects"] = {k: float(v) for k, v in self.effects.items()}
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "SPStrip":
        return cls(
            name=d["name"],
            strip_type=StripType(d["strip_type"]),
            stops=[(s[0], tuple(s[1])) for s in d["stops"]],
            direction=d.get("direction"),
            color_mode=d.get("color_mode", 'RGB'),
            interpolation=d.get("interpolation", 'LINEAR'),
            hue_interpolation=d.get("hue_interpolation", 'NEAR'),
            effects=d.get("effects", {}),
        )
