# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Import/export for palette files � versioned schema, no bpy imports.

File format: JSON with envelope { format, version, palette }.
Only user-meaningful data is exported (no internal IDs or runtime state).
"""

import json

from .data import SPPalette, SPStrip, StripType

CURRENT_VERSION = 1
FORMAT_TAG = "palette_grid"


# -- Export ----------------------------------------------------

def _export_strip_v1(strip: SPStrip) -> dict:
    """Export a single strip � curated fields only."""
    d = {
        "name": strip.name,
        "type": strip.strip_type.value,
        "stops": [[float(pos), [float(c) for c in color]] for pos, color in strip.stops],
    }
    if strip.direction is not None:
        d["direction"] = strip.direction
    if strip.color_mode != "RGB":
        d["color_mode"] = strip.color_mode
    if strip.interpolation != "LINEAR":
        d["interpolation"] = strip.interpolation
    if strip.hue_interpolation != "NEAR":
        d["hue_interpolation"] = strip.hue_interpolation
    if strip.effects:
        d["effects"] = {k: float(v) for k, v in strip.effects.items()}
    return d


def _export_palette_v1(palette: SPPalette) -> dict:
    """Export palette � only user-meaningful data."""
    return {
        "name": palette.name,
        "texture_width": palette.texture_width,
        "texture_height": palette.texture_height,
        "direction": palette.direction,
        "color_space": palette.color_space,
        "grid_cols": palette.grid_cols,
        "grid_rows": palette.grid_rows,
        "strips": [_export_strip_v1(s) for s in palette.strips],
    }


def export_palette(palette: SPPalette) -> str:
    """Serialize a palette to a JSON string for saving to file."""
    envelope = {
        "format": FORMAT_TAG,
        "version": CURRENT_VERSION,
        "palette": _export_palette_v1(palette),
    }
    return json.dumps(envelope, indent=2, ensure_ascii=False)


# -- Migration chain ------------------------------------------

# Each migration function transforms data dict from version N to N+1.
# Add new entries as the schema evolves:
#   _MIGRATIONS = { 1: _migrate_v1_to_v2, 2: _migrate_v2_to_v3, ... }
_MIGRATIONS: dict = {}


def _migrate(data: dict, from_version: int) -> dict:
    """Upgrade data dict from *from_version* to CURRENT_VERSION."""
    v = from_version
    while v < CURRENT_VERSION:
        fn = _MIGRATIONS.get(v)
        if fn is None:
            raise ValueError(
                f"No migration from version {v} to {v + 1}")
        data = fn(data)
        v += 1
    return data


# -- Import ----------------------------------------------------

def _import_strip_v1(d: dict) -> SPStrip:
    """Reconstruct an SPStrip from exported dict."""
    return SPStrip(
        name=d.get("name", "Strip"),
        strip_type=StripType(d.get("type", "flat")),
        stops=[(s[0], tuple(s[1])) for s in d.get("stops", [])],
        direction=d.get("direction"),
        color_mode=d.get("color_mode", "RGB"),
        interpolation=d.get("interpolation", "LINEAR"),
        hue_interpolation=d.get("hue_interpolation", "NEAR"),
        effects=d.get("effects", {}),
    )


def _import_palette_v1(d: dict) -> SPPalette:
    """Reconstruct an SPPalette from exported dict."""
    strips = [_import_strip_v1(s) for s in d.get("strips", [])]
    tw = d.get("texture_width", 1024)
    th = d.get("texture_height", 1024)
    return SPPalette(
        name=d.get("name", "Imported Palette"),
        strips=strips,
        texture_size=max(tw, th),
        direction=d.get("direction", "Vertical"),
        color_space=d.get("color_space", "sRGB"),
        grid_cols=d.get("grid_cols", 8),
        grid_rows=d.get("grid_rows", 8),
        texture_width=tw,
        texture_height=th,
    )


def import_palette(raw: str) -> SPPalette:
    """Deserialize a JSON string into an SPPalette.

    Handles version migration automatically.
    Raises ValueError on invalid data.
    """
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as e:
        raise ValueError(f"Invalid JSON: {e}") from e

    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object at top level")

    fmt = data.get("format")
    if fmt != FORMAT_TAG:
        raise ValueError(
            f"Unknown format '{fmt}' � expected '{FORMAT_TAG}'")

    version = data.get("version", 1)
    if not isinstance(version, int) or version < 1:
        raise ValueError(f"Invalid version: {version}")

    if version > CURRENT_VERSION:
        raise ValueError(
            f"File version {version} is newer than supported "
            f"version {CURRENT_VERSION}. Please update the addon.")

    palette_data = data.get("palette")
    if not isinstance(palette_data, dict):
        raise ValueError("Missing or invalid 'palette' field")

    # Migrate if needed
    if version < CURRENT_VERSION:
        palette_data = _migrate(palette_data, version)

    return _import_palette_v1(palette_data)
