# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Palette operations � CRUD, strip management, ordering.

Pure functions, no bpy/bgui imports. Operates on core.data models.
"""
import random

from .data import SPPalette, SPStrip, StripType


def _random_rgba():
    """Generate a random RGBA color with full opacity."""
    return (random.random(), random.random(), random.random(), 1.0)


def compute_grid_size(texture_size: int, strips_type: str = "Flat",
                      direction: str = "Vertical") -> tuple:
    """Calculate grid dimensions (cols, rows) for a palette texture.

    Gradient cells need more pixels along the gradient axis:
      Vertical:   64w � 128h per cell
      Horizontal: 128w � 64h per cell
    Flat cells are square: 64 � 64.

    512  Grad-V: 8�4   Grad-H: 4�8   Flat: 8�8
    1K+  Grad-V: 16�8  Grad-H: 8�16  Flat: 16�16
    (2K/4K use 1K grid � extra resolution gives more pixels per cell)
    """
    # Cap at 1K for grid calculation
    calc_size = min(texture_size, 1024)
    if strips_type == "Gradient":
        if direction == "Vertical":
            cols = calc_size // 64
            rows = calc_size // 128
        else:  # Horizontal
            cols = calc_size // 128
            rows = calc_size // 64
    else:  # Flat
        cols = calc_size // 64
        rows = calc_size // 64
    return max(1, cols), max(1, rows)


def create_palette(name: str, texture_size: int = 1024,
                   strips_type: str = "Flat", direction: str = "Vertical",
                   color_space: str = "sRGB",
                   grid_cols: int = 0, grid_rows: int = 0,
                   texture_width: int = 0, texture_height: int = 0,
                   fill_color=None) -> SPPalette:
    """Create a new palette with auto-calculated grid of strips.

    If *grid_cols* / *grid_rows* are > 0, they override the auto-computed values.
    *texture_width* / *texture_height* override texture_size for non-square textures.

    *fill_color* controls how the strips are seeded:
      None            -- every strip gets its own random colour (the default,
                         unchanged behaviour)
      (r, g, b, a)    -- every strip is filled with exactly this colour, so the
                         new palette starts uniform and the user adds variation
                         deliberately.  Gradient strips get the same colour on
                         both stops rather than an invented second colour.
    """
    auto_cols, auto_rows = compute_grid_size(texture_size, strips_type, direction)
    cols = grid_cols if grid_cols > 0 else auto_cols
    rows = grid_rows if grid_rows > 0 else auto_rows
    count = cols * rows
    palette = SPPalette(name, texture_size=texture_size,
                        direction=direction, color_space=color_space,
                        grid_cols=cols, grid_rows=rows,
                        texture_width=texture_width, texture_height=texture_height)
    manual = fill_color is not None
    if manual:
        fill_color = tuple(fill_color)
        if len(fill_color) == 3:
            fill_color = fill_color + (1.0,)

    for i in range(count):
        if strips_type == "Gradient":
            if manual:
                stops = [(0.0, fill_color), (1.0, fill_color)]
            else:
                stops = [(0.0, _random_rgba()), (1.0, _random_rgba())]
            palette.strips.append(
                SPStrip(f"Strip {i + 1}", StripType.GRADIENT, stops)
            )
        else:
            color = fill_color if manual else _random_rgba()
            palette.strips.append(
                SPStrip(f"Strip {i + 1}", StripType.FLAT,
                        [(0.0, color), (1.0, color)])
            )
    return palette


def add_strip(palette: SPPalette, strip: SPStrip):
    """Add a strip to the end of the palette."""
    palette.strips.append(strip)


def remove_strip(palette: SPPalette, index: int):
    """Remove strip at index. Returns True if removed."""
    if 0 <= index < len(palette.strips):
        palette.strips.pop(index)
        return True
    return False


def reorder_strips(palette: SPPalette, from_idx: int, to_idx: int):
    """Move a strip from one position to another."""
    strips = palette.strips
    if 0 <= from_idx < len(strips) and 0 <= to_idx < len(strips):
        strip = strips.pop(from_idx)
        strips.insert(to_idx, strip)


def duplicate_palette(palette: SPPalette) -> SPPalette:
    """Deep copy a palette with ' Copy' suffix. Gets a fresh unique ID."""
    new_strips = [
        SPStrip(s.name, s.strip_type, list(s.stops))
        for s in palette.strips
    ]
    return SPPalette(palette.name + " Copy", new_strips,
                     texture_size=palette.texture_size,
                     direction=palette.direction,
                     color_space=palette.color_space,
                     grid_cols=palette.grid_cols,
                     grid_rows=palette.grid_rows,
                     texture_width=palette.texture_width,
                     texture_height=palette.texture_height)
