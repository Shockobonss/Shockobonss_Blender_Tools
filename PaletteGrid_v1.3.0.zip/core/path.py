# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Gradient path algorithms � pure math, no bpy.

All functions operate on plain Python data (tuples, lists, floats).
The app/ layer captures mouse input, calls these functions, and writes UV results.
"""
import math


# -- Arc-length parameterization -------------------------------------------

def arc_lengths(points):
    """Return cumulative arc-length at each vertex.

    Parameters
    ----------
    points : list of (x, y)
        Polyline vertices in screen space.

    Returns
    -------
    list of float � same length as *points*, starting at 0.0.
    """
    if not points:
        return []
    lengths = [0.0]
    for i in range(1, len(points)):
        dx = points[i][0] - points[i - 1][0]
        dy = points[i][1] - points[i - 1][1]
        lengths.append(lengths[-1] + math.hypot(dx, dy))
    return lengths


def normalize_lengths(cumulative):
    """Normalize cumulative arc-lengths to [0, 1].

    Parameters
    ----------
    cumulative : list of float
        Output of :func:`arc_lengths`.

    Returns
    -------
    list of float � same length, range [0.0, 1.0].
    """
    if not cumulative:
        return []
    total = cumulative[-1]
    if total < 1e-8:
        return [0.0] * len(cumulative)
    return [l / total for l in cumulative]


# -- Gradient sampling -----------------------------------------------------

def sample_gradient(stops, t):
    """Sample a gradient at position *t* (0-1).

    Parameters
    ----------
    stops : list of (position, (r, g, b, a))
        Gradient stop definitions, sorted by position.
    t : float
        Parameter in [0, 1].

    Returns
    -------
    (r, g, b, a) tuple.
    """
    if not stops:
        return (1.0, 1.0, 1.0, 1.0)

    sorted_stops = sorted(stops, key=lambda s: s[0])
    t = max(0.0, min(1.0, t))

    if t <= sorted_stops[0][0]:
        return sorted_stops[0][1]
    if t >= sorted_stops[-1][0]:
        return sorted_stops[-1][1]

    for i in range(1, len(sorted_stops)):
        p0, c0 = sorted_stops[i - 1]
        p1, c1 = sorted_stops[i]
        if p0 <= t <= p1:
            seg_t = (t - p0) / (p1 - p0) if (p1 - p0) > 1e-8 else 0.0
            return (
                c0[0] + (c1[0] - c0[0]) * seg_t,
                c0[1] + (c1[1] - c0[1]) * seg_t,
                c0[2] + (c1[2] - c0[2]) * seg_t,
                c0[3] + (c1[3] - c0[3]) * seg_t,
            )

    return sorted_stops[-1][1]


# -- Point-to-polyline projection ------------------------------------------

def _project_point_to_segment(px, py, ax, ay, bx, by):
    """Project point P onto segment AB. Returns (t_on_segment, sq_distance).

    t_on_segment is clamped to [0, 1].
    """
    abx = bx - ax
    aby = by - ay
    ab_sq = abx * abx + aby * aby
    if ab_sq < 1e-12:
        return 0.0, (px - ax) ** 2 + (py - ay) ** 2

    t = ((px - ax) * abx + (py - ay) * aby) / ab_sq
    t = max(0.0, min(1.0, t))
    nx = ax + t * abx
    ny = ay + t * aby
    return t, (px - nx) ** 2 + (py - ny) ** 2


def project_point_to_polyline(px, py, points, cum_lengths):
    """Find the nearest point on a polyline and return its global t value.

    Parameters
    ----------
    px, py : float
        The query point (screen space).
    points : list of (x, y)
        Polyline vertices.
    cum_lengths : list of float
        Cumulative arc-lengths (output of :func:`arc_lengths`).

    Returns
    -------
    float � the t parameter [0, 1] along the polyline.
    """
    if len(points) < 2:
        return 0.0

    total = cum_lengths[-1]
    if total < 1e-8:
        return 0.0

    best_t = 0.0
    best_dist_sq = float('inf')

    for i in range(len(points) - 1):
        ax, ay = points[i]
        bx, by = points[i + 1]
        seg_t, dist_sq = _project_point_to_segment(px, py, ax, ay, bx, by)

        if dist_sq < best_dist_sq:
            best_dist_sq = dist_sq
            seg_len = cum_lengths[i + 1] - cum_lengths[i]
            best_t = (cum_lengths[i] + seg_t * seg_len) / total

    return max(0.0, min(1.0, best_t))


def project_points_batch(screen_points, polyline, cum_lengths):
    """Project multiple points onto a polyline.

    Parameters
    ----------
    screen_points : list of (x, y)
        Points to project (e.g. vertex screen positions).
    polyline : list of (x, y)
        The drawn path.
    cum_lengths : list of float
        Cumulative arc-lengths of the polyline.

    Returns
    -------
    list of float � t values [0, 1] for each input point.
    """
    return [
        project_point_to_polyline(px, py, polyline, cum_lengths)
        for px, py in screen_points
    ]


# -- Path simplification --------------------------------------------------

def simplify_path(points, min_dist=4.0):
    """Remove points that are too close together.

    Parameters
    ----------
    points : list of (x, y)
    min_dist : float
        Minimum pixel distance between consecutive points.

    Returns
    -------
    list of (x, y) � simplified path (always includes first and last).
    """
    if len(points) <= 2:
        return list(points)

    result = [points[0]]
    min_sq = min_dist * min_dist
    for i in range(1, len(points) - 1):
        dx = points[i][0] - result[-1][0]
        dy = points[i][1] - result[-1][1]
        if dx * dx + dy * dy >= min_sq:
            result.append(points[i])
    result.append(points[-1])
    return result


def _rdp_simplify(points, epsilon):
    """Ramer-Douglas-Peucker polyline simplification.

    Recursively reduces a polyline to fewer points while keeping deviations
    below *epsilon* pixels.
    """
    if len(points) <= 2:
        return list(points)

    ax, ay = points[0]
    bx, by = points[-1]
    line_len = math.hypot(bx - ax, by - ay)

    max_dist = 0.0
    max_idx = 0

    if line_len < 1e-8:
        for i in range(1, len(points) - 1):
            d = math.hypot(points[i][0] - ax, points[i][1] - ay)
            if d > max_dist:
                max_dist = d
                max_idx = i
    else:
        dx, dy = bx - ax, by - ay
        for i in range(1, len(points) - 1):
            dist = abs(dy * (points[i][0] - ax) - dx * (points[i][1] - ay)) / line_len
            if dist > max_dist:
                max_dist = dist
                max_idx = i

    if max_dist > epsilon:
        left = _rdp_simplify(points[:max_idx + 1], epsilon)
        right = _rdp_simplify(points[max_idx:], epsilon)
        return left[:-1] + right
    else:
        return [points[0], points[-1]]


# -- Path smoothing --------------------------------------------------------

def smooth_path(points, iterations=2):
    """Smooth a polyline using Chaikin's corner-cutting algorithm.

    Each iteration replaces each segment with two new points at 25% and 75%
    along it, producing a progressively smoother curve.  The first and last
    points are always preserved.

    Parameters
    ----------
    points : list of (x, y)
    iterations : int
        Number of smoothing passes (2-3 is typical).

    Returns
    -------
    list of (x, y) � smoothed path.
    """
    if len(points) <= 2:
        return list(points)

    pts = list(points)
    for _ in range(iterations):
        new = [pts[0]]
        for i in range(len(pts) - 1):
            ax, ay = pts[i]
            bx, by = pts[i + 1]
            new.append((0.75 * ax + 0.25 * bx, 0.75 * ay + 0.25 * by))
            new.append((0.25 * ax + 0.75 * bx, 0.25 * ay + 0.75 * by))
        new.append(pts[-1])
        pts = new
    return pts


# -- Shape detection -------------------------------------------------------

def is_path_closed(points, threshold_ratio=0.15):
    """Check if the path forms a closed loop.

    Returns True if the distance between first and last points is less than
    *threshold_ratio* � total arc-length.
    """
    if len(points) < 3:
        return False
    cum = arc_lengths(points)
    total = cum[-1]
    if total < 1e-8:
        return False
    dx = points[-1][0] - points[0][0]
    dy = points[-1][1] - points[0][1]
    gap = math.hypot(dx, dy)
    return gap < total * threshold_ratio


def _turning_angle(ax, ay, bx, by, cx, cy):
    """Angle (degrees) of the turn at B in the polyline A?B?C.

    Returns 0-180 where 180 = straight, 0 = U-turn.
    """
    v1x, v1y = ax - bx, ay - by
    v2x, v2y = cx - bx, cy - by
    dot = v1x * v2x + v1y * v2y
    m1 = math.hypot(v1x, v1y)
    m2 = math.hypot(v2x, v2y)
    if m1 < 1e-8 or m2 < 1e-8:
        return 180.0
    cos_a = max(-1.0, min(1.0, dot / (m1 * m2)))
    return math.degrees(math.acos(cos_a))


def detect_corners(points, angle_threshold=120.0, min_dist_ratio=0.05,
                   closed=False):
    """Find corner vertices in a polyline.

    A corner is a vertex where the turning angle is less than
    *angle_threshold* degrees (180 = straight, 90 = right angle).

    Parameters
    ----------
    points : list of (x, y)
    angle_threshold : float
        Maximum turning angle to consider a corner (degrees).
    min_dist_ratio : float
        Minimum distance between corners as a fraction of total arc-length.
    closed : bool
        If True, treat the path as a closed loop and check all vertices
        (including first/last) using wraparound neighbors.

    Returns
    -------
    list of int � indices into *points* of detected corners.
    """
    if len(points) < 3:
        return []

    n = len(points)
    cum = arc_lengths(points)
    total = cum[-1]
    min_dist = total * min_dist_ratio

    # Compute turning angle at each vertex
    candidates = []
    start = 0 if closed else 1
    end = n if closed else n - 1

    for i in range(start, end):
        pi = (i - 1) % n if closed else i - 1
        ni = (i + 1) % n if closed else i + 1
        angle = _turning_angle(
            points[pi][0], points[pi][1],
            points[i][0], points[i][1],
            points[ni][0], points[ni][1],
        )
        if angle < angle_threshold:
            candidates.append((i, angle))

    if not candidates:
        return []

    # Non-maximum suppression: keep the sharpest corner in each neighborhood
    candidates.sort(key=lambda c: c[1])  # sharpest first
    selected = []
    for idx, _angle in candidates:
        too_close = False
        for s_idx in selected:
            d = abs(cum[idx] - cum[s_idx])
            if closed:
                d = min(d, total - d)
            if d < min_dist:
                too_close = True
                break
        if not too_close:
            selected.append(idx)

    selected.sort()
    return selected


def detect_line(points, max_deviation_ratio=0.07):
    """Test if the path is approximately a straight line.

    Parameters
    ----------
    points : list of (x, y)
    max_deviation_ratio : float
        Maximum perpendicular deviation / path-length ratio.

    Returns
    -------
    list of (x, y) with 2 points (start, end) if a line is detected,
    or None if not.
    """
    if len(points) < 2:
        return None

    ax, ay = points[0]
    bx, by = points[-1]
    line_len = math.hypot(bx - ax, by - ay)
    if line_len < 1e-8:
        return None

    cum = arc_lengths(points)
    total = cum[-1]
    if total < 1e-8:
        return None

    # Max perpendicular distance from any point to the line A?B
    max_dev = 0.0
    dx, dy = bx - ax, by - ay
    for px, py in points:
        # Distance from point to line
        dist = abs(dy * (px - ax) - dx * (py - ay)) / line_len
        if dist > max_dev:
            max_dev = dist

    if max_dev / total < max_deviation_ratio:
        return [(ax, ay), (bx, by)]
    return None


def _fit_bbox_rect(points, fill_ratio_min=0.65, pts_per_edge=16):
    """Fit an axis-aligned bounding-box rectangle to a closed path.

    Returns rectangle vertices if the path fills at least *fill_ratio_min*
    of its own bounding box area (shoelace area / bbox area), otherwise None.
    """
    if len(points) < 4:
        return None

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    x0, x1 = min(xs), max(xs)
    y0, y1 = min(ys), max(ys)
    bb_w, bb_h = x1 - x0, y1 - y0
    if bb_w < 1e-8 or bb_h < 1e-8:
        return None

    # Shoelace area of the drawn polygon
    n = len(points)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += points[i][0] * points[j][1]
        area -= points[j][0] * points[i][1]
    area = abs(area) / 2.0

    if area / (bb_w * bb_h) < fill_ratio_min:
        return None

    # Generate rectangle points (closed loop, evenly sampled edges)
    corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    result = []
    for i in range(4):
        cx0, cy0 = corners[i]
        cx1, cy1 = corners[(i + 1) % 4]
        for j in range(pts_per_edge):
            t = j / pts_per_edge
            result.append((cx0 + t * (cx1 - cx0), cy0 + t * (cy1 - cy0)))
    result.append(result[0])  # close
    return result


def _centroid(points):
    """Compute centroid (cx, cy) of a set of points."""
    n = len(points)
    cx = sum(p[0] for p in points) / n
    cy = sum(p[1] for p in points) / n
    return cx, cy


def fit_circle(points, n_output=64):
    """Fit a circle to a set of points and return evenly-spaced vertices.

    Parameters
    ----------
    points : list of (x, y)
    n_output : int
        Number of points on the fitted circle.

    Returns
    -------
    list of (x, y) � circle vertices, or None if fitting fails.
    """
    if len(points) < 3:
        return None

    cx, cy = _centroid(points)
    dists = [math.hypot(p[0] - cx, p[1] - cy) for p in points]
    avg_r = sum(dists) / len(dists)

    if avg_r < 1e-8:
        return None

    # Check circularity: max deviation from average radius
    max_dev = max(abs(d - avg_r) for d in dists)
    if max_dev / avg_r > 0.40:
        return None  # too irregular for a circle

    # Check aspect ratio: a circle's bounding box should be roughly square
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    bb_w = max(xs) - min(xs)
    bb_h = max(ys) - min(ys)
    if bb_w > 1e-8 and bb_h > 1e-8:
        aspect = max(bb_w, bb_h) / min(bb_w, bb_h)
        if aspect > 1.5:
            return None  # too elongated for a circle

    # Determine stroke direction (CW or CCW) from the original points
    # Use signed area (shoelace formula)
    signed_area = 0.0
    n = len(points)
    for i in range(n):
        j = (i + 1) % n
        signed_area += points[i][0] * points[j][1]
        signed_area -= points[j][0] * points[i][1]

    # Start angle from the first point
    start_angle = math.atan2(points[0][1] - cy, points[0][0] - cx)

    # Generate circle points
    direction = 1.0 if signed_area >= 0 else -1.0
    result = []
    for i in range(n_output):
        t = i / n_output
        a = start_angle + direction * 2.0 * math.pi * t
        result.append((cx + avg_r * math.cos(a), cy + avg_r * math.sin(a)))
    result.append(result[0])  # close the loop
    return result


def fit_polygon(points, corner_indices):
    """Create a clean polygon from detected corner positions.

    Connects the corner points with straight segments, generating intermediate
    points for smooth rendering.

    Parameters
    ----------
    points : list of (x, y)
        Original path points.
    corner_indices : list of int
        Indices of the detected corners.

    Returns
    -------
    list of (x, y) � polygon vertices with interpolated edges.
    """
    if len(corner_indices) < 3:
        return None

    corners = [points[i] for i in corner_indices]
    # Close the polygon
    corners.append(corners[0])

    # Generate intermediate points along each edge
    pts_per_edge = max(8, 64 // len(corner_indices))
    result = []
    for i in range(len(corners) - 1):
        ax, ay = corners[i]
        bx, by = corners[i + 1]
        for j in range(pts_per_edge):
            t = j / pts_per_edge
            result.append((ax + t * (bx - ax), ay + t * (by - ay)))
    result.append(result[0])  # close the loop
    return result


def detect_shape(points):
    """Run the full shape detection pipeline.

    Parameters
    ----------
    points : list of (x, y)
        Raw (or simplified) path points.

    Returns
    -------
    dict with keys:
        'type': str � 'line', 'circle', 'rectangle', 'polygon', or 'freehand'
        'points': list of (x, y) � fitted shape points (or original for 'freehand')
    """
    if len(points) < 2:
        return {'type': 'freehand', 'points': list(points)}

    closed = is_path_closed(points)

    if not closed:
        line = detect_line(points)
        if line is not None:
            return {'type': 'line', 'points': line}
        return {'type': 'freehand', 'points': list(points)}

    # -- Closed path ---------------------------------------------------
    cum = arc_lengths(points)
    total = cum[-1]

    # RDP-simplify for cleaner corner detection (collapses rounded-hand
    # arcs into sharp corner vertices).
    epsilon = total * 0.02
    simplified = _rdp_simplify(list(points), epsilon)

    # Remove overlapping end-points from the simplified path so wrapping
    # corner detection has meaningful geometry at the junction.
    while len(simplified) > 3:
        d = math.hypot(simplified[-1][0] - simplified[0][0],
                       simplified[-1][1] - simplified[0][1])
        if d < epsilon:
            simplified.pop()
        else:
            break

    # Detect corners on the simplified closed loop
    corners = detect_corners(simplified, closed=True)
    n_corners = len(corners)

    if n_corners == 0:
        # Use original dense points for circle fit (better circularity check)
        circle = fit_circle(points)
        if circle is not None:
            return {'type': 'circle', 'points': circle}

        # Bounding-box rectangle fallback for rounded rectangles:
        # If the closed path isn't circular, fit to its axis-aligned bbox.
        bb = _fit_bbox_rect(points)
        if bb is not None:
            return {'type': 'rectangle', 'points': bb}

        return {'type': 'freehand', 'points': list(points)}

    if n_corners == 3:
        # Try harder with relaxed threshold � might be a rectangle with
        # one corner slightly too gentle to detect.
        corners_relaxed = detect_corners(simplified, angle_threshold=150.0,
                                         closed=True)
        if len(corners_relaxed) == 4:
            poly = fit_polygon(simplified, corners_relaxed)
            if poly is not None:
                return {'type': 'rectangle', 'points': poly}

        # Junction recovery: when the user starts/ends at a corner,
        # overlap trimming can eat that vertex. Try inserting index 0
        # as the 4th corner if it's not already one of the 3.
        if 0 not in corners:
            trial = sorted(corners + [0])
            poly = fit_polygon(simplified, trial)
            if poly is not None:
                return {'type': 'rectangle', 'points': poly}

        # 3-corner shapes (triangles) conflict too often with rectangles;
        # fall through to freehand instead of fitting a polygon.
        return {'type': 'freehand', 'points': list(points)}

    if n_corners == 4:
        poly = fit_polygon(simplified, corners)
        if poly is not None:
            return {'type': 'rectangle', 'points': poly}

    if n_corners >= 5:
        poly = fit_polygon(simplified, corners)
        if poly is not None:
            return {'type': 'polygon', 'points': poly}

    return {'type': 'freehand', 'points': list(points)}
