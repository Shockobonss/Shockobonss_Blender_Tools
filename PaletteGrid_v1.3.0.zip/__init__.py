# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Palette Grid — Color palette addon with custom GPU UI framework."""
import bpy
import os

from . import bgui
from .app import build_main_panel


_panel = None


def _load_fonts():
    """Load font family from the fonts/ directory."""
    font_dir = os.path.join(os.path.dirname(__file__), "fonts")
    family = "Figtree"
    bgui.fonts.load_family(font_dir, {
        'light':    f'{family}-Light.ttf',
        'regular':  f'{family}-Regular.ttf',
        'medium':   f'{family}-Medium.ttf',
        'semibold': f'{family}-SemiBold.ttf',
        'bold':     f'{family}-Bold.ttf',
    })
    bgui.fonts.set_default('regular')


def _build_palette_panel():
    """Build the main palette grid panel."""
    return build_main_panel()


# ── Preferences ──────────────────────────────────────────────

class PaletteGridPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    hover_copy_paste: bpy.props.BoolProperty(
        name="Strip List: Copy/Paste on Hover",
        description="Speeds up palette iteration in the sidebar. Ctrl+C / Ctrl+V targets the strip under the mouse cursor so you can duplicate strip setups without changing selection first. Does not affect the overlay strip tool",
        default=True,
    )

    def _update_ui_scale(self, _context):
        bgui.set_user_scale(self.ui_scale)

    ui_scale: bpy.props.FloatProperty(
        name="UI Scale",
        description="Scales Palette Grid's custom interface so palette authoring, live editing, and UV workflow stay comfortable inside Blender. Combines with Blender's own DPI / pixel size setting",
        default=1.0,
        min=0.5, max=3.0,
        step=10, precision=2,
        update=_update_ui_scale,
    )

    popup_scale_factor: bpy.props.FloatProperty(
        name="Popup Scale Factor",
        description="Controls how strongly Palette Grid's editor popups follow UI Scale. Lower it if gradient or color popups feel too large compared with the main sidebar panel",
        default=1.0,
        min=0.0, max=1.0,
        step=10, precision=2,
    )

    skip_edit_mode_check: bpy.props.BoolProperty(
        name="Skip Edit Mode Check (Pie Menu)",
        description="Always show the UV snap pie menu even if no Edit Mode mesh is detected. Enable only if the pie menu incorrectly shows 'No mesh in Edit Mode' despite having one",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "hover_copy_paste")
        layout.prop(self, "ui_scale")
        layout.prop(self, "popup_scale_factor")
        layout.separator()
        layout.prop(self, "skip_edit_mode_check")
        if self.skip_edit_mode_check:
            box = layout.box()
            box.label(text="Warning: UV snap operators may fail if no mesh", icon='ERROR')
            box.label(text="is actually in Edit Mode. Only enable this if")
            box.label(text="detection incorrectly blocks the pie menu.")
        layout.separator()
        layout.operator("wm.url_open", text="SavedPixel.com", icon='WORLD').url = "https://savedpixel.com"


# ── Registration ─────────────────────────────────────────────

_classes = [
    PaletteGridPreferences,
]


def register():
    global _panel
    bgui.register()
    _load_fonts()
    for cls in _classes:
        bpy.utils.register_class(cls)
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        bgui.set_user_scale(prefs.ui_scale)
    except Exception:
        pass
    # Persistence — must be before panel build so listener is active
    from .app import persist as _persist
    _persist.register()
    # Eyedropper operator
    from .app import eyedrop as _eyedrop
    _eyedrop.register()
    # Import/export operators
    from .app import io_ops as _io_ops
    _io_ops.register()
    # Strip copy/paste operators + context menu
    from .app import strip_ops as _strip_ops
    _strip_ops.register()

    # Set up file-load callback: full panel rebuild after .blend open
    def _on_file_loaded():
        global _panel
        from .app.state import app_state
        if _panel is not None:
            _panel.unregister()
            _panel = None
        bgui.fonts.unload_all()
        _load_fonts()
        app_state.reset_listeners()
        # register() is idempotent -- clearing _registered would append a
        # duplicate of every handler on each file load.
        _persist.register()
        _panel = _build_palette_panel()
    _persist._on_file_loaded = _on_file_loaded

    _panel = _build_palette_panel()

    # Restore palettes from scene (survives disable/enable cycle).
    # Deferred because bpy.context.scene is unavailable during registration.
    def _deferred_restore():
        try:
            scene = bpy.context.scene
            if scene and scene.get("palette_grid"):
                _persist.load_from_scene()
                _on_file_loaded()
        except Exception:
            pass
        return None
    bpy.app.timers.register(_deferred_restore, first_interval=0.1)


def unregister():
    global _panel
    # Set shutdown flag FIRST — prevents draw callbacks from accessing freed data
    from .bgui import panel as _panel_mod
    _panel_mod._shutting_down = True
    if _panel is not None:
        _panel.unregister()
        _panel = None
    from .app import overlay as _overlay
    _overlay.unregister()
    from .app import persist as _persist
    _persist.unregister()
    from .app import eyedrop as _eyedrop
    _eyedrop.unregister()
    from .app import io_ops as _io_ops
    _io_ops.unregister()
    from .app import strip_ops as _strip_ops
    _strip_ops.unregister()
    # Tear down bgui BEFORE unregistering our classes — this removes all
    # draw handlers and the modal operator via cleanup_gpu(), preventing
    # Blender from dispatching events to freed memory.
    bgui.fonts.unload_all()
    bgui.unregister()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)

    # Release file locks on Windows — purge modules, caches, and __pycache__
    import sys, os, gc, importlib
    pkg = __package__
    pkg_dir = os.path.dirname(__file__)
    # Purge our modules from sys.modules
    to_del = [k for k in sys.modules if k == pkg or k.startswith(pkg + '.')]
    for k in to_del:
        del sys.modules[k]
    gc.collect()
    importlib.invalidate_caches()
    # Delete .pyc files individually (rmtree may fail on locked dirs)
    for dirpath, dirnames, filenames in os.walk(pkg_dir):
        if os.path.basename(dirpath) == '__pycache__':
            for f in filenames:
                try:
                    os.remove(os.path.join(dirpath, f))
                except Exception:
                    pass
            try:
                os.rmdir(dirpath)
            except Exception:
                pass
