# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Create Palette modal popup."""
import os
import bpy

from .. import bgui
from ..bgui.theme import StyleSheet as SS, DesignTokens as DT, _hex
from ..core.palette import compute_grid_size

_ASSETS = os.path.join(os.path.dirname(__file__), 'assets')

LIME     = (0.784, 1.0, 0.0, 1.0)
PANEL_BG = (0.098, 0.098, 0.11, 1.0)
CARD_BG  = (0.18, 0.18, 0.20, 1.0)
DARK_TEXT = (0.098, 0.098, 0.11, 1.0)


class _FlexButton(bgui.Button):
    def _measure_content_width(self) -> float:
        return 0


class _LazyIcon(bgui.ImageWidget):
    """ImageWidget that loads an SVG on first draw."""
    def __init__(self, path: str, **kwargs):
        super().__init__(image=None, **kwargs)
        self._path = path

    def _draw_content(self, renderer, style):
        if self.image is None:
            self.image = bgui.load_ui_image(self._path, svg_size=32)
        super()._draw_content(renderer, style)


def build_create_popup(on_create=None, on_pick_color=None):
    """Build the 'New Palette' modal popup.

    Args:
        on_create: optional callback(name, size, strips, direction, color_space,
            rows, cols, tex_width, tex_height, fill_color).
        on_pick_color: optional callback(current_color, apply_fn) used to let the
            user choose the manual fill colour.  The caller is responsible for
            showing the colour editor and calling apply_fn(color) with the
            result -- this popup deliberately knows nothing about that editor.

    Returns:
        (popup, open_fn) � call open_fn(btn) to show with a reset form.
    """
    def _force_redraw():
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

    name_input = bgui.TextInput(
        text="",
        placeholder="My Palette",
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=1,
            border_radius=5,
            font_size=14,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=120,
            padding=bgui.EdgeInsets(4, 8, 4, 8),
        ),
    )

    texture_seg = bgui.SegmentedControl(
        options=["512", "1K", "2K", "4K"],
        selected="1K",
        active_color=LIME,
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    strips_seg = bgui.SegmentedControl(
        options=["Flat", "Gradient"],
        selected="Flat",
        active_color=LIME,
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    _dir_icon = os.path.join(_ASSETS, 'direction_vertical.svg')
    direction_seg = bgui.SegmentedControl(
        options=["Horizontal", "Vertical"],
        selected="Vertical",
        active_color=LIME,
        icons=[
            (_dir_icon, -90),  # Horizontal = vertical icon rotated -90�
            _dir_icon,
        ],
        icon_size=14,
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    from .texture import get_color_spaces
    _color_spaces = get_color_spaces()
    _default_cs_idx = _color_spaces.index("sRGB") if "sRGB" in _color_spaces else 0
    color_dropdown = bgui.Dropdown(
        options=_color_spaces,
        selected=_default_cs_idx,
        columns=2,
        max_visible_rows=6,
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=0,
            border_radius=5,
            font_size=12,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=120,
            padding=bgui.EdgeInsets(4, 20, 4, 8),
            hover_style={'background_color': (0.35, 0.35, 0.39, 1.0)},
        ),
    )

    _POPUP_LABEL = bgui.Style(
        font_size=15,
        font_weight='semibold',
        font_color=(1.0, 1.0, 1.0, 1.0),
    )

    def _row(label_text, control, icon_path=None):
        label_children = []
        if icon_path:
            label_children.append(_LazyIcon(icon_path,
                                            style=bgui.Style(width=14, height=14)))
        label_children.append(bgui.Label(label_text, style=_POPUP_LABEL))
        left = bgui.Row(
            style=bgui.Style(alignment=bgui.Alignment.CENTER, gap=6),
            children=label_children,
        )
        return bgui.Row(
            style=bgui.Style(
                width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER,
                main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            ),
            children=[left, control],
        )

    # Direction row � visible only when "Gradient" selected
    direction_row = _row("Direction", direction_seg)
    direction_row.visible = False
    _DIR_ROW_HEIGHT = 26
    _ANIM_DUR = 0.2

    def _on_strips_change(widget):
        show = (widget.selected == "Gradient")
        if show:
            direction_row.visible = True
            direction_row.style.height = 0
            direction_row.style.opacity = 0.0
            bgui.Tween(direction_row.style, 'height', 0, _DIR_ROW_HEIGHT, _ANIM_DUR,
                       ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate())
            bgui.Tween(direction_row.style, 'opacity', 0.0, 1.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        else:
            cur_h = direction_row.style.height or _DIR_ROW_HEIGHT
            direction_row.style.height = cur_h

            def _collapse_done(tw):
                direction_row.visible = False
                direction_row.style.height = None
                direction_row.style.opacity = 1.0
                popup.invalidate()

            bgui.Tween(direction_row.style, 'height', cur_h, 0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate(),
                       on_complete=_collapse_done)
            bgui.Tween(direction_row.style, 'opacity', 1.0, 0.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        _force_redraw()

    strips_seg.on_change = _on_strips_change

    popup_card1 = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL,
        ),
        children=[
            _row("Name", name_input, icon_path=os.path.join(_ASSETS, 'Palletes.svg')),
            _row("Texture Size", texture_seg, icon_path=os.path.join(_ASSETS, 'Image.svg')),
        ],
    )

    popup_card2 = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL, clip_children=True,
        ),
        children=[
            _row("Strips Type", strips_seg, icon_path=os.path.join(_ASSETS, 'Strips.svg')),
            direction_row,
        ],
    )

    # -- Fill mode: random colours (Auto) or one chosen colour (Manual) ------
    _DEFAULT_FILL = (0.8, 0.8, 0.82, 1.0)
    _fill_color = [_DEFAULT_FILL]

    fill_swatch = bgui.Row(
        style=bgui.Style(
            width=120, height=26, border_radius=5,
            background_color=_DEFAULT_FILL,
            border_color=(0.30, 0.30, 0.34, 1.0), border_width=1,
            hover_style={'border_color': LIME},
        ),
        children=[],
    )

    def _set_fill_color(color):
        """Called back by the colour editor once the user has picked."""
        _fill_color[0] = color
        fill_swatch.style.background_color = color
        popup.invalidate()
        _force_redraw()

    def _open_fill_picker(_w=None):
        if on_pick_color:
            on_pick_color(_fill_color[0], _set_fill_color)

    fill_swatch.on_click = _open_fill_picker

    fill_seg = bgui.SegmentedControl(
        options=["Auto", "Manual"],
        selected="Auto",
        active_color=LIME,
        on_change=lambda w: _update_fill_visibility(animate=True),
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    fill_row = _row("Fill", fill_seg,
                    icon_path=os.path.join(_ASSETS, 'ColorEyedrop.svg'))
    fill_color_row = _row("Color", fill_swatch)
    fill_color_row.visible = False
    _FILL_ROW_HEIGHT = 26

    def _update_fill_visibility(animate=False):
        """Show the Color row only while Fill is set to Manual.

        Always driven from fill_seg's current value, so reopening the popup can
        never leave the swatch visible in Auto mode (or hidden in Manual).
        """
        show = fill_seg.selected == "Manual"
        if show == fill_color_row.visible:
            return
        if not animate:
            fill_color_row.visible = show
            fill_color_row.style.height = None
            fill_color_row.style.opacity = 1.0
            popup.invalidate()
            _force_redraw()
            return
        if show:
            fill_color_row.visible = True
            fill_color_row.style.height = 0
            fill_color_row.style.opacity = 0.0
            bgui.Tween(fill_color_row.style, 'height', 0, _FILL_ROW_HEIGHT,
                       _ANIM_DUR, ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate())
            bgui.Tween(fill_color_row.style, 'opacity', 0.0, 1.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        else:
            cur_h = fill_color_row.style.height or _FILL_ROW_HEIGHT
            fill_color_row.style.height = cur_h

            def _done(tw):
                fill_color_row.visible = False
                fill_color_row.style.height = None
                fill_color_row.style.opacity = 1.0
                popup.invalidate()

            bgui.Tween(fill_color_row.style, 'height', cur_h, 0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate(),
                       on_complete=_done)
            bgui.Tween(fill_color_row.style, 'opacity', 1.0, 0.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        _force_redraw()

    popup_card3 = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL, clip_children=True,
        ),
        children=[
            _row("Color Space", color_dropdown, icon_path=os.path.join(_ASSETS, 'color_space.svg')),
            fill_row,
            fill_color_row,
        ],
    )

    # -- "More" collapsible section � Rows & Columns --------------

    _SIZE_MAP = {"512": 512, "1K": 1024, "2K": 2048, "4K": 4096}
    _REVERSE_SIZE_MAP = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K"}

    def _current_defaults():
        """Compute default (cols, rows) from the current control values."""
        if texture_seg.selected is not None:
            size = _SIZE_MAP.get(texture_seg.selected, 1024)
        else:
            # Custom resolution � use max of width/height
            try:
                size = max(int(res_w_input.text), int(res_h_input.text))
            except (ValueError, TypeError):
                size = 1024
        strips = strips_seg.selected
        direction = direction_seg.selected if strips == "Gradient" else "Vertical"
        return compute_grid_size(size, strips, direction)

    def _grid_input_style():
        return bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=1,
            border_radius=5,
            font_size=12,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=52,
            padding=bgui.EdgeInsets(4, 8, 4, 8),
        )

    # Resolution inputs (width � height)
    _initial_size = _SIZE_MAP.get(texture_seg.selected, 1024)
    _syncing_res = [False]  # guard against recursive sync

    res_w_input = bgui.TextInput(text=str(_initial_size), placeholder="1024",
                                 style=_grid_input_style())
    res_h_input = bgui.TextInput(text=str(_initial_size), placeholder="1024",
                                 style=_grid_input_style())

    def _on_res_input_change(*_args):
        """When resolution inputs change, sync segmented control."""
        if _syncing_res[0]:
            return
        try:
            w = int(res_w_input.text)
            h = int(res_h_input.text)
        except (ValueError, TypeError):
            texture_seg.deselect()
            return
        # If square and matches a preset, select it
        if w == h and w in _REVERSE_SIZE_MAP:
            preset = _REVERSE_SIZE_MAP[w]
            if texture_seg.selected != preset:
                _syncing_res[0] = True
                texture_seg.select(preset)
                _syncing_res[0] = False
        else:
            texture_seg.deselect()

    res_w_input.on_change = _on_res_input_change
    res_h_input.on_change = _on_res_input_change

    cols_default, rows_default = _current_defaults()
    rows_input = bgui.TextInput(text=str(rows_default), placeholder="8",
                                style=_grid_input_style())
    cols_input = bgui.TextInput(text=str(cols_default), placeholder="16",
                                style=_grid_input_style())

    def _update_grid_defaults(*_args):
        """Refresh rows/cols inputs when texture size/strip type/direction changes."""
        c, r = _current_defaults()
        rows_input.text = str(r)
        rows_input.cursor_pos = len(rows_input.text)
        cols_input.text = str(c)
        cols_input.cursor_pos = len(cols_input.text)

    # Chain on_change: texture_seg + direction_seg update defaults
    _orig_texture_on_change = getattr(texture_seg, 'on_change', None)
    def _on_texture_change(w):
        if _orig_texture_on_change:
            _orig_texture_on_change(w)
        # Sync resolution inputs from selected preset
        if not _syncing_res[0] and w.selected is not None:
            size_val = _SIZE_MAP.get(w.selected, 1024)
            res_w_input.text = str(size_val)
            res_w_input.cursor_pos = len(res_w_input.text)
            res_h_input.text = str(size_val)
            res_h_input.cursor_pos = len(res_h_input.text)
        _update_grid_defaults()
    texture_seg.on_change = _on_texture_change

    _orig_direction_on_change = getattr(direction_seg, 'on_change', None)
    def _on_direction_change(w):
        if _orig_direction_on_change:
            _orig_direction_on_change(w)
        _update_grid_defaults()
    direction_seg.on_change = _on_direction_change

    # Also update on strip type changes (chain with existing _on_strips_change)
    _orig_strips_on_change = _on_strips_change
    def _on_strips_change_chained(w):
        _orig_strips_on_change(w)
        _update_grid_defaults()
    strips_seg.on_change = _on_strips_change_chained

    # Resolution row: [Width] � [Height]
    res_control = bgui.Row(
        style=bgui.Style(alignment=bgui.Alignment.CENTER, gap=6),
        children=[
            res_w_input,
            bgui.Label("�", style=bgui.Style(
                font_size=13, font_weight='medium',
                font_color=(0.55, 0.55, 0.58, 1.0),
            )),
            res_h_input,
        ],
    )
    more_res_row = _row("Resolution", res_control)
    more_rows_row = _row("Rows", rows_input)
    more_cols_row = _row("Columns", cols_input)
    more_res_row.visible = False
    more_rows_row.visible = False
    more_cols_row.visible = False
    _MORE_ROW_HEIGHT = 26
    _more_expanded = [False]

    more_arrow = bgui.Label("?", style=bgui.Style(
        font_size=10, font_weight='medium',
        font_color=(0.55, 0.55, 0.58, 1.0),
    ), on_click=lambda w: _toggle_more())

    more_label = bgui.Label("More", style=_POPUP_LABEL,
                            on_click=lambda w: _toggle_more())

    more_toggle_row = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
        ),
        children=[more_label, more_arrow],
        on_click=lambda w: _toggle_more(),
    )

    more_card = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL, clip_children=True,
            hover_style={'background_color': (0.22, 0.22, 0.24, 1.0)},
        ),
        children=[more_toggle_row, more_res_row, more_rows_row, more_cols_row],
    )

    _MORE_ROWS = (more_res_row, more_rows_row, more_cols_row)

    def _toggle_more():
        expanding = not _more_expanded[0]
        _more_expanded[0] = expanding
        if expanding:
            more_arrow.text = "?"
            for r in _MORE_ROWS:
                r.visible = True
                r.style.height = 0
                r.style.opacity = 0.0
                bgui.Tween(r.style, 'height', 0, _MORE_ROW_HEIGHT, _ANIM_DUR,
                           ease=bgui.ease_out_cubic,
                           on_update=lambda tw: popup.invalidate())
                bgui.Tween(r.style, 'opacity', 0.0, 1.0, _ANIM_DUR,
                           ease=bgui.ease_out_cubic)
        else:
            more_arrow.text = "?"
            for r in _MORE_ROWS:
                cur_h = r.style.height or _MORE_ROW_HEIGHT
                r.style.height = cur_h

                def _collapse_done(tw, row=r):
                    row.visible = False
                    row.style.height = None
                    row.style.opacity = 1.0
                    popup.invalidate()

                bgui.Tween(r.style, 'height', cur_h, 0, _ANIM_DUR,
                           ease=bgui.ease_out_cubic,
                           on_update=lambda tw: popup.invalidate(),
                           on_complete=_collapse_done)
                bgui.Tween(r.style, 'opacity', 1.0, 0.0, _ANIM_DUR,
                           ease=bgui.ease_out_cubic)
        _force_redraw()

    def _do_create():
        name = name_input.text.strip() or "Untitled"
        # Resolution inputs are the source of truth for texture size
        try:
            tex_w = max(1, int(res_w_input.text))
        except (ValueError, TypeError):
            tex_w = _SIZE_MAP.get(texture_seg.selected, 1024)
        try:
            tex_h = max(1, int(res_h_input.text))
        except (ValueError, TypeError):
            tex_h = tex_w
        size = str(max(tex_w, tex_h))
        strips = strips_seg.selected
        direction = direction_seg.selected if strips == "Gradient" else "N/A"
        color_space = color_dropdown.options[color_dropdown.selected]
        # Parse custom rows/cols (0 = auto)
        try:
            custom_rows = max(1, int(rows_input.text))
        except (ValueError, TypeError):
            custom_rows = 0
        try:
            custom_cols = max(1, int(cols_input.text))
        except (ValueError, TypeError):
            custom_cols = 0
        # Auto keeps the historical behaviour: every strip gets a random colour.
        fill_color = _fill_color[0] if fill_seg.selected == "Manual" else None
        if on_create:
            on_create(name, size, strips, direction, color_space,
                      custom_rows, custom_cols,
                      tex_width=tex_w, tex_height=tex_h,
                      fill_color=fill_color)
        popup.hide()

    _BTN_R = DT.radius.xl
    popup_buttons = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            gap=0,
        ),
        children=[
            _FlexButton("Cancel",
                style=bgui.Style(
                    background_color=_hex('#4D4D57'),
                    border_radius_tl=_BTN_R, border_radius_bl=_BTN_R,
                    border_radius_tr=0, border_radius_br=0,
                    font_size=DT.font.lg, font_color=(1.0, 1.0, 1.0, 1.0),
                    font_weight='semibold', padding=bgui.EdgeInsets(12, 4, 12, 4),
                    flex=1, width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={'background_color': (0.35, 0.35, 0.40, 1.0)},
                    active_style={'background_color': (0.25, 0.25, 0.29, 1.0)},
                ),
                on_click=lambda w: popup.hide(),
            ),
            _FlexButton("New Palette",
                style=bgui.Style(
                    background_color=LIME,
                    border_radius_tl=0, border_radius_bl=0,
                    border_radius_tr=_BTN_R, border_radius_br=_BTN_R,
                    font_size=DT.font.lg, font_color=DARK_TEXT,
                    font_weight='semibold', padding=bgui.EdgeInsets(12, 4, 12, 4),
                    flex=1, width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={'background_color': (0.7, 0.9, 0.0, 1.0)},
                    active_style={'background_color': (0.6, 0.8, 0.0, 1.0)},
                ),
                on_click=lambda w: _do_create(),
            ),
        ],
    )

    popup_content = bgui.ScrollBox(
        scroll_speed=24.0,
        style=bgui.Style(
            background_color=PANEL_BG, border_radius=DT.radius.xl,
            height_policy=bgui.SizePolicy.FILL,
            padding=bgui.EdgeInsets(14, 12, 14, 12), gap=10, width=300,
        ),
        children=[
            bgui.Label("New Palette", style=bgui.Style(
                font_size=DT.font.xxl, font_color=(1.0, 1.0, 1.0, 1.0),
                font_weight='bold', width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER, padding=bgui.EdgeInsets(4, 0, 6, 0),
            )),
            popup_card1, popup_card2, popup_card3, more_card, popup_buttons,
        ],
    )

    popup = bgui.ModalPopup("palette_create_popup", space_type='IMAGE_EDITOR')
    popup.set_root(popup_content)
    popup.on_dismiss = popup.hide

    def open_fn(btn=None):
        name_input.text = ""
        name_input.cursor_pos = 0
        # Reset "More" section
        _more_expanded[0] = False
        more_arrow.text = "?"
        more_res_row.visible = False
        more_rows_row.visible = False
        more_cols_row.visible = False
        more_res_row.style.height = None
        more_rows_row.style.height = None
        more_cols_row.style.height = None
        more_res_row.style.opacity = 1.0
        more_rows_row.style.opacity = 1.0
        more_cols_row.style.opacity = 1.0
        # Fill mode and its colour persist between palettes on purpose, but the
        # Color row must always agree with the mode -- re-derive it rather than
        # assuming whatever state the previous session left behind.
        fill_swatch.style.background_color = _fill_color[0]
        _update_fill_visibility()
        # Reset resolution inputs from current selection
        sel_size = _SIZE_MAP.get(texture_seg.selected, 1024)
        res_w_input.text = str(sel_size)
        res_w_input.cursor_pos = len(res_w_input.text)
        res_h_input.text = str(sel_size)
        res_h_input.cursor_pos = len(res_h_input.text)
        _update_grid_defaults()
        popup.show()

    return popup, open_fn


def build_strip_settings_popup(on_change=None, on_cancel=None):
    """Build the 'Strip Settings' modal popup with real-time preview.

    Args:
        on_change: optional callback(strip_index, name, strip_type, direction)
                   � called on every widget change for live preview.
        on_cancel: optional callback(strip_index, original_name, original_type,
                   original_direction, original_stops) � called on Cancel to revert.

    Returns:
        (popup, open_fn) � call open_fn(strip, index) to show with strip's current data.
    """
    from .data import StripType

    def _force_redraw():
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

    _strip_ref = [None, -1]  # (strip, index)
    _original = [None]  # snapshot: (name, strip_type, direction, stops)
    _initializing = [False]  # guard: don't fire change during open_fn setup

    def _fire_change():
        """Gather current widget values and fire on_change for live preview."""
        if _initializing[0] or on_change is None:
            return
        strip, idx = _strip_ref
        if strip is None:
            return
        new_name = name_input.text.strip() or strip.name
        new_type_str = strips_seg.selected
        new_type = StripType.FLAT if new_type_str == "Flat" else StripType.GRADIENT
        new_direction = direction_seg.selected if new_type == StripType.GRADIENT else None
        on_change(idx, new_name, new_type, new_direction)

    name_input = bgui.TextInput(
        text="",
        placeholder="Strip Name",
        on_change=lambda w: _fire_change(),
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=1,
            border_radius=5,
            font_size=14,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=120,
            padding=bgui.EdgeInsets(4, 8, 4, 8),
        ),
    )

    strips_seg = bgui.SegmentedControl(
        options=["Flat", "Gradient"],
        selected="Flat",
        active_color=LIME,
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    _dir_icon = os.path.join(_ASSETS, 'direction_vertical.svg')
    direction_seg = bgui.SegmentedControl(
        options=["Horizontal", "Vertical"],
        selected="Vertical",
        active_color=LIME,
        on_change=lambda w: _fire_change(),
        icons=[
            (_dir_icon, -90),
            _dir_icon,
        ],
        icon_size=14,
        style=bgui.Style(width=120, height=26, font_size=12),
    )

    _POPUP_LABEL = bgui.Style(
        font_size=15,
        font_weight='semibold',
        font_color=(1.0, 1.0, 1.0, 1.0),
    )

    def _row(label_text, control, icon_path=None):
        label_children = []
        if icon_path:
            label_children.append(_LazyIcon(icon_path,
                                            style=bgui.Style(width=14, height=14)))
        label_children.append(bgui.Label(label_text, style=_POPUP_LABEL))
        left = bgui.Row(
            style=bgui.Style(alignment=bgui.Alignment.CENTER, gap=6),
            children=label_children,
        )
        return bgui.Row(
            style=bgui.Style(
                width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER,
                main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            ),
            children=[left, control],
        )

    # Direction row � visible only when "Gradient" selected
    direction_row = _row("Direction", direction_seg)
    direction_row.visible = False
    _DIR_ROW_HEIGHT = 26
    _ANIM_DUR = 0.2

    def _on_strips_change(widget):
        show = (widget.selected == "Gradient")
        if show:
            direction_row.visible = True
            direction_row.style.height = 0
            direction_row.style.opacity = 0.0
            bgui.Tween(direction_row.style, 'height', 0, _DIR_ROW_HEIGHT, _ANIM_DUR,
                       ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate())
            bgui.Tween(direction_row.style, 'opacity', 0.0, 1.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        else:
            cur_h = direction_row.style.height or _DIR_ROW_HEIGHT
            direction_row.style.height = cur_h

            def _collapse_done(tw):
                direction_row.visible = False
                direction_row.style.height = None
                direction_row.style.opacity = 1.0
                popup.invalidate()

            bgui.Tween(direction_row.style, 'height', cur_h, 0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic,
                       on_update=lambda tw: popup.invalidate(),
                       on_complete=_collapse_done)
            bgui.Tween(direction_row.style, 'opacity', 1.0, 0.0, _ANIM_DUR,
                       ease=bgui.ease_out_cubic)
        _force_redraw()
        _fire_change()

    strips_seg.on_change = _on_strips_change

    popup_card1 = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL,
        ),
        children=[
            _row("Name", name_input, icon_path=os.path.join(_ASSETS, 'Strips.svg')),
        ],
    )

    popup_card2 = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=6,
            padding=bgui.EdgeInsets(14, 19, 14, 19), gap=12,
            width_policy=bgui.SizePolicy.FILL, clip_children=True,
        ),
        children=[
            _row("Strip Type", strips_seg, icon_path=os.path.join(_ASSETS, 'Settings.svg')),
            direction_row,
        ],
    )

    def _do_update():
        # Changes already applied live � just close.
        popup.hide()

    def _do_cancel():
        strip, idx = _strip_ref
        orig = _original[0]
        if strip is not None and orig is not None and on_cancel:
            on_cancel(idx, orig[0], orig[1], orig[2], orig[3])
        popup.hide()

    _BTN_R = DT.radius.xl
    popup_buttons = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            gap=0,
        ),
        children=[
            _FlexButton("Cancel",
                style=bgui.Style(
                    background_color=_hex('#4D4D57'),
                    border_radius_tl=_BTN_R, border_radius_bl=_BTN_R,
                    border_radius_tr=0, border_radius_br=0,
                    font_size=DT.font.lg, font_color=(1.0, 1.0, 1.0, 1.0),
                    font_weight='semibold', padding=bgui.EdgeInsets(12, 4, 12, 4),
                    flex=1, width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={'background_color': (0.35, 0.35, 0.40, 1.0)},
                    active_style={'background_color': (0.25, 0.25, 0.29, 1.0)},
                ),
                on_click=lambda w: _do_cancel(),
            ),
            _FlexButton("Update",
                style=bgui.Style(
                    background_color=LIME,
                    border_radius_tl=0, border_radius_bl=0,
                    border_radius_tr=_BTN_R, border_radius_br=_BTN_R,
                    font_size=DT.font.lg, font_color=DARK_TEXT,
                    font_weight='semibold', padding=bgui.EdgeInsets(12, 4, 12, 4),
                    flex=1, width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={'background_color': (0.7, 0.9, 0.0, 1.0)},
                    active_style={'background_color': (0.6, 0.8, 0.0, 1.0)},
                ),
                on_click=lambda w: _do_update(),
            ),
        ],
    )

    popup_content = bgui.ScrollBox(
        scroll_speed=24.0,
        style=bgui.Style(
            background_color=PANEL_BG, border_radius=DT.radius.xl,
            height_policy=bgui.SizePolicy.FILL,
            padding=bgui.EdgeInsets(14, 12, 14, 12), gap=10, width=300,
        ),
        children=[
            bgui.Label("Strip Settings", style=bgui.Style(
                font_size=DT.font.xxl, font_color=(1.0, 1.0, 1.0, 1.0),
                font_weight='bold', width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER, padding=bgui.EdgeInsets(4, 0, 6, 0),
            )),
            popup_card1, popup_card2, popup_buttons,
        ],
    )

    popup = bgui.ModalPopup("strip_settings_popup", space_type='IMAGE_EDITOR')
    popup.set_root(popup_content)
    popup.on_dismiss = _do_cancel

    def open_fn(strip, index):
        _strip_ref[0] = strip
        _strip_ref[1] = index
        # Snapshot original state for Cancel revert
        _original[0] = (strip.name, strip.strip_type, strip.direction,
                        list(strip.stops))
        _initializing[0] = True
        name_input.text = strip.name
        name_input.cursor_pos = len(strip.name)
        # Set strip type
        if strip.strip_type == StripType.FLAT:
            strips_seg.select("Flat")
            direction_row.visible = False
        else:
            strips_seg.select("Gradient")
            direction_row.visible = True
            direction_row.style.height = None
            direction_row.style.opacity = 1.0
            direction_seg.select(strip.direction or "Vertical")
        _initializing[0] = False
        popup.show()

    return popup, open_fn
