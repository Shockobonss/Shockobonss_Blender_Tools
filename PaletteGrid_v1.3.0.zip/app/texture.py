# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Texture generation � creates Blender images from palette strip data.

Lives in app/ because it depends on bpy. Core data models stay pure Python.
"""
import bpy
import numpy as np
import colorsys

from ..core.data import SPPalette, StripType
from ..core.effects import EFFECT_ORDER

# Prefix for palette textures in bpy.data.images
_PREFIX = "PG_"

# Pixel buffer cache: {palette_id: (tex_w, tex_h, numpy_array_shaped)}
# Avoids re-reading the full pixel buffer on every update_strip call.
_pixel_cache: dict = {}


def clear_pixel_cache():
    """Clear the pixel buffer cache � call after undo/redo to avoid stale data."""
    _pixel_cache.clear()


def find_image_by_palette_id(palette_id: str):
    """Find a Blender image tagged with the given palette ID.

    Handles image renames � looks up by custom property instead of name.
    Returns the image or None.
    """
    for img in bpy.data.images:
        if img.get("pg_id") == palette_id:
            return img
    return None


def generate_texture(palette: SPPalette) -> bpy.types.Image:
    """Create a new Blender image and fill it from the palette's strips.

    Sets palette.image_name so the app layer can look it up later.
    If an image with the same name already exists, it is replaced.
    """
    name = f"{_PREFIX}{palette.id}"
    w = palette.texture_width
    h = palette.texture_height

    # Remove stale image with same name
    old = bpy.data.images.get(name)
    if old is not None:
        bpy.data.images.remove(old)

    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    img.use_fake_user = True
    img.colorspace_settings.name = palette.color_space
    img["pg_id"] = palette.id
    palette.image_name = name

    _fill_pixels(img, palette)
    return img


def update_texture(palette: SPPalette) -> bpy.types.Image:
    """Regenerate pixels for an existing palette texture.

    Creates the image if it doesn't exist yet.
    """
    if palette.image_name and palette.image_name in bpy.data.images:
        img = bpy.data.images[palette.image_name]
        img.use_fake_user = True
        _fill_pixels(img, palette)
        return img
    # Name mismatch � try finding by palette ID (handles renames)
    img = find_image_by_palette_id(palette.id)
    if img is not None:
        palette.image_name = img.name
        img.use_fake_user = True
        _fill_pixels(img, palette)
        return img
    return generate_texture(palette)


def update_strip(palette: SPPalette, strip_index: int) -> bpy.types.Image:
    """Fast partial update � regenerate only one strip's pixel region.

    Much faster than update_texture() for large palettes (4K, many strips)
    because it avoids re-computing all other cells.
    """
    img = None
    if palette.image_name and palette.image_name in bpy.data.images:
        img = bpy.data.images[palette.image_name]
    else:
        img_found = find_image_by_palette_id(palette.id)
        if img_found:
            img = img_found
            palette.image_name = img.name
    if img is None:
        return generate_texture(palette)

    if strip_index < 0 or strip_index >= len(palette.strips):
        return img

    tex_w = palette.texture_width
    tex_h = palette.texture_height
    cols = palette.grid_cols
    rows = palette.grid_rows

    col_edges = [round(c * tex_w / cols) for c in range(cols + 1)]
    row_edges = [round(r * tex_h / rows) for r in range(rows + 1)]

    col = strip_index % cols
    row = strip_index // cols
    cw = col_edges[col + 1] - col_edges[col]
    ch = row_edges[row + 1] - row_edges[row]
    px_x0 = col_edges[col]
    px_y0 = tex_h - row_edges[row + 1]

    strip = palette.strips[strip_index]
    sorted_stops = sorted(strip.stops, key=lambda s: s[0])

    # Try to use cached pixel buffer (avoids expensive foreach_get read)
    cached = _pixel_cache.get(palette.id)
    if cached and cached[0] == tex_w and cached[1] == tex_h:
        pixels = cached[2]
    else:
        # Cold start � read from image
        pixel_count = tex_w * tex_h * 4
        pixels = np.empty(pixel_count, dtype=np.float32)
        img.pixels.foreach_get(pixels)
        # If image was blanked (RGB all zeros), do full regeneration instead
        rgb = pixels.reshape(-1, 4)[:, :3]
        if not rgb.any():
            return update_texture(palette)
        pixels = pixels.reshape(tex_h, tex_w, 4)
        _pixel_cache[palette.id] = (tex_w, tex_h, pixels)

    # Update only the affected cell
    if strip.strip_type == StripType.FLAT:
        color = np.array(sorted_stops[0][1], dtype=np.float32)
        pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = color
        if getattr(strip, 'effects', None):
            cell = pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw]
            _apply_effects_np(cell, strip.effects)
    else:
        cm = getattr(strip, 'color_mode', 'RGB')
        ip = getattr(strip, 'interpolation', 'LINEAR')
        hi = getattr(strip, 'hue_interpolation', 'NEAR')
        direction = strip.direction or palette.direction
        if direction == "Vertical":
            t = np.linspace(1.0, 0.0, ch)
            colors = _interpolate_stops(sorted_stops, t, cm, ip, hi)
            pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = colors.reshape(ch, 1, 4)
        else:
            t = np.linspace(0.0, 1.0, cw)
            colors = _interpolate_stops(sorted_stops, t, cm, ip, hi)
            pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = colors.reshape(1, cw, 4)
        if getattr(strip, 'effects', None):
            cell = pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw]
            _apply_effects_np(cell, strip.effects)

    img.pixels.foreach_set(pixels.ravel())
    img.update()
    return img


def remove_texture(palette: SPPalette):
    """Remove the Blender image associated with a palette."""
    _pixel_cache.pop(palette.id, None)
    name = palette.image_name
    # Clear name BEFORE removing so depsgraph handler won't regenerate
    palette.image_name = None
    if name and name in bpy.data.images:
        img = bpy.data.images[name]
        # Remove pg_id tag so find_image_by_palette_id won't match
        if "pg_id" in img:
            del img["pg_id"]
        bpy.data.images.remove(img)


def focus_texture(palette: SPPalette):
    """Set the palette's texture as the active image in the Image Editor.

    When called during sidebar event processing (the modal has tracked the
    active area), only the Image Editor the user is currently interacting
    with is updated.  Otherwise (file load, recovery) all Image Editors
    are updated.
    """
    if not palette.image_name or palette.image_name not in bpy.data.images:
        return
    img = bpy.data.images[palette.image_name]

    # Scope to the actively-interacted area when available
    try:
        from ..bgui.panel import get_current_event_area
        area = get_current_event_area()
        if area is not None:
            try:
                if area.type == 'IMAGE_EDITOR' and area.spaces.active:
                    area.spaces.active.image = img
                    return
            except ReferenceError:
                pass  # area was freed � fall through
    except ImportError:
        pass

    # Fallback: set in all Image Editors
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = img


def get_color_spaces() -> list:
    """Return a list of available settable color space names from Blender's OCIO config."""
    try:
        items = bpy.types.ColorManagedInputColorspaceSettings.bl_rna.properties['name'].enum_items
        # Filter out role-based aliases that can't be directly assigned
        _roles = {'Working Space'}
        return [item.name for item in items if item.name not in _roles]
    except Exception:
        return ["sRGB", "Non-Color", "Linear Rec.709", "Raw"]


def apply_color_space(palette: SPPalette, color_space: str):
    """Change a palette's color space and regenerate the texture."""
    palette.color_space = color_space
    _pixel_cache.pop(palette.id, None)
    if palette.image_name and palette.image_name in bpy.data.images:
        img = bpy.data.images[palette.image_name]
        try:
            img.colorspace_settings.name = color_space
        except TypeError:
            img.colorspace_settings.name = 'sRGB'
            palette.color_space = 'sRGB'
        _fill_pixels(img, palette)


# -- Internal --------------------------------------------------


def _interpolate_stops(stops, t_array, color_mode='RGB', interpolation='LINEAR',
                       hue_interpolation='NEAR'):
    """Vectorized multi-stop gradient interpolation.

    Args:
        stops: sorted list of (position, (r, g, b, a)) tuples
        t_array: 1D numpy array of positions in [0, 1]
        color_mode: 'RGB', 'HSV', or 'HSL'
        interpolation: 'LINEAR', 'EASE', 'CARDINAL', 'B_SPLINE', 'CONSTANT'
        hue_interpolation: 'NEAR', 'FAR', 'CW', 'CCW' (HSV/HSL only)

    Returns:
        (len(t_array), 4) float32 array of interpolated colors.
    """
    positions = np.array([s[0] for s in stops], dtype=np.float32)
    colors = np.array([s[1] for s in stops], dtype=np.float32)
    result = np.empty((len(t_array), 4), dtype=np.float32)

    # Clamp to boundary colors
    result[t_array <= positions[0]] = colors[0]
    result[t_array >= positions[-1]] = colors[-1]

    # Interpolate between each pair of stops
    for i in range(len(stops) - 1):
        p0, p1 = positions[i], positions[i + 1]
        c0, c1 = colors[i], colors[i + 1]
        mask = (t_array > p0) & (t_array <= p1)
        if i == 0:
            mask |= (t_array == p0)
        if not np.any(mask):
            continue
        span = p1 - p0
        if span < 1e-9:
            result[mask] = c0
        else:
            frac = ((t_array[mask] - p0) / span).reshape(-1, 1)

            # Apply interpolation curve to frac
            if interpolation == 'CONSTANT':
                result[mask] = c0
                continue
            elif interpolation == 'EASE':
                frac = frac * frac * (3.0 - 2.0 * frac)  # smoothstep
            elif interpolation == 'B_SPLINE':
                # Approximate B-spline ease with a stronger S-curve
                frac = frac * frac * frac * (frac * (frac * 6.0 - 15.0) + 10.0)
            # CARDINAL and LINEAR use frac as-is (cardinal needs multi-stop
            # cubic which is complex; linear is identity)

            if color_mode == 'RGB':
                result[mask] = c0 * (1.0 - frac) + c1 * frac
            else:
                # Convert to HSV or HSL, interpolate, convert back
                result[mask] = _interp_in_color_space(
                    c0, c1, frac.ravel(), color_mode, hue_interpolation)

    return result


def _hue_diff(h0, h1, mode):
    """Compute hue delta for interpolation, matching Blender's colorband logic.

    h0, h1: hue values in [0, 1]
    mode: 'NEAR', 'FAR', 'CW', 'CCW'
    Returns: signed delta such that h(t) = (h0 + delta * t) % 1.0
    """
    dh = h1 - h0
    if mode == 'NEAR':
        if dh > 0.5:
            dh -= 1.0
        elif dh < -0.5:
            dh += 1.0
    elif mode == 'FAR':
        if h0 == h1:
            dh = 1.0
        elif 0.0 < dh < 0.5:
            dh -= 1.0
        elif -0.5 < dh < 0.0:
            dh += 1.0
    elif mode == 'CW':
        if dh < 0.0:
            dh += 1.0
    elif mode == 'CCW':
        if dh > 0.0:
            dh -= 1.0
    return dh


def _interp_in_color_space(c0, c1, frac, mode, hue_interpolation='NEAR'):
    """Interpolate between two RGBA colors in HSV or HSL space.

    c0, c1: (4,) numpy arrays (RGBA)
    frac: 1D numpy array of interpolation factors
    mode: 'HSV' or 'HSL'
    hue_interpolation: 'NEAR', 'FAR', 'CW', 'CCW'

    Returns: (len(frac), 4) RGBA array
    """
    import colorsys
    n = len(frac)
    result = np.empty((n, 4), dtype=np.float32)

    r0, g0, b0, a0 = float(c0[0]), float(c0[1]), float(c0[2]), float(c0[3])
    r1, g1, b1, a1 = float(c1[0]), float(c1[1]), float(c1[2]), float(c1[3])

    if mode == 'HSV':
        h0, s0, v0 = colorsys.rgb_to_hsv(r0, g0, b0)
        h1, s1, v1 = colorsys.rgb_to_hsv(r1, g1, b1)
        dh = _hue_diff(h0, h1, hue_interpolation)
        for j in range(n):
            f = frac[j]
            h = (h0 + dh * f) % 1.0
            s = s0 + (s1 - s0) * f
            v = v0 + (v1 - v0) * f
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            a = a0 + (a1 - a0) * f
            result[j] = (r, g, b, a)
    else:  # HSL
        h0, s0, l0 = _rgb_to_hsl(r0, g0, b0)
        h1, s1, l1 = _rgb_to_hsl(r1, g1, b1)
        dh = _hue_diff(h0, h1, hue_interpolation)
        for j in range(n):
            f = frac[j]
            h = (h0 + dh * f) % 1.0
            s = s0 + (s1 - s0) * f
            l = l0 + (l1 - l0) * f
            r, g, b = _hsl_to_rgb(h, s, l)
            a = a0 + (a1 - a0) * f
            result[j] = (r, g, b, a)
    return result


def _rgb_to_hsl(r, g, b):
    """Convert RGB to HSL. Returns (h, s, l) in [0,1]."""
    mx = max(r, g, b)
    mn = min(r, g, b)
    l = (mx + mn) / 2.0
    if mx == mn:
        return (0.0, 0.0, l)
    d = mx - mn
    s = d / (2.0 - mx - mn) if l > 0.5 else d / (mx + mn)
    if mx == r:
        h = (g - b) / d + (6.0 if g < b else 0.0)
    elif mx == g:
        h = (b - r) / d + 2.0
    else:
        h = (r - g) / d + 4.0
    return (h / 6.0, s, l)


def _hsl_to_rgb(h, s, l):
    """Convert HSL to RGB. Returns (r, g, b) in [0,1]."""
    if s == 0.0:
        return (l, l, l)
    def hue2rgb(p, q, t):
        if t < 0.0: t += 1.0
        if t > 1.0: t -= 1.0
        if t < 1/6: return p + (q - p) * 6.0 * t
        if t < 1/2: return q
        if t < 2/3: return p + (q - p) * (2/3 - t) * 6.0
        return p
    q = l * (1.0 + s) if l < 0.5 else l + s - l * s
    p = 2.0 * l - q
    return (hue2rgb(p, q, h + 1/3), hue2rgb(p, q, h), hue2rgb(p, q, h - 1/3))


def _apply_effects_np(cell, effects):
    """Apply effects pipeline to a numpy pixel region in-place.

    *cell* is a (..., 4) float32 array (the RGBA pixel region).
    *effects* is a sparse dict of effect values.
    Mirrors core.effects pipeline order: hue ? saturation ? gamma ? contrast.
    """
    # Hue shift
    hue_val = effects.get("hue")
    if hue_val is not None and hue_val != 0.0:
        rgb = cell[..., :3]
        # Convert RGB ? HSV per pixel, shift hue, convert back
        mx = rgb.max(axis=-1)
        mn = rgb.min(axis=-1)
        diff = mx - mn
        # Hue calculation
        h = np.zeros_like(mx)
        mask = diff > 1e-9
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        # Where max == R
        m_r = mask & (mx == r)
        h[m_r] = ((g[m_r] - b[m_r]) / diff[m_r]) % 6.0
        # Where max == G
        m_g = mask & (mx == g) & ~m_r
        h[m_g] = (b[m_g] - r[m_g]) / diff[m_g] + 2.0
        # Where max == B
        m_b = mask & ~m_r & ~m_g
        h[m_b] = (r[m_b] - g[m_b]) / diff[m_b] + 4.0
        h = (h / 6.0 + hue_val) % 1.0
        s = np.where(mx > 1e-9, diff / mx, 0.0)
        v = mx
        # HSV ? RGB
        hi = (h * 6.0).astype(np.int32) % 6
        f = h * 6.0 - hi.astype(np.float32)
        p = v * (1 - s)
        q = v * (1 - f * s)
        t = v * (1 - (1 - f) * s)
        # Build result per sector
        nr = np.where(hi == 0, v, np.where(hi == 1, q, np.where(hi == 2, p, np.where(hi == 3, p, np.where(hi == 4, t, v)))))
        ng = np.where(hi == 0, t, np.where(hi == 1, v, np.where(hi == 2, v, np.where(hi == 3, q, np.where(hi == 4, p, p)))))
        nb = np.where(hi == 0, p, np.where(hi == 1, p, np.where(hi == 2, t, np.where(hi == 3, v, np.where(hi == 4, v, q)))))
        cell[..., 0] = np.clip(nr, 0.0, 1.0)
        cell[..., 1] = np.clip(ng, 0.0, 1.0)
        cell[..., 2] = np.clip(nb, 0.0, 1.0)

    # Saturation
    sat = effects.get("saturation")
    if sat is not None and sat != 0.0:
        rgb = cell[..., :3]
        mx = rgb.max(axis=-1, keepdims=True)
        mn = rgb.min(axis=-1, keepdims=True)
        diff = mx - mn
        # Value (brightness)
        v = mx
        # Saturation (avoid division by zero)
        s_old = np.where(v > 0, diff / np.maximum(v, 1e-9), 0.0)
        s_new = np.clip(s_old + sat, 0.0, 1.0)
        # Scale RGB to achieve new saturation while preserving hue and value
        # When s_old > 0: scale chroma by s_new/s_old
        ratio = np.where(s_old > 1e-9, s_new / s_old, 1.0)
        # new_rgb = v - (v - rgb) * ratio  (adjusts distance from max)
        cell[..., :3] = np.clip(v - (v - rgb) * ratio, 0.0, 1.0)

    # Gamma
    gamma_val = effects.get("gamma")
    if gamma_val is not None and gamma_val != 1.0 and gamma_val > 0:
        inv = 1.0 / gamma_val
        cell[..., :3] = np.clip(np.power(np.maximum(cell[..., :3], 0.0), inv), 0.0, 1.0)

    # Contrast
    contrast_val = effects.get("contrast")
    if contrast_val is not None and contrast_val != 0.0:
        factor = 1.0 + contrast_val
        cell[..., :3] = np.clip(0.5 + (cell[..., :3] - 0.5) * factor, 0.0, 1.0)


def _fill_pixels(img: bpy.types.Image, palette: SPPalette):
    """Fill image pixels based on palette grid layout and strip colors.

    Pixel array uses Blender convention: row 0 = bottom of image.
    Grid convention: row 0 = top of image (first strip row).
    """
    tex_w = palette.texture_width
    tex_h = palette.texture_height
    cols = palette.grid_cols
    rows = palette.grid_rows

    # Pre-compute pixel boundaries so remainder pixels are spread evenly.
    # Every cell is either floor(size/n) or ceil(size/n) wide/tall.
    col_edges = [round(c * tex_w / cols) for c in range(cols + 1)]
    row_edges = [round(r * tex_h / rows) for r in range(rows + 1)]

    # RGBA float32 array � (height, width, 4)
    pixels = np.zeros((tex_h, tex_w, 4), dtype=np.float32)
    # Default alpha to 1 for the entire image
    pixels[:, :, 3] = 1.0

    for idx, strip in enumerate(palette.strips):
        if idx >= cols * rows:
            break

        col = idx % cols
        row = idx // cols

        cw = col_edges[col + 1] - col_edges[col]
        ch = row_edges[row + 1] - row_edges[row]

        # Grid row 0 is top of image; pixel row 0 is bottom of image.
        px_x0 = col_edges[col]
        px_y0 = tex_h - row_edges[row + 1]

        sorted_stops = sorted(strip.stops, key=lambda s: s[0])

        if strip.strip_type == StripType.FLAT:
            # Solid fill � use first stop color
            color = np.array(sorted_stops[0][1], dtype=np.float32)
            pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = color
            if getattr(strip, 'effects', None):
                cell = pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw]
                _apply_effects_np(cell, strip.effects)
        else:
            # Per-strip direction overrides palette direction
            cm = getattr(strip, 'color_mode', 'RGB')
            ip = getattr(strip, 'interpolation', 'LINEAR')
            hi = getattr(strip, 'hue_interpolation', 'NEAR')
            direction = strip.direction or palette.direction
            if direction == "Vertical":
                # Gradient top?bottom within each cell.
                t = np.linspace(1.0, 0.0, ch)
                colors = _interpolate_stops(sorted_stops, t, cm, ip, hi)  # (ch, 4)
                pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = colors.reshape(ch, 1, 4)
            else:  # Horizontal
                # Gradient left?right within each cell.
                t = np.linspace(0.0, 1.0, cw)
                colors = _interpolate_stops(sorted_stops, t, cm, ip, hi)  # (cw, 4)
                pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw] = colors.reshape(1, cw, 4)
            if getattr(strip, 'effects', None):
                cell = pixels[px_y0:px_y0 + ch, px_x0:px_x0 + cw]
                _apply_effects_np(cell, strip.effects)

    # Write pixels to Blender image
    img.pixels.foreach_set(pixels.ravel())
    img.update()
    img.gl_free()  # Force GPU texture re-upload on next draw

    # Cache the buffer for fast update_strip calls
    _pixel_cache[palette.id] = (tex_w, tex_h, pixels)
