# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Copy/paste operators and context menu for strips."""

import json
import bpy

from .state import app_state
from .data import SPStrip, StripType
from .texture import update_strip

_FORMAT_TAG = "palette_grid_strip"
_VERSION = 1

# Set by right-click handler before opening the menu
_target_index: int = -1


def _serialize_strip(strip: SPStrip, palette_direction: str | None = None) -> str:
    """Serialize a strip to clipboard JSON."""
    effective_direction = None
    if strip.strip_type == StripType.GRADIENT:
        effective_direction = strip.direction or palette_direction
    return json.dumps({
        "format": _FORMAT_TAG,
        "version": _VERSION,
        "strip": strip.to_dict(),
        "effective_direction": effective_direction,
    }, separators=(",", ":"))


def _deserialize_strip(text: str):
    """Deserialize clipboard JSON to an SPStrip. Returns (strip, effective_direction)."""
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("format") != _FORMAT_TAG:
        return None
    strip_data = data.get("strip")
    if not isinstance(strip_data, dict):
        return None
    try:
        return SPStrip.from_dict(strip_data), data.get("effective_direction")
    except (KeyError, TypeError, ValueError):
        return None


class PALETTE_OT_copy_strip(bpy.types.Operator):
    """Copy the selected strip to clipboard"""
    bl_idname = "palette_grid.copy_strip"
    bl_label = "Copy Strip"

    def execute(self, context):
        palette = app_state.active_palette
        if palette is None:
            self.report({'WARNING'}, "No active palette")
            return {'CANCELLED'}
        idx = _target_index if _target_index >= 0 else app_state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            self.report({'WARNING'}, "No strip selected")
            return {'CANCELLED'}
        strip = palette.strips[idx]
        context.window_manager.clipboard = _serialize_strip(strip, palette.direction)
        self.report({'INFO'}, f"Copied '{strip.name}'")
        return {'FINISHED'}


class PALETTE_OT_paste_strip(bpy.types.Operator):
    """Paste a strip from clipboard"""
    bl_idname = "palette_grid.paste_strip"
    bl_label = "Paste Strip"

    def execute(self, context):
        palette = app_state.active_palette
        if palette is None:
            self.report({'WARNING'}, "No active palette")
            return {'CANCELLED'}
        clip = context.window_manager.clipboard or ""
        payload = _deserialize_strip(clip)
        if payload is None:
            self.report({'WARNING'}, "No strip data in clipboard")
            return {'CANCELLED'}
        strip, effective_direction = payload
        idx = app_state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            self.report({'WARNING'}, "No strip selected to paste onto")
            return {'CANCELLED'}
        target = palette.strips[idx]
        target_was_flat = (target.strip_type == StripType.FLAT)
        # Replace the selected strip's content (keeps grid size intact, preserves name)
        target.strip_type = strip.strip_type
        target.stops = list(strip.stops)
        if target_was_flat and strip.strip_type == StripType.GRADIENT:
            target.direction = strip.direction or effective_direction
        else:
            target.direction = strip.direction
        target.color_mode = strip.color_mode
        target.interpolation = strip.interpolation
        target.hue_interpolation = strip.hue_interpolation
        target.effects = dict(getattr(strip, 'effects', {}))
        update_strip(palette, idx)
        app_state.notify()
        from . import overlay
        overlay.tag_redraw()
        self.report({'INFO'}, f"Pasted onto '{target.name}'")
        return {'FINISHED'}


class PALETTE_MT_strip_context(bpy.types.Menu):
    bl_idname = "PALETTE_MT_strip_context"
    bl_label = "Strip"

    def draw(self, context):
        layout = self.layout
        layout.operator("palette_grid.copy_strip", icon='COPYDOWN')
        layout.operator("palette_grid.paste_strip", icon='PASTEDOWN')


_classes = [PALETTE_OT_copy_strip, PALETTE_OT_paste_strip, PALETTE_MT_strip_context]


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
