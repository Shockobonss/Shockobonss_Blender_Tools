# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Gradient Editor popup � interactive color gradient editing.

Opened from the Edit button on a StripDataList item. Provides:
- Gradient strip with draggable control points
- SV color picker, hue slider, transparency slider
- Hex input, position display, last-used colors
"""
import os
import colorsys

from .. import bgui
from ..bgui.theme import DesignTokens as DT
from ..bgui.core import Rect, Style, Widget, ui_scale

_ASSETS = os.path.join(os.path.dirname(__file__), "assets")
_BGUI_ASSETS = os.path.join(os.path.dirname(os.path.dirname(__file__)), "bgui", "assets")

# -- Colors ------------------------------------------------
POPUP_BG   = (0.04, 0.04, 0.043, 1.0)
CONTAINER  = (0.18, 0.18, 0.20, 1.0)
INPUT_BG   = (0.30, 0.30, 0.34, 1.0)
INPUT_BORDER = (0.39, 0.39, 0.42, 1.0)
TEXT_COLOR  = (0.91, 0.90, 0.90, 1.0)
SEPARATOR  = (0.39, 0.39, 0.39, 1.0)
SLIDER_BORDER = (0.30, 0.30, 0.34, 1.0)
WHITE      = (1.0, 1.0, 1.0, 1.0)
BLACK      = (0.0, 0.0, 0.0, 1.0)
TRANSPARENT = (0.0, 0.0, 0.0, 0.0)


def parse_clipboard_color(text: str):
    """Try to parse clipboard text as a color. Returns (r,g,b,a) or None.

    Supported formats:
      - [0.05, 0.05, 0.05, 1.0]  (Blender float array)
      - #F54927 or F54927         (hex code)
      - (255, 100, 50)            (int RGB)
    """
    text = text.strip()
    # Blender-style list: [r, g, b, a] or [r, g, b]
    if text.startswith('[') and text.endswith(']'):
        try:
            vals = [float(v.strip()) for v in text[1:-1].split(',')]
            if len(vals) == 3:
                return (vals[0], vals[1], vals[2], 1.0)
            if len(vals) == 4:
                return tuple(vals)
        except (ValueError, IndexError):
            pass
    # Tuple-style: (r, g, b) or (r, g, b, a)
    if text.startswith('(') and text.endswith(')'):
        try:
            vals = [float(v.strip()) for v in text[1:-1].split(',')]
            if len(vals) >= 3:
                # Detect integer 0-255 range
                if all(v == int(v) and v > 1.0 for v in vals[:3]):
                    r, g, b = vals[0] / 255, vals[1] / 255, vals[2] / 255
                    a = vals[3] / 255 if len(vals) > 3 and vals[3] > 1.0 else (vals[3] if len(vals) > 3 else 1.0)
                    return (r, g, b, a)
                if len(vals) == 3:
                    return (vals[0], vals[1], vals[2], 1.0)
                if len(vals) == 4:
                    return tuple(vals)
        except (ValueError, IndexError):
            pass
    # Hex code: #F54927 or F54927
    raw = text.lstrip('#')
    if len(raw) == 6:
        try:
            ri = int(raw[0:2], 16)
            gi = int(raw[2:4], 16)
            bi = int(raw[4:6], 16)
            return (ri / 255.0, gi / 255.0, bi / 255.0, 1.0)
        except ValueError:
            pass
    if len(raw) == 8:
        try:
            ri = int(raw[0:2], 16)
            gi = int(raw[2:4], 16)
            bi = int(raw[4:6], 16)
            ai = int(raw[6:8], 16)
            return (ri / 255.0, gi / 255.0, bi / 255.0, ai / 255.0)
        except ValueError:
            pass
    return None


# -- Shared Last-Used Colors (module-level) ---------------

def _hue_diff(h0, h1, mode):
    """Compute hue delta for interpolation, matching Blender's colorband logic."""
    dh = h1 - h0
    if mode == 'NEAR':
        if dh > 0.5:
            dh -= 1.0
        elif dh < -0.5:
            dh += 1.0
    elif mode == 'FAR':
        if h0 == h1:
            dh = 1.0
        elif 0.0 < dh < 0.5:
            dh -= 1.0
        elif -0.5 < dh < 0.0:
            dh += 1.0
    elif mode == 'CW':
        if dh < 0.0:
            dh += 1.0
    elif mode == 'CCW':
        if dh > 0.0:
            dh -= 1.0
    return dh


def _rgb_to_hsl(r, g, b):
    """Convert RGB to HSL. Returns (h, s, l) in [0,1]."""
    mx = max(r, g, b)
    mn = min(r, g, b)
    l = (mx + mn) / 2.0
    if mx == mn:
        return (0.0, 0.0, l)
    d = mx - mn
    s = d / (2.0 - mx - mn) if l > 0.5 else d / (mx + mn)
    if mx == r:
        h = (g - b) / d + (6.0 if g < b else 0.0)
    elif mx == g:
        h = (b - r) / d + 2.0
    else:
        h = (r - g) / d + 4.0
    return (h / 6.0, s, l)


def _hsl_to_rgb(h, s, l):
    """Convert HSL to RGB. Returns (r, g, b) in [0,1]."""
    if s == 0.0:
        return (l, l, l)
    def hue2rgb(p, q, t):
        if t < 0.0: t += 1.0
        if t > 1.0: t -= 1.0
        if t < 1/6: return p + (q - p) * 6.0 * t
        if t < 1/2: return q
        if t < 2/3: return p + (q - p) * (2/3 - t) * 6.0
        return p
    q = l * (1.0 + s) if l < 0.5 else l + s - l * s
    p = 2.0 * l - q
    return (hue2rgb(p, q, h + 1/3), hue2rgb(p, q, h), hue2rgb(p, q, h - 1/3))


def _interp_hsv_hsl(c1, c2, frac, mode, hue_mode):
    """Interpolate two RGBA colors in HSV or HSL space with hue wrapping."""
    r0, g0, b0, a0 = c1[:4]
    r1, g1, b1, a1 = c2[:4]
    if mode == 'HSV':
        h0, s0, v0 = colorsys.rgb_to_hsv(r0, g0, b0)
        h1, s1, v1 = colorsys.rgb_to_hsv(r1, g1, b1)
        dh = _hue_diff(h0, h1, hue_mode)
        h = (h0 + dh * frac) % 1.0
        s = s0 + (s1 - s0) * frac
        v = v0 + (v1 - v0) * frac
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
    else:  # HSL
        h0, s0, l0 = _rgb_to_hsl(r0, g0, b0)
        h1, s1, l1 = _rgb_to_hsl(r1, g1, b1)
        dh = _hue_diff(h0, h1, hue_mode)
        h = (h0 + dh * frac) % 1.0
        s = s0 + (s1 - s0) * frac
        l = l0 + (l1 - l0) * frac
        r, g, b = _hsl_to_rgb(h, s, l)
    a = a0 + (a1 - a0) * frac
    return (r, g, b, a)

_shared_last_used = [
    (0.0, 0.0, 0.0, 1.0),
    (0.0, 0.48, 1.0, 1.0),
    (0.20, 0.78, 0.35, 1.0),
    (1.0, 0.80, 0.0, 1.0),
    (1.0, 0.23, 0.19, 1.0),
    (0.48, 0.78, 0.96, 1.0),
]

# -- Gradient State ----------------------------------------

class GradientStop:
    """A single stop in the gradient."""
    __slots__ = ('position', 'color')

    def __init__(self, position: float, color: tuple):
        self.position = position   # 0.0 - 1.0
        self.color = color         # (r, g, b, a)


class GradientState:
    """Central state for the gradient editor."""

    def __init__(self):
        self.stops = [
            GradientStop(0.0, (1.0, 0.43, 0.23, 1.0)),
            GradientStop(1.0, (1.0, 0.82, 0.09, 1.0)),
        ]
        self.selected_index = 0
        self.hue = 0.1          # 0-1
        self.saturation = 0.85  # 0-1
        self.value = 0.85       # 0-1
        self.opacity = 1.0      # 0-1
        self.color_mode = 'RGB'           # 'RGB', 'HSV', 'HSL'
        self.interpolation = 'LINEAR'     # 'LINEAR', 'EASE', 'CARDINAL', 'B_SPLINE', 'CONSTANT'
        self.hue_interpolation = 'NEAR'   # 'NEAR', 'FAR', 'CW', 'CCW' (HSV/HSL only)
        self.effects = {}                 # Non-destructive effects: {"gamma": 1.0, ...}
        self.last_used = _shared_last_used
        self._listeners = []
        self._undo_stack = []
        self._redo_stack = []
        self._max_undo = 50

    def add_listener(self, fn):
        self._listeners.append(fn)

    def notify(self):
        for fn in self._listeners:
            fn(self)

    def _snapshot(self):
        """Capture current state as a serializable dict."""
        return {
            'stops': [(s.position, s.color) for s in self.stops],
            'selected_index': self.selected_index,
            'hue': self.hue,
            'saturation': self.saturation,
            'value': self.value,
            'opacity': self.opacity,
            'color_mode': self.color_mode,
            'interpolation': self.interpolation,
            'hue_interpolation': self.hue_interpolation,
            'effects': dict(self.effects),
        }

    def _restore(self, snap):
        """Restore state from a snapshot dict."""
        self.stops = [GradientStop(p, c) for p, c in snap['stops']]
        self.selected_index = snap['selected_index']
        self.hue = snap['hue']
        self.saturation = snap['saturation']
        self.value = snap['value']
        self.opacity = snap['opacity']
        self.color_mode = snap.get('color_mode', 'RGB')
        self.interpolation = snap.get('interpolation', 'LINEAR')
        self.hue_interpolation = snap.get('hue_interpolation', 'NEAR')
        self.effects = snap.get('effects', {})
        self.notify()

    def push_undo(self):
        """Save current state to undo stack (call before a change)."""
        self._undo_stack.append(self._snapshot())
        if len(self._undo_stack) > self._max_undo:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def undo(self):
        """Revert to previous state."""
        if not self._undo_stack:
            return
        self._redo_stack.append(self._snapshot())
        self._restore(self._undo_stack.pop())

    def redo(self):
        """Re-apply a previously undone state."""
        if not self._redo_stack:
            return
        self._undo_stack.append(self._snapshot())
        self._restore(self._redo_stack.pop())

    @property
    def selected_stop(self):
        if 0 <= self.selected_index < len(self.stops):
            return self.stops[self.selected_index]
        return None

    def color_at(self, t: float) -> tuple:
        """Interpolate gradient color at position t (0-1)."""
        if not self.stops:
            return (0, 0, 0, 1)
        stops = sorted(self.stops, key=lambda s: s.position)
        if t <= stops[0].position:
            return stops[0].color
        if t >= stops[-1].position:
            return stops[-1].color
        for i in range(len(stops) - 1):
            if stops[i].position <= t <= stops[i + 1].position:
                span = stops[i + 1].position - stops[i].position
                if span < 1e-6:
                    return stops[i].color
                frac = (t - stops[i].position) / span

                # Apply interpolation curve
                ip = self.interpolation
                if ip == 'CONSTANT':
                    return stops[i].color
                elif ip == 'EASE':
                    frac = frac * frac * (3.0 - 2.0 * frac)
                elif ip == 'B_SPLINE':
                    frac = frac * frac * frac * (frac * (frac * 6.0 - 15.0) + 10.0)

                c1, c2 = stops[i].color, stops[i + 1].color
                cm = self.color_mode
                if cm == 'RGB':
                    return tuple(c1[j] + (c2[j] - c1[j]) * frac for j in range(4))
                else:
                    return _interp_hsv_hsl(c1, c2, frac, cm, self.hue_interpolation)
        return stops[-1].color

    def update_selected_color_from_hsv(self):
        r, g, b = colorsys.hsv_to_rgb(self.hue, self.saturation, self.value)
        stop = self.selected_stop
        if stop:
            stop.color = (r, g, b, self.opacity)
            self.notify()

    def select_stop(self, index):
        self.selected_index = index
        stop = self.selected_stop
        if stop:
            r, g, b = stop.color[:3]
            h, s, v = colorsys.rgb_to_hsv(r, g, b)
            self.hue = h
            self.saturation = s
            self.value = v
            self.opacity = stop.color[3] if len(stop.color) > 3 else 1.0
        self.notify()

    def add_stop(self):
        self.push_undo()
        stop = self.selected_stop
        pos = stop.position + 0.1 if stop else 0.5
        pos = min(1.0, max(0.0, pos))
        color = self.color_at(pos)
        self.stops.append(GradientStop(pos, color))
        self.selected_index = len(self.stops) - 1
        self.notify()

    def remove_selected(self):
        if len(self.stops) <= 2:
            return  # Keep at least 2 stops
        self.push_undo()
        if 0 <= self.selected_index < len(self.stops):
            self.stops.pop(self.selected_index)
            self.selected_index = min(self.selected_index, len(self.stops) - 1)
            self.select_stop(self.selected_index)

    def distribute_evenly(self):
        """Redistribute all stop positions at equal intervals."""
        n = len(self.stops)
        if n < 2:
            return
        self.push_undo()
        sorted_stops = sorted(self.stops, key=lambda s: s.position)
        if self.color_mode == 'RGB' and self.interpolation == 'CONSTANT':
            # In constant RGB mode, each stop marks the start of a flat color band.
            # Even spacing should therefore create N equal bands, not N-1 equal spans.
            for i, stop in enumerate(sorted_stops):
                stop.position = i / n
        else:
            for i, stop in enumerate(sorted_stops):
                stop.position = i / (n - 1)
        self.notify()

    def adjust_channel(self, channel: int, value: float):
        """Set a color channel (0=R, 1=G, 2=B) of the selected stop."""
        stop = self.selected_stop
        if stop is None:
            return
        c = list(stop.color)
        c[channel] = max(0.0, min(1.0, value))
        stop.color = tuple(c)
        r, g, b = stop.color[:3]
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        self.hue = h
        self.saturation = s
        self.value = v
        self.notify()

    def set_effect(self, key: str, value):
        """Set a non-destructive effect value."""
        from ..core.effects import EFFECT_DEFAULTS
        default = EFFECT_DEFAULTS.get(key)
        if value == default:
            self.effects.pop(key, None)
        else:
            self.effects[key] = value
        self.notify()

    def push_last_used(self, color):
        """Add a color to the shared last-used list (deduplicated, max 6)."""
        # Round to avoid float drift duplicates
        def _key(c):
            return tuple(round(x, 3) for x in c[:4])
        k = _key(color)
        # Remove existing duplicate
        self.last_used[:] = [c for c in self.last_used if _key(c) != k]
        # Prepend
        self.last_used.insert(0, color)
        # Trim to 6
        del self.last_used[6:]


# -- Custom Widgets ----------------------------------------

def _apply_fx(grad_stops, effects):
    """Apply effects pipeline to a list of (position, (r,g,b,a)) gradient stops."""
    if not effects:
        return grad_stops
    from ..core.effects import apply_pipeline_rgba
    return [(pos, apply_pipeline_rgba(color, effects)) for pos, color in grad_stops]


class _GradientStripWidget(Widget):
    """Horizontal gradient bar with draggable control points."""
    _POINT_SIZE = 19
    _BORDER_W = 2

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._dragging = -1

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        bar = Rect(cr.x, cr.y, cr.width, cr.height)

        # Build stop list, extending first/last colors to edges
        stops = sorted(self.gstate.stops, key=lambda s: s.position)
        if len(stops) >= 2:
            gs = self.gstate
            is_linear_rgb = (gs.color_mode == 'RGB' and
                             gs.interpolation == 'LINEAR')
            if gs.interpolation == 'CONSTANT':
                # Hard-edge step function: duplicate stops at boundaries
                grad_stops = []
                for si, s in enumerate(stops):
                    c = s.color
                    if si > 0:
                        grad_stops.append((s.position, stops[si - 1].color))
                    grad_stops.append((s.position, c))
                if grad_stops[0][0] > 0.0:
                    grad_stops.insert(0, (0.0, grad_stops[0][1]))
                if grad_stops[-1][0] < 1.0:
                    grad_stops.append((1.0, grad_stops[-1][1]))
            elif not is_linear_rgb:
                # Sample via color_at() � shader supports max 16 stops
                n = 15
                grad_stops = []
                for si in range(n + 1):
                    t = si / n
                    c = gs.color_at(t)
                    grad_stops.append((t, c))
            else:
                grad_stops = [(s.position, s.color) for s in stops]
                if grad_stops[0][0] > 0.0:
                    grad_stops.insert(0, (0.0, grad_stops[0][1]))
                if grad_stops[-1][0] < 1.0:
                    grad_stops.append((1.0, grad_stops[-1][1]))

            renderer.draw_multi_stop_gradient(
                bar, _apply_fx(grad_stops, self.gstate.effects), 13 * sc,
                gradient_angle=0.0,
                border_color=SLIDER_BORDER,
                border_width=self._BORDER_W * sc,
            )
        elif len(stops) == 1:
            from ..core.effects import apply_pipeline_rgba
            c = apply_pipeline_rgba(stops[0].color, self.gstate.effects)
            renderer.draw_rounded_rect(
                bar, c, 13 * sc,
                border_color=SLIDER_BORDER, border_width=self._BORDER_W * sc,
            )
        else:
            renderer.draw_rounded_rect(
                bar, TRANSPARENT, 13 * sc,
                border_color=SLIDER_BORDER, border_width=self._BORDER_W * sc,
            )

        # Control points � clamped with margin inside the rounded bar
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        usable = bar.width - ps - margin * 2
        sorted_stops = sorted(enumerate(self.gstate.stops),
                              key=lambda t: t[1].position)
        for orig_i, stop in sorted_stops:
            cx = bar.x + margin + stop.position * usable
            cy = bar.y + (bar.height - ps) / 2
            # Circle background
            renderer.draw_rounded_rect(
                Rect(cx, cy, ps, ps), stop.color, ps / 2,
            )
            # White stroke � thicker for selected
            bw = 2.0 * sc if orig_i == self.gstate.selected_index else 1.5 * sc
            renderer.draw_rounded_rect(
                Rect(cx, cy, ps, ps), TRANSPARENT, ps / 2,
                border_color=WHITE, border_width=bw,
            )

    def _hit_point(self, x, y):
        """Return index of control point at (x, y), or -1."""
        cr = self.content_rect
        sc = ui_scale()
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        usable = cr.width - ps - margin * 2
        stops = sorted(enumerate(self.gstate.stops),
                       key=lambda t: t[1].position)
        for orig_i, stop in reversed(stops):
            cx = cr.x + margin + ps / 2 + stop.position * usable
            cy = cr.y + cr.height / 2
            if abs(x - cx) <= ps and abs(y - cy) <= ps:
                return orig_i
        return -1

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        idx = self._hit_point(x, y)
        if idx >= 0:
            self.gstate.push_undo()
            self.gstate.select_stop(idx)
            self._dragging = idx
        return True

    def handle_mouse_release(self, x, y):
        self._dragging = -1
        return False

    def propagate_mouse_move(self, x, y):
        super().propagate_mouse_move(x, y)
        if self._dragging >= 0 and self.rect:
            cr = self.content_rect
            sc = ui_scale()
            ps = self._POINT_SIZE * sc
            margin = 3 * sc
            usable = cr.width - ps - margin * 2
            t = (x - cr.x - margin - ps / 2) / max(usable, 1)
            t = max(0.0, min(1.0, t))
            self.gstate.stops[self._dragging].position = t
            self.gstate.notify()


class _SVPickerWidget(Widget):
    """2D saturation/value color picker box."""
    _POINT_SIZE = 17

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._dragging = False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        # Layer 1: white ? hue color (horizontal gradient)
        hue_r, hue_g, hue_b = colorsys.hsv_to_rgb(self.gstate.hue, 1.0, 1.0)
        hue_color = (hue_r, hue_g, hue_b, 1.0)
        renderer.draw_rounded_rect(
            cr, WHITE, 8 * sc,
            color2=hue_color, gradient_angle=0.0,
        )
        # Layer 2: black at bottom ? near-transparent at top
        # (note: color2.a must be > 0 for the shader to activate gradient mode)
        renderer.draw_rounded_rect(
            cr, BLACK, 8 * sc,
            color2=(0.0, 0.0, 0.0, 0.002), gradient_angle=90.0,
        )

        # Picker point � clamped inside rect with visual margin
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        usable_w = cr.width - ps - margin * 2
        usable_h = cr.height - ps - margin * 2
        px = cr.x + margin + self.gstate.saturation * usable_w
        py = cr.y + margin + (1.0 - self.gstate.value) * usable_h
        sel_color = colorsys.hsv_to_rgb(
            self.gstate.hue, self.gstate.saturation, self.gstate.value)
        renderer.draw_rounded_rect(
            Rect(px, py, ps, ps), (*sel_color, 1.0), ps / 2,
        )
        renderer.draw_rounded_rect(
            Rect(px, py, ps, ps), TRANSPARENT, ps / 2,
            border_color=WHITE, border_width=1.0 * sc,
        )

    def _update_from_xy(self, x, y):
        cr = self.content_rect
        sc = ui_scale()
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        usable_w = cr.width - ps - margin * 2
        usable_h = cr.height - ps - margin * 2
        s = (x - cr.x - margin - ps / 2) / max(usable_w, 1)
        v = 1.0 - (y - cr.y - margin - ps / 2) / max(usable_h, 1)
        self.gstate.saturation = max(0.0, min(1.0, s))
        self.gstate.value = max(0.0, min(1.0, v))
        self.gstate.update_selected_color_from_hsv()

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        self.gstate.push_undo()
        self._dragging = True
        self._update_from_xy(x, y)
        return True

    def handle_mouse_release(self, x, y):
        self._dragging = False
        return False

    def propagate_mouse_move(self, x, y):
        super().propagate_mouse_move(x, y)
        if self._dragging:
            self._update_from_xy(x, y)


class _VerticalSlider(Widget):
    """Base for vertical slider bars (hue, transparency)."""
    _POINT_SIZE = 19

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._dragging = False

    def _get_value(self) -> float:
        """Override: return 0-1 value for the slider."""
        return 0.0

    def _set_value(self, v: float):
        """Override: set value from 0-1."""
        pass

    def _draw_bar(self, renderer, cr):
        """Override: draw the slider background."""
        pass

    def _point_color(self) -> tuple:
        """Override: color of the control point."""
        return WHITE

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        self._draw_bar(renderer, cr)

        # Border
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 13 * sc,
            border_color=SLIDER_BORDER, border_width=2 * sc,
        )

        # Control point � clamped with margin inside the rounded bar
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        val = self._get_value()
        usable = cr.height - ps - margin * 2
        py = cr.y + margin + val * usable
        px = cr.x + (cr.width - ps) / 2
        renderer.draw_rounded_rect(
            Rect(px, py, ps, ps), self._point_color(), ps / 2,
        )
        renderer.draw_rounded_rect(
            Rect(px, py, ps, ps), TRANSPARENT, ps / 2,
            border_color=WHITE, border_width=1.5 * sc,
        )

    def _update_from_y(self, y):
        cr = self.content_rect
        sc = ui_scale()
        ps = self._POINT_SIZE * sc
        margin = 3 * sc
        usable = cr.height - ps - margin * 2
        v = (y - cr.y - margin - ps / 2) / max(usable, 1)
        v = max(0.0, min(1.0, v))
        self._set_value(v)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        self.gstate.push_undo()
        self._dragging = True
        self._update_from_y(y)
        return True

    def handle_mouse_release(self, x, y):
        self._dragging = False
        return False

    def propagate_mouse_move(self, x, y):
        super().propagate_mouse_move(x, y)
        if self._dragging:
            self._update_from_y(y)


class _HueSlider(_VerticalSlider):
    """Vertical hue slider using hue_strip.png."""

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(state, **kwargs)
        self._hue_img = None
        self._img_loaded = False

    def _get_value(self) -> float:
        return self.gstate.hue

    def _set_value(self, v: float):
        self.gstate.hue = v
        self.gstate.update_selected_color_from_hsv()

    def _point_color(self) -> tuple:
        r, g, b = colorsys.hsv_to_rgb(self.gstate.hue, 1.0, 1.0)
        return (r, g, b, 1.0)

    def _draw_bar(self, renderer, cr):
        if not self._img_loaded:
            self._img_loaded = True
            self._hue_img = bgui.load_ui_image(
                os.path.join(_ASSETS, "hue_strip.png"))
        if self._hue_img:
            renderer.draw_image(self._hue_img, cr, border_radius=13 * ui_scale())


class _TransparencySlider(_VerticalSlider):
    """Vertical transparency slider with checkerboard bg."""

    def __init__(self, state, **kwargs):
        super().__init__(state, **kwargs)
        self._checker_img = None
        self._checker_loaded = False

    def _get_value(self) -> float:
        return 1.0 - self.gstate.opacity

    def _set_value(self, v: float):
        self.gstate.opacity = 1.0 - v
        self.gstate.update_selected_color_from_hsv()

    def _point_color(self) -> tuple:
        stop = self.gstate.selected_stop
        if stop:
            r, g, b = stop.color[:3]
            return (r, g, b, 1.0)
        return WHITE

    def _draw_bar(self, renderer, cr):
        # Checkerboard background image (masked by border_radius, cover fit)
        if not self._checker_loaded:
            self._checker_loaded = True
            path = os.path.join(_ASSETS, "TransparencySliderFillImageBackground.png")
            if os.path.exists(path):
                self._checker_img = bgui.load_ui_image(path)
        if self._checker_img:
            renderer.draw_image(self._checker_img, cr, border_radius=13 * ui_scale(), fit='cover',
                                opacity=0.7)

        # Gradient overlay: transparent black at bottom ? full color at top
        # color2 (top) has alpha=1.0, which passes the shader gate (v_fill_color_2.a > 0)
        stop = self.gstate.selected_stop
        full_color = stop.color[:3] + (1.0,) if stop else (1.0, 1.0, 1.0, 1.0)
        renderer.draw_rounded_rect(
            cr, (0.0, 0.0, 0.0, 0.0), 13 * ui_scale(),
            color2=full_color, gradient_angle=90.0,
        )


class _ColorLump(Widget):
    """Small preview square showing a color."""

    def __init__(self, color: tuple, state: GradientState = None,
                 lump_index: int = 0, **kwargs):
        super().__init__(**kwargs)
        self.color = color
        self.gstate = state
        self._lump_index = lump_index

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        # Read color dynamically from the shared last_used list
        color = self.color
        if self.gstate and 0 <= self._lump_index < len(self.gstate.last_used):
            color = self.gstate.last_used[self._lump_index]
            self.color = color
        renderer.draw_rounded_rect(cr, color, 4 * sc)
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=(0.93, 0.93, 0.93, 1.0), border_width=1.5 * sc,
        )

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        if self.gstate:
            self.gstate.push_undo()
            stop = self.gstate.selected_stop
            if stop:
                stop.color = self.color
                r, g, b = self.color[:3]
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                self.gstate.hue = h
                self.gstate.saturation = s
                self.gstate.value = v
                self.gstate.notify()
        return True


# -- Tool buttons (small icon buttons) ---------------------

class _ToolButton(Widget):
    """Small 18�17 icon button used in the tool row."""

    def __init__(self, icon_path: str, on_click=None, **kwargs):
        super().__init__(**kwargs)
        self._icon_path = icon_path
        self._icon_img = None
        self._icon_loaded = False
        self.on_click = on_click

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        # Background
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=INPUT_BORDER, border_width=1 * sc,
        )
        # Icon centered
        if not self._icon_loaded:
            self._icon_loaded = True
            if os.path.exists(self._icon_path):
                self._icon_img = bgui.load_ui_image(
                    self._icon_path, svg_size=32, svg_color=WHITE)
        if self._icon_img:
            s = 12 * sc
            ix = cr.x + (cr.width - s) / 2
            iy = cr.y + (cr.height - s) / 2
            renderer.draw_image(self._icon_img, Rect(ix, iy, s, s))

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        if self.on_click:
            self.on_click(self)
        return True


class _DragHandle(Widget):
    """Three-dots icon that lets the user drag the popup to reposition it."""

    def __init__(self, popup_ref, **kwargs):
        super().__init__(**kwargs)
        self._popup_ref = popup_ref  # mutable [popup] list
        self._dragging = False
        self._drag_start_mx = 0.0
        self._drag_start_my = 0.0
        self._drag_start_ox = 0.0
        self._drag_start_oy = 0.0
        self._icon_img = None
        self._icon_loaded = False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        if not self._icon_loaded:
            self._icon_loaded = True
            path = os.path.join(_BGUI_ASSETS, "threepoints.svg")
            if os.path.exists(path):
                self._icon_img = bgui.load_ui_image(
                    path, svg_size=32, svg_color=(0.55, 0.55, 0.55, 1.0))
        if self._icon_img:
            sc = ui_scale()
            s = 16 * sc
            ix = cr.x + (cr.width - s) / 2
            iy = cr.y + (cr.height - s) / 2
            renderer.draw_image(self._icon_img, Rect(ix, iy, s, s))

    def handle_mouse_press(self, x, y):
        if not self.visible or not self.rect or not self.rect.contains(x, y):
            return False
        popup = self._popup_ref[0]
        if popup:
            self._dragging = True
            self._drag_start_mx = x
            self._drag_start_my = y
            self._drag_start_ox = popup._drag_offset_x
            self._drag_start_oy = popup._drag_offset_y
        return True

    def handle_mouse_release(self, x, y):
        if self._dragging:
            self._dragging = False
            return True
        return False

    def propagate_mouse_move(self, x, y):
        super().propagate_mouse_move(x, y)
        if self._dragging:
            popup = self._popup_ref[0]
            if popup:
                dx = x - self._drag_start_mx
                dy = y - self._drag_start_my
                popup._drag_offset_x = self._drag_start_ox + dx
                popup._drag_offset_y = self._drag_start_oy + dy
                popup._needs_layout = True
                popup.invalidate()


# -- Effect Value Input ------------------------------------

class _EffectValueInput(Widget):
    """Small numeric input for an effect slider value.

    Click to type a value, press Enter/blur to apply.
    """

    def __init__(self, precision=2, suffix="", on_commit=None, **kwargs):
        super().__init__(**kwargs)
        self._precision = precision
        self._suffix = suffix
        self._on_commit = on_commit
        self._editing = False
        self._buf = ""
        self._cursor_pos = 0
        self._sel_start = None
        self._display_value = 0.0

    def set_display(self, value):
        self._display_value = value
        if not self._editing:
            self._buf = f"{value:.{self._precision}f}"

    def _start_edit(self):
        self._buf = f"{self._display_value:.{self._precision}f}"
        self._cursor_pos = len(self._buf)
        self._sel_start = 0  # select all
        self._editing = True
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        if self._editing:
            self._commit()

    def _commit(self):
        from ..bgui.core import unregister_editing
        self._editing = False
        unregister_editing(self)
        try:
            val = float(self._buf)
        except ValueError:
            return
        if self._on_commit:
            self._on_commit(val)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            if self._editing:
                self._commit()
            return False
        if not self._editing:
            self._start_edit()
        return True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        if not self._editing:
            return False
        if key == 'RET':
            self._commit()
            return True
        if key == 'ESC':
            from ..bgui.core import unregister_editing
            self._editing = False
            unregister_editing(self)
            return True

        # Select-all
        if ctrl and key == 'A':
            self._sel_start = 0
            self._cursor_pos = len(self._buf)
            return True

        # Clipboard
        if ctrl and key == 'C':
            import bpy
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                bpy.context.window_manager.clipboard = self._buf[s:e]
            else:
                bpy.context.window_manager.clipboard = self._buf
            return True
        if ctrl and key == 'X':
            import bpy
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                bpy.context.window_manager.clipboard = self._buf[s:e]
                self._del_sel()
            else:
                bpy.context.window_manager.clipboard = self._buf
                self._buf = ""
                self._cursor_pos = 0
            return True
        if ctrl and key == 'V':
            import bpy
            clip = bpy.context.window_manager.clipboard or ""
            clip = ''.join(c for c in clip if c in '0123456789.-')
            if clip:
                self._del_sel()
                self._buf = self._buf[:self._cursor_pos] + clip + self._buf[self._cursor_pos:]
                self._cursor_pos += len(clip)
            return True

        # Navigation / selection
        if key == 'LEFT':
            if self._cursor_pos > 0:
                if shift:
                    if self._sel_start is None:
                        self._sel_start = self._cursor_pos
                else:
                    self._sel_start = None
                self._cursor_pos -= 1
            return True
        if key == 'RIGHT':
            if self._cursor_pos < len(self._buf):
                if shift:
                    if self._sel_start is None:
                        self._sel_start = self._cursor_pos
                else:
                    self._sel_start = None
                self._cursor_pos += 1
            return True
        if key == 'HOME':
            self._cursor_pos = 0
            if not shift:
                self._sel_start = None
            return True
        if key == 'END':
            self._cursor_pos = len(self._buf)
            if not shift:
                self._sel_start = None
            return True

        # Deletion
        if key == 'BACK_SPACE':
            if self._sel_start is not None:
                self._del_sel()
            elif self._cursor_pos > 0:
                self._buf = self._buf[:self._cursor_pos - 1] + self._buf[self._cursor_pos:]
                self._cursor_pos -= 1
            return True
        if key == 'DEL':
            if self._sel_start is not None:
                self._del_sel()
            elif self._cursor_pos < len(self._buf):
                self._buf = self._buf[:self._cursor_pos] + self._buf[self._cursor_pos + 1:]
            return True

        # Character input (digits, minus, dot)
        if ascii_char and not ctrl:
            self._del_sel()
            if ascii_char in '0123456789.-' and len(self._buf) < 8:
                self._buf = self._buf[:self._cursor_pos] + ascii_char + self._buf[self._cursor_pos:]
                self._cursor_pos += 1
            return True
        return False

    def _del_sel(self):
        if self._sel_start is None:
            return
        s = min(self._sel_start, self._cursor_pos)
        e = max(self._sel_start, self._cursor_pos)
        self._buf = self._buf[:s] + self._buf[e:]
        self._cursor_pos = s
        self._sel_start = None

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        from ..bgui.renderer import Renderer as R

        border_c = (0.784, 1.0, 0.0, 0.8) if self._editing else INPUT_BORDER
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        renderer.draw_rounded_rect(cr, TRANSPARENT, 4 * sc,
                                   border_color=border_c, border_width=1 * sc)

        text = self._buf + self._suffix if self._editing else f"{self._display_value:.{self._precision}f}{self._suffix}"
        tw, ref_h = R.measure_text(text, 10, font_weight='semibold')
        tx = cr.x + (cr.width - tw) / 2
        ty = cr.y + (cr.height - ref_h) / 2
        color = WHITE if self._editing else TEXT_COLOR
        renderer.draw_text(text, tx, ty, size=10,
                           color=color, font_weight='semibold',
                           ref_height=ref_h)

        if self._editing:
            before = self._buf[:self._cursor_pos]
            full_text = self._buf + self._suffix
            tw_full, _ = R.measure_text(full_text, 10, font_weight='semibold')
            tx_base = cr.x + (cr.width - tw_full) / 2
            # Selection highlight
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw, _ = R.measure_text(self._buf[:s], 10, font_weight='semibold')
                ew, _ = R.measure_text(self._buf[:e], 10, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(tx_base + sw, cr.y + 2 * sc, ew - sw, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            cw, _ = R.measure_text(before, 10, font_weight='semibold')
            renderer.draw_rounded_rect(
                Rect(tx_base + cw, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)


class _ResetButton(Widget):
    """Small clickable reset icon � resets an effect to its default value."""

    def __init__(self, on_click=None, **kwargs):
        super().__init__(**kwargs)
        self.on_click = on_click
        self._icon_img = None
        self._icon_loaded = False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        if not self._icon_loaded:
            self._icon_loaded = True
            path = os.path.join(_BGUI_ASSETS, "resetreload.svg")
            if os.path.exists(path):
                self._icon_img = bgui.load_ui_image(path, svg_size=32, svg_color=TEXT_COLOR)
        if self._icon_img:
            sc = ui_scale()
            s = 12 * sc
            ix = cr.x + (cr.width - s) / 2
            iy = cr.y + (cr.height - s) / 2
            renderer.draw_image(self._icon_img, Rect(ix, iy, s, s))

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        if self.on_click:
            self.on_click(self)
        return True


class _EffectIcon(Widget):
    """Small icon loaded from SVG, lazy-loaded on first draw."""

    def __init__(self, svg_name, **kwargs):
        super().__init__(**kwargs)
        self._svg_name = svg_name
        self._icon_img = None
        self._icon_loaded = False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        if not self._icon_loaded:
            self._icon_loaded = True
            path = os.path.join(_BGUI_ASSETS, self._svg_name)
            if os.path.exists(path):
                self._icon_img = bgui.load_ui_image(path, svg_size=32, svg_color=TEXT_COLOR)
        if self._icon_img:
            s = min(cr.width, cr.height)
            ix = cr.x + (cr.width - s) / 2
            iy = cr.y + (cr.height - s) / 2
            renderer.draw_image(self._icon_img, Rect(ix, iy, s, s))


def _build_effects_section(state: GradientState, visible: bool = True):
    """Build the shared non-destructive effects section used by both popups."""
    _fx_slider_style = bgui.Style(
        width_policy=bgui.SizePolicy.FILL, height=20, flex=1,
    )
    _fx_active = (0.784, 1.0, 0.0, 1.0)
    _adj_self_update = [False]

    def _undo_on_press(slider):
        """Patch a Slider so push_undo fires once on mouse-press, not per-tick."""
        _orig = slider.handle_mouse_press

        def _press(x, y):
            if slider.rect and slider.rect.contains(x, y):
                state.push_undo()
            return _orig(x, y)

        slider.handle_mouse_press = _press

    from ..core.effects import EFFECT_DEFAULTS

    effect_defs = [
        ("hue", "Hue", "Shift the hue of all colors", "hue.svg", -1.0, 1.0, EFFECT_DEFAULTS["hue"], 2),
        ("gamma", "Gamma", "Adjust brightness curve", "gamma.svg", 0.1, 3.0, EFFECT_DEFAULTS["gamma"], 2),
        ("contrast", "Contrast", "Adjust color contrast", "contrast.svg", -1.0, 1.0, EFFECT_DEFAULTS["contrast"], 2),
        ("saturation", "Saturation", "Adjust color saturation", "saturation.svg", -1.0, 1.0, EFFECT_DEFAULTS["saturation"], 2),
    ]

    fx_sliders = {}
    fx_inputs = {}
    fx_entries = []

    for key, label, tooltip, icon_svg, min_val, max_val, default, precision in effect_defs:
        effect_key = key
        effect_default = default
        effect_min = min_val
        effect_max = max_val

        def _make_on_change(effect_key=effect_key):
            def _on_change(widget):
                if _adj_self_update[0]:
                    return
                state.set_effect(effect_key, widget.value)

            return _on_change

        slider = bgui.Slider(
            value=default,
            min_val=min_val,
            max_val=max_val,
            precision=precision,
            active_color=_fx_active,
            on_change=_make_on_change(),
            style=_fx_slider_style,
        )
        _undo_on_press(slider)

        def _make_on_commit(effect_key=effect_key, slider=slider,
                            effect_min=effect_min, effect_max=effect_max):
            def _on_commit(value):
                value = max(effect_min, min(effect_max, value))
                _adj_self_update[0] = True
                slider.value = value
                _adj_self_update[0] = False
                state.push_undo()
                state.set_effect(effect_key, value)

            return _on_commit

        input_widget = _EffectValueInput(
            precision=precision,
            on_commit=_make_on_commit(),
            style=bgui.Style(width=42, height=20),
        )
        input_widget.set_display(default)

        def _make_on_reset(effect_key=effect_key, effect_default=effect_default,
                           slider=slider, input_widget=input_widget):
            def _on_reset(_widget):
                _adj_self_update[0] = True
                slider.value = effect_default
                input_widget.set_display(effect_default)
                _adj_self_update[0] = False
                state.push_undo()
                state.set_effect(effect_key, effect_default)

            return _on_reset

        reset_btn = _ResetButton(
            on_click=_make_on_reset(),
            style=bgui.Style(width=18, height=18),
            tooltip="Reset to default",
        )

        fx_entries.append(
            bgui.Column(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    gap=3,
                ),
                children=[
                    bgui.Row(
                        style=bgui.Style(
                            width_policy=bgui.SizePolicy.FILL,
                            gap=5,
                            alignment=bgui.Alignment.CENTER,
                        ),
                        children=[
                            _EffectIcon(icon_svg, style=bgui.Style(width=14, height=14)),
                            bgui.Label(label, style=bgui.Style(
                                font_size=12, font_weight="semibold", font_color=TEXT_COLOR,
                            )),
                        ],
                        tooltip=tooltip,
                    ),
                    bgui.Row(
                        style=bgui.Style(
                            width_policy=bgui.SizePolicy.FILL,
                            gap=5,
                            alignment=bgui.Alignment.CENTER,
                        ),
                        children=[slider, input_widget, reset_btn],
                    ),
                ],
            )
        )

        fx_sliders[key] = slider
        fx_inputs[key] = input_widget

    def _sync_effects(st):
        _adj_self_update[0] = True
        for effect_key, input_widget in fx_inputs.items():
            value = st.effects.get(effect_key, EFFECT_DEFAULTS[effect_key])
            fx_sliders[effect_key].value = value
            input_widget.set_display(value)
        _adj_self_update[0] = False

    state.add_listener(_sync_effects)
    _sync_effects(state)

    section = bgui.Column(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=7,
            padding=bgui.EdgeInsets(4, 0, 0, 0),
        ),
        children=[
            bgui.Box(style=bgui.Style(
                width_policy=bgui.SizePolicy.FILL,
                height=1,
                background_color=SEPARATOR,
            )),
            bgui.Label("Effects", style=bgui.Style(
                font_size=11, font_weight="semibold", font_color=TEXT_COLOR,
            )),
        ] + fx_entries,
    )
    section.visible = visible
    return section


def _animate_popup_section(section, expand, popup_inst):
    """Expand or collapse a section with clip + tween."""
    if section is None or popup_inst is None:
        return
    if not getattr(section.style, 'clip_children', False):
        section.style.clip_children = True
    anim_dur = 0.25
    if expand:
        section.visible = True
        section.style.height = None
        target_h = section.measure_height()
        section.style.height = 0
        section.style.opacity = 0.0
        bgui.Tween(section.style, 'height', 0.0, target_h, anim_dur,
                   ease=bgui.ease_out_cubic,
                   on_update=lambda tw: popup_inst.invalidate())
        bgui.Tween(section.style, 'opacity', 0.0, 1.0, anim_dur,
                   ease=bgui.ease_out_cubic)
    else:
        cur_h = section.style.height
        if cur_h is None:
            cur_h = section.measure_height()

        def _collapse_done(tw, sec=section):
            sec.visible = False
            sec.style.height = None
            sec.style.opacity = 1.0
            popup_inst.invalidate()

        bgui.Tween(section.style, 'height', float(cur_h), 0.0, anim_dur,
                   ease=bgui.ease_out_cubic,
                   on_update=lambda tw: popup_inst.invalidate(),
                   on_complete=_collapse_done)
        bgui.Tween(section.style, 'opacity', 1.0, 0.0, anim_dur,
                   ease=bgui.ease_out_cubic)


# -- Hex Input Display -------------------------------------

class _HexInput(Widget):
    """Editable hex color + opacity input for the selected gradient stop.

    Click hex or opacity text to type a value. Press Enter to apply.
    """

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._hex_editing = False
        self._opa_editing = False
        self._hex_buf = ""
        self._opa_buf = ""
        self._cursor_pos = 0
        self._sel_start = None
        self._active_field = None  # 'hex' or 'opa'
        self._self_notify = False  # guard for self-triggered notify
        state.add_listener(self._on_state_change)

    def _on_state_change(self, st):
        # If we triggered the notify ourselves (from _commit), just update buffers
        if self._self_notify:
            self._self_notify = False
        elif self._active_field:
            # External state change � cancel editing
            self._hex_editing = False
            self._opa_editing = False
            self._active_field = None
        stop = st.selected_stop
        if stop:
            r, g, b = stop.color[:3]
            self._hex_buf = "#{:02X}{:02X}{:02X}".format(
                int(r * 255), int(g * 255), int(b * 255))
            a = stop.color[3] if len(stop.color) > 3 else 1.0
            self._opa_buf = "{}".format(int(a * 100))

    def _start_edit(self, field):
        stop = self.gstate.selected_stop
        if not stop:
            return
        self._active_field = field
        if field == 'hex':
            r, g, b = stop.color[:3]
            self._hex_buf = "{:02X}{:02X}{:02X}".format(
                int(r * 255), int(g * 255), int(b * 255))
            self._hex_editing = True
            self._cursor_pos = len(self._hex_buf)
        elif field == 'opa':
            a = stop.color[3] if len(stop.color) > 3 else 1.0
            self._opa_buf = "{}".format(int(a * 100))
            self._opa_editing = True
            self._cursor_pos = len(self._opa_buf)
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        """Commit and exit edit mode (called by global blur)."""
        if self._active_field:
            self._commit()

    def _commit(self):
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        stop = self.gstate.selected_stop
        if not stop:
            self._active_field = None
            self._hex_editing = False
            self._opa_editing = False
            return

        if self._active_field == 'hex':
            raw = self._hex_buf.strip().lstrip('#')
            if len(raw) == 6:
                try:
                    ri = int(raw[0:2], 16)
                    gi = int(raw[2:4], 16)
                    bi = int(raw[4:6], 16)
                    old_a = stop.color[3] if len(stop.color) > 3 else 1.0
                    stop.color = (ri / 255.0, gi / 255.0, bi / 255.0, old_a)
                    r, g, b = stop.color[:3]
                    h, s, v = colorsys.rgb_to_hsv(r, g, b)
                    self.gstate.hue = h
                    self.gstate.saturation = s
                    self.gstate.value = v
                except ValueError:
                    pass
            self._hex_editing = False
        elif self._active_field == 'opa':
            raw = self._opa_buf.strip().rstrip('%')
            try:
                val = max(0, min(100, int(raw)))
                r, g, b = stop.color[:3]
                stop.color = (r, g, b, val / 100.0)
                self.gstate.opacity = val / 100.0
            except ValueError:
                pass
            self._opa_editing = False

        self._active_field = None
        self._self_notify = True
        self.gstate.notify()

    def _del_sel(self, buf_attr):
        if self._sel_start is None:
            return getattr(self, buf_attr), False
        buf = getattr(self, buf_attr)
        s, e = min(self._sel_start, self._cursor_pos), max(self._sel_start, self._cursor_pos)
        buf = buf[:s] + buf[e:]
        self._cursor_pos = s
        self._sel_start = None
        setattr(self, buf_attr, buf)
        return buf, True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        if not self._active_field:
            return False
        buf_attr = '_hex_buf' if self._active_field == 'hex' else '_opa_buf'
        buf = getattr(self, buf_attr)

        if key == 'RET':
            self._commit()
            return True
        if key == 'ESC':
            self._hex_editing = False
            self._opa_editing = False
            self._active_field = None
            self._sel_start = None
            self.gstate.notify()
            return True
        if ctrl and key == 'A':
            self._sel_start = 0
            self._cursor_pos = len(buf)
            return True
        if key == 'BACK_SPACE':
            buf, had_sel = self._del_sel(buf_attr)
            if not had_sel:
                if self._cursor_pos > 0:
                    buf = buf[:self._cursor_pos - 1] + buf[self._cursor_pos:]
                    self._cursor_pos -= 1
                    setattr(self, buf_attr, buf)
            return True
        if key == 'DEL':
            buf, had_sel = self._del_sel(buf_attr)
            if not had_sel:
                if self._cursor_pos < len(buf):
                    buf = buf[:self._cursor_pos] + buf[self._cursor_pos + 1:]
                    setattr(self, buf_attr, buf)
            return True
        if key == 'LEFT_ARROW':
            self._sel_start = None
            self._cursor_pos = max(0, self._cursor_pos - 1)
            return True
        if key == 'RIGHT_ARROW':
            self._sel_start = None
            self._cursor_pos = min(len(buf), self._cursor_pos + 1)
            return True
        if key == 'HOME':
            self._sel_start = None
            self._cursor_pos = 0
            return True
        if key == 'END':
            self._sel_start = None
            self._cursor_pos = len(buf)
            return True

        if ctrl and key == 'V':
            buf, _ = self._del_sel(buf_attr)
            import bpy
            clip = (bpy.context.window_manager.clipboard or "").strip()
            if self._active_field == 'hex':
                clip = clip.lstrip('#')
                for ch in clip:
                    if ch.upper() in '0123456789ABCDEF' and len(buf) < 6:
                        buf = buf[:self._cursor_pos] + ch.upper() + buf[self._cursor_pos:]
                        self._cursor_pos += 1
                setattr(self, buf_attr, buf)
            elif self._active_field == 'opa':
                clip = clip.rstrip('%')
                try:
                    val = float(clip)
                    if val <= 1.0 and '.' in clip:
                        val = int(val * 100)
                    else:
                        val = int(val)
                    val = max(0, min(100, val))
                    buf = str(val)
                    self._cursor_pos = len(buf)
                except ValueError:
                    pass
                setattr(self, buf_attr, buf)
            return True

        if ascii_char and not ctrl:
            buf, _ = self._del_sel(buf_attr)
            if self._active_field == 'hex':
                if ascii_char.upper() in '0123456789ABCDEF' and len(buf) < 6:
                    buf = buf[:self._cursor_pos] + ascii_char.upper() + buf[self._cursor_pos:]
                    self._cursor_pos += 1
                    setattr(self, buf_attr, buf)
            elif self._active_field == 'opa':
                if ascii_char in '0123456789' and len(buf) < 3:
                    buf = buf[:self._cursor_pos] + ascii_char + buf[self._cursor_pos:]
                    self._cursor_pos += 1
                    setattr(self, buf_attr, buf)
            return True

        return False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        from ..bgui.renderer import Renderer as R

        # Background
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        border_c = (0.784, 1.0, 0.0, 0.8) if self._active_field else INPUT_BORDER
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=border_c, border_width=1 * sc,
        )

        stop = self.gstate.selected_stop
        if not stop:
            return

        r, g, b = stop.color[:3]
        a = stop.color[3] if len(stop.color) > 3 else 1.0

        # Color swatch
        swatch_size = 13 * sc
        sx = cr.x + 5 * sc
        sy = cr.y + (cr.height - swatch_size) / 2
        renderer.draw_rounded_rect(
            Rect(sx, sy, swatch_size, swatch_size),
            (r, g, b, 1.0), 3 * sc,
        )

        _, ref_h = R.measure_text("Og", 11, font_weight='semibold')
        ty = cr.y + (cr.height - ref_h) / 2
        tx = sx + swatch_size + 5 * sc

        # Hex text
        if self._hex_editing:
            hex_str = "#" + self._hex_buf
            renderer.draw_text(hex_str, tx, ty, size=11,
                               color=WHITE, font_weight='semibold',
                               ref_height=ref_h)
            # Selection highlight
            if self._sel_start is not None and self._active_field == 'hex':
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw, _ = R.measure_text("#" + self._hex_buf[:s], 11, font_weight='semibold')
                ew, _ = R.measure_text("#" + self._hex_buf[:e], 11, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(tx + sw, cr.y + 2 * sc, ew - sw, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            # Cursor
            before = "#" + self._hex_buf[:self._cursor_pos]
            cw, _ = R.measure_text(before, 11, font_weight='semibold')
            renderer.draw_rounded_rect(
                Rect(tx + cw, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)
        else:
            hex_str = "#{:02X}{:02X}{:02X}".format(
                int(r * 255), int(g * 255), int(b * 255))
            renderer.draw_text(hex_str, tx, ty, size=11,
                               color=TEXT_COLOR, font_weight='semibold',
                               ref_height=ref_h)

        # Separator line
        opa_w = 36 * sc
        sep_x = cr.x + cr.width - opa_w
        renderer.draw_rounded_rect(
            Rect(sep_x, cr.y + 4 * sc, 1 * sc, cr.height - 8 * sc),
            (0.85, 0.85, 0.85, 1.0), 0,
        )

        # Opacity
        if self._opa_editing:
            opa_str = self._opa_buf + "%"
            tw, _ = R.measure_text(opa_str, 11, font_weight='semibold')
            ox = sep_x + (opa_w - tw) / 2 + 1 * sc
            renderer.draw_text(opa_str, ox, ty, size=11,
                               color=WHITE, font_weight='semibold',
                               ref_height=ref_h)
            before_o = self._opa_buf[:self._cursor_pos]
            cw_o, _ = R.measure_text(before_o, 11, font_weight='semibold')
            # Selection highlight
            if self._sel_start is not None and self._active_field == 'opa':
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw_o, _ = R.measure_text(self._opa_buf[:s], 11, font_weight='semibold')
                ew_o, _ = R.measure_text(self._opa_buf[:e], 11, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(ox + sw_o, cr.y + 2 * sc, ew_o - sw_o, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            renderer.draw_rounded_rect(
                Rect(ox + cw_o, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)
        else:
            opa_str = "{}%".format(int(a * 100))
            tw, _ = R.measure_text(opa_str, 11, font_weight='semibold')
            ox = sep_x + (opa_w - tw) / 2 + 1 * sc
            renderer.draw_text(opa_str, ox, ty, size=11,
                               color=TEXT_COLOR, font_weight='semibold',
                               ref_height=ref_h)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            if self._active_field:
                self._commit()
            return False
        cr = self.content_rect
        sep_x = cr.x + cr.width - 36 * ui_scale()
        if x >= sep_x:
            if self._hex_editing:
                self._commit()
            self._start_edit('opa')
        else:
            if self._opa_editing:
                self._commit()
            self._start_edit('hex')
        return True


class _PositionInput(Widget):
    """Editable position % input for the selected gradient stop."""

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._editing = False
        self._buf = ""
        self._cursor_pos = 0
        self._sel_start = None
        self._self_notify = False
        state.add_listener(self._on_state_change)

    def _on_state_change(self, st):
        if self._self_notify:
            self._self_notify = False
        elif self._editing:
            self._editing = False
        stop = st.selected_stop
        if stop:
            self._buf = "{}".format(int(stop.position * 100))

    def _start_edit(self):
        stop = self.gstate.selected_stop
        if not stop:
            return
        self._buf = "{}".format(int(stop.position * 100))
        self._cursor_pos = len(self._buf)
        self._editing = True
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        """Commit and exit edit mode (called by global blur)."""
        if self._editing:
            self._commit()

    def _commit(self):
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        stop = self.gstate.selected_stop
        if stop:
            raw = self._buf.strip().rstrip('%')
            try:
                val = max(0, min(100, int(raw)))
                stop.position = val / 100.0
            except ValueError:
                pass
        self._editing = False
        self._self_notify = True
        self.gstate.notify()

    def _del_sel(self):
        if self._sel_start is None:
            return False
        s, e = min(self._sel_start, self._cursor_pos), max(self._sel_start, self._cursor_pos)
        self._buf = self._buf[:s] + self._buf[e:]
        self._cursor_pos = s
        self._sel_start = None
        return True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        if not self._editing:
            return False
        if key == 'RET':
            self._commit()
            return True
        if key == 'ESC':
            self._editing = False
            self._sel_start = None
            self.gstate.notify()
            return True
        if ctrl and key == 'A':
            self._sel_start = 0
            self._cursor_pos = len(self._buf)
            return True
        if key == 'BACK_SPACE':
            if not self._del_sel():
                if self._cursor_pos > 0:
                    self._buf = self._buf[:self._cursor_pos - 1] + self._buf[self._cursor_pos:]
                    self._cursor_pos -= 1
            return True
        if key == 'DEL':
            if not self._del_sel():
                if self._cursor_pos < len(self._buf):
                    self._buf = self._buf[:self._cursor_pos] + self._buf[self._cursor_pos + 1:]
            return True
        if key == 'LEFT_ARROW':
            self._sel_start = None
            self._cursor_pos = max(0, self._cursor_pos - 1)
            return True
        if key == 'RIGHT_ARROW':
            self._sel_start = None
            self._cursor_pos = min(len(self._buf), self._cursor_pos + 1)
            return True
        if key == 'HOME':
            self._sel_start = None
            self._cursor_pos = 0
            return True
        if key == 'END':
            self._sel_start = None
            self._cursor_pos = len(self._buf)
            return True
        if ctrl and key == 'V':
            self._del_sel()
            import bpy
            clip = (bpy.context.window_manager.clipboard or "").strip().rstrip('%')
            try:
                val = float(clip)
                if val <= 1.0 and '.' in clip:
                    val = int(val * 100)
                else:
                    val = int(val)
                val = max(0, min(100, val))
                self._buf = str(val)
                self._cursor_pos = len(self._buf)
            except ValueError:
                pass
            return True
        if ascii_char and not ctrl:
            self._del_sel()
            if ascii_char in '0123456789' and len(self._buf) < 3:
                self._buf = self._buf[:self._cursor_pos] + ascii_char + self._buf[self._cursor_pos:]
                self._cursor_pos += 1
            return True
        return False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        from ..bgui.renderer import Renderer as R

        border_c = (0.784, 1.0, 0.0, 0.8) if self._editing else INPUT_BORDER
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=border_c, border_width=1 * sc,
        )

        stop = self.gstate.selected_stop
        if not stop:
            return

        if self._editing:
            text = self._buf + "%"
        else:
            text = "{}%".format(int(stop.position * 100))

        tw, ref_h = R.measure_text(text, 11, font_weight='semibold')
        tx = cr.x + (cr.width - tw) / 2
        ty = cr.y + (cr.height - ref_h) / 2
        color = WHITE if self._editing else TEXT_COLOR
        renderer.draw_text(text, tx, ty, size=11,
                           color=color, font_weight='semibold',
                           ref_height=ref_h)

        if self._editing:
            before = self._buf[:self._cursor_pos]
            cw, _ = R.measure_text(before, 11, font_weight='semibold')
            # Offset cursor from the centered text position
            text_no_pct = self._buf
            tw_np, _ = R.measure_text(text_no_pct + "%", 11, font_weight='semibold')
            tx_base = cr.x + (cr.width - tw_np) / 2
            # Selection highlight
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw, _ = R.measure_text(self._buf[:s], 11, font_weight='semibold')
                ew, _ = R.measure_text(self._buf[:e], 11, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(tx_base + sw, cr.y + 2 * sc, ew - sw, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            renderer.draw_rounded_rect(
                Rect(tx_base + cw, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            if self._editing:
                self._commit()
            return False
        self._start_edit()
        return True


# -- Build Popup -------------------------------------------

def build_gradient_popup(on_close=None):
    """Build the Gradient Editor modal popup.

    Returns:
        (popup, open_fn, state) � call open_fn() to show.
    """
    state = GradientState()

    # -- Header ------------------------------------
    def _close(btn=None):
        # Push all stop colors to last-used on close
        for stop in state.stops:
            state.push_last_used(stop.color)
        popup.hide()
        if on_close:
            on_close(state)

    close_btn = bgui.Button(
        "✕",
        style=bgui.Style(
            background_color=TRANSPARENT,
            border_radius=4,
            width=20, height=20,
            font_size=13,
            font_color=TEXT_COLOR,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
            hover_style={"background_color": (1, 1, 1, 0.1)},
        ),
        on_click=_close,
    )

    # -- Params toggle (expand/collapse settings) --
    _params_expanded = [False]
    _params_section = [None]  # will hold the Column widget
    _adj_section = [None]     # will hold the adjustments Column
    _popup_ref = [None]       # will hold the ModalPopup for invalidation

    params_btn = _ToolButton(
        os.path.join(_ASSETS, "Params.svg"),
        style=bgui.Style(width=22, height=20),
    )

    def _toggle_params(btn):
        _params_expanded[0] = not _params_expanded[0]
        popup_inst = _popup_ref[0]
        _animate_popup_section(_params_section[0], _params_expanded[0], popup_inst)
        _animate_popup_section(_adj_section[0], _params_expanded[0], popup_inst)

    params_btn.on_click = _toggle_params

    distribute_btn = _ToolButton(
        os.path.join(_BGUI_ASSETS, "spaceeven.svg"),
        on_click=lambda w: state.distribute_evenly(),
        style=bgui.Style(width=22, height=20),
    )

    header_right = bgui.Row(
        style=bgui.Style(
            gap=4,
            alignment=bgui.Alignment.CENTER,
        ),
        children=[distribute_btn, params_btn, close_btn],
    )

    header = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            alignment=bgui.Alignment.CENTER,
            padding=bgui.EdgeInsets(9, 9, 5, 9),
        ),
        children=[
            bgui.Label("Gradient Editor", style=bgui.Style(
                font_size=13, font_weight="bold", font_color=TEXT_COLOR,
            )),
            header_right,
        ],
    )

    # -- Separators --------------------------------
    def _sep():
        return bgui.Box(style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            height=1,
            background_color=SEPARATOR,
            border_radius=60,
        ))

    # -- Gradient Strip ----------------------------
    gradient_strip = _GradientStripWidget(
        state,
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            height=26,
        ),
    )

    # -- Tool Row ----------------------------------
    position_display = _PositionInput(
        state,
        style=bgui.Style(width=32, height=20),
    )

    hex_display = _HexInput(
        state,
        style=bgui.Style(width=109, height=20),
    )

    def _start_eyedrop(btn):
        import bpy
        from .eyedrop import PALETTE_OT_eyedrop
        def _on_pick(color):
            stop = state.selected_stop
            if stop:
                stop.color = color
                r, g, b = color[:3]
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                state.hue = h
                state.saturation = s
                state.value = v
                state.opacity = color[3] if len(color) > 3 else 1.0
                state.notify()
        PALETTE_OT_eyedrop._on_pick_callback = _on_pick
        PALETTE_OT_eyedrop._on_finish_callback = None
        bpy.ops.palette.eyedrop('INVOKE_DEFAULT')

    color_picker_btn = _ToolButton(
        os.path.join(_ASSETS, "ColorEyedrop.svg"),
        on_click=_start_eyedrop,
        style=bgui.Style(width=22, height=20),
    )

    add_btn = _ToolButton(
        os.path.join(_ASSETS, "Plus.svg"),
        on_click=lambda w: state.add_stop(),
        style=bgui.Style(width=22, height=20),
    )

    remove_btn = _ToolButton(
        os.path.join(_ASSETS, "Bin.svg"),
        on_click=lambda w: state.remove_selected(),
        style=bgui.Style(width=22, height=20),
    )

    tool_row = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
            gap=5,
        ),
        children=[position_display, hex_display,
                  color_picker_btn, add_btn, remove_btn],
    )

    # -- Color Picker Area -------------------------
    sv_picker = _SVPickerWidget(
        state,
        style=bgui.Style(width=164, height=164, border_radius=9),
    )

    transparency_slider = _TransparencySlider(
        state,
        style=bgui.Style(width=26, height=164),
    )

    hue_slider = _HueSlider(
        state,
        style=bgui.Style(width=26, height=164),
    )

    picker_area = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=7,
            alignment=bgui.Alignment.START,
        ),
        children=[sv_picker, transparency_slider, hue_slider],
    )

    # -- Last Used ---------------------------------
    last_used_label = bgui.Label("Last Used", style=bgui.Style(
        font_size=11, font_weight="semibold", font_color=TEXT_COLOR,
    ))

    lumps = []
    for i, color in enumerate(state.last_used):
        lumps.append(_ColorLump(
            color, state=state, lump_index=i,
            style=bgui.Style(width=29, height=29),
        ))

    last_used_row = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=9,
            alignment=bgui.Alignment.CENTER,
        ),
        children=lumps,
    )

    # -- Params Section (Color Mode + Interpolation) --
    _COLOR_MODES = ["RGB", "HSV", "HSL"]
    _INTERP_MODES_RGB = ["Linear", "Ease", "Cardinal", "B-Spline", "Constant"]
    _INTERP_KEYS_RGB = ["LINEAR", "EASE", "CARDINAL", "B_SPLINE", "CONSTANT"]
    _INTERP_MODES_HUE = ["Near", "Far", "CW", "CCW"]
    _INTERP_KEYS_HUE = ["NEAR", "FAR", "CW", "CCW"]

    def _sync_interp_dropdown(cm):
        """Swap interp dropdown options based on color mode."""
        if cm == 'RGB':
            interp_dd.options = list(_INTERP_MODES_RGB)
            idx = _INTERP_KEYS_RGB.index(state.interpolation) if state.interpolation in _INTERP_KEYS_RGB else 0
            interp_dd.selected = idx
        else:
            interp_dd.options = list(_INTERP_MODES_HUE)
            idx = _INTERP_KEYS_HUE.index(state.hue_interpolation) if state.hue_interpolation in _INTERP_KEYS_HUE else 0
            interp_dd.selected = idx

    def _on_color_mode_change(dd):
        state.push_undo()
        state.color_mode = _COLOR_MODES[dd.selected]
        _sync_interp_dropdown(state.color_mode)
        state.notify()

    def _on_interp_change(dd):
        state.push_undo()
        if state.color_mode == 'RGB':
            state.interpolation = _INTERP_KEYS_RGB[dd.selected]
        else:
            state.hue_interpolation = _INTERP_KEYS_HUE[dd.selected]
        state.notify()

    color_mode_dd = bgui.Dropdown(
        options=_COLOR_MODES,
        selected=0,
        on_change=_on_color_mode_change,
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=0,
            border_radius=5,
            font_size=11,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=75,
            padding=bgui.EdgeInsets(4, 16, 4, 8),
            hover_style={'background_color': (0.35, 0.35, 0.39, 1.0)},
        ),
    )

    interp_dd = bgui.Dropdown(
        options=_INTERP_MODES_RGB,
        selected=0,
        on_change=_on_interp_change,
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=0,
            border_radius=5,
            font_size=11,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight='semibold',
            height=26,
            width=75,
            padding=bgui.EdgeInsets(4, 16, 4, 8),
            hover_style={'background_color': (0.35, 0.35, 0.39, 1.0)},
        ),
    )

    params_section = bgui.Column(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=6,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
        ),
        children=[
            bgui.Row(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
                    alignment=bgui.Alignment.CENTER,
                ),
                children=[
                    bgui.Row(
                        style=bgui.Style(gap=6, alignment=bgui.Alignment.CENTER),
                        children=[
                            bgui.Label("Color", style=bgui.Style(
                                font_size=11, font_weight="semibold", font_color=TEXT_COLOR,
                            )),
                            color_mode_dd,
                        ]
                    ),
                    bgui.Row(
                        style=bgui.Style(gap=6, alignment=bgui.Alignment.CENTER),
                        children=[
                            bgui.Label("Interp", style=bgui.Style(
                                font_size=11, font_weight="semibold", font_color=TEXT_COLOR,
                            )),
                            interp_dd,
                        ]
                    ),
                ],
            ),
            _sep(),
        ],
    )
    params_section.visible = False
    _params_section[0] = params_section

    # -- Effects Section ---------------------------
    adjustments_section = _build_effects_section(state, visible=False)
    _adj_section[0] = adjustments_section

    # -- Assemble ----------------------------------
    drag_handle = _DragHandle(
        _popup_ref,
        style=bgui.Style(
            width=40, height=14,
            alignment=bgui.Alignment.CENTER,
        ),
    )
    popup_content = bgui.ScrollBox(
        scroll_speed=24.0,
        style=bgui.Style(
            width=270,
            height_policy=bgui.SizePolicy.FILL,
            background_color=POPUP_BG,
            border_radius=13,
            padding=bgui.EdgeInsets(4, 7, 7, 7),
            gap=3,
            alignment=bgui.Alignment.CENTER,
        ),
        children=[
            bgui.Row(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    main_alignment=bgui.MainAxisAlignment.CENTER,
                ),
                children=[drag_handle],
            ),
            bgui.Column(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    background_color=CONTAINER,
                    border_radius=7,
                    padding=bgui.EdgeInsets(10, 13, 12, 13),
                    gap=9,
                ),
                children=[
                    header,
                    _sep(),
                    params_section,
                    gradient_strip,
                    tool_row,
                    _sep(),
                    picker_area,
                    _sep(),
                    last_used_label,
                    last_used_row,
                    adjustments_section,
                ],
            ),
        ],
    )

    popup = bgui.ModalPopup("gradient_editor_popup", space_type='IMAGE_EDITOR')
    popup.set_root(popup_content)
    popup.on_dismiss = _close
    _popup_ref[0] = popup

    # Ctrl+Z / Ctrl+Shift+Z undo/redo at popup root level
    def _popup_key_handler(key, shift=False, ctrl=False, ascii_char=""):
        if ctrl and key == 'Z':
            if shift:
                state.redo()
            else:
                state.undo()
            return True
        if ctrl and key == 'V':
            import bpy
            clip = bpy.context.window_manager.clipboard or ""
            color = parse_clipboard_color(clip)
            if color:
                stop = state.selected_stop
                if stop:
                    state.push_undo()
                    stop.color = color
                    r, g, b = color[:3]
                    h, s, v = colorsys.rgb_to_hsv(r, g, b)
                    state.hue = h
                    state.saturation = s
                    state.value = v
                    state.opacity = color[3] if len(color) > 3 else 1.0
                    state.notify()
                return True
        return False
    popup_content.handle_key_event = _popup_key_handler

    def open_fn():
        # Sync dropdown selections from state
        cm = state.color_mode
        color_mode_dd.selected = _COLOR_MODES.index(cm) if cm in _COLOR_MODES else 0
        _sync_interp_dropdown(cm)
        # Collapse params + adjustments on open
        _params_expanded[0] = False
        params_section.visible = False
        adjustments_section.visible = False
        popup.show()

    return popup, open_fn, state
