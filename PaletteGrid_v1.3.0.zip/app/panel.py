# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Main panel orchestrator � manages panel switching between empty and active states."""
import bpy
from .. import bgui
from ..core import palette as core_palette
from .state import app_state
from .texture import generate_texture, update_texture, update_strip, focus_texture
from . import overlay
from .popup import build_create_popup, build_strip_settings_popup
from .gradient_popup import build_gradient_popup, GradientStop
from .color_popup import build_color_picker_popup
from .panel_empty import build_empty_root
from .panel_active import build_active_root
from .io_ops import PALETTE_OT_export


def build_main_panel():
    """Build the single Palette Grid sidebar panel.

    Switches between empty-state and active-state content based
    on whether app_state has any palettes.

    Returns:
        SidebarGPUPanel instance (already registered).
    """
    # Create popups once � they are overlays, independent of panel content
    def _on_palette_created(name, size, strips_type, direction, color_space,
                             rows=0, cols=0, tex_width=0, tex_height=0,
                             fill_color=None):
        texture_size = int(size)
        palette = core_palette.create_palette(
            name, texture_size, strips_type, direction, color_space,
            grid_cols=cols, grid_rows=rows,
            texture_width=tex_width, texture_height=tex_height,
            fill_color=fill_color)
        generate_texture(palette)
        app_state.add_palette(palette)
        focus_texture(palette)

    # Picking the create-popup's fill colour reuses the normal colour editor.
    # bgui delivers events to EVERY visible modal popup and dismisses any whose
    # rect the click falls outside, so two stacked popups fight over clicks --
    # the create popup is hidden while picking and restored on close.  While
    # this is active, _sync_color must not treat the edit as a strip edit.
    _fill_pick = {"active": False, "apply": None}

    def _pick_fill_color(current, apply_fn):
        _fill_pick["active"] = True
        _fill_pick["apply"] = apply_fn
        create_popup.hide()
        color_state.stops.clear()
        color_state.stops.append(GradientStop(0.0, current))
        color_state.effects = {}
        color_state.select_stop(0)
        color_open()

    def _on_color_popup_closed(cstate):
        if not _fill_pick["active"]:
            return
        _fill_pick["active"] = False
        apply_fn = _fill_pick["apply"]
        _fill_pick["apply"] = None
        color = cstate.stops[0].color if cstate.stops else (1.0, 1.0, 1.0, 1.0)
        if apply_fn:
            apply_fn(color)
        create_popup.show()

    create_popup, open_create_popup = build_create_popup(
        on_create=_on_palette_created, on_pick_color=_pick_fill_color)
    grad_popup, grad_open, grad_state = build_gradient_popup()
    color_popup, color_open, color_state = build_color_picker_popup(
        on_close=_on_color_popup_closed)

    def _on_strip_settings_change(strip_index, name, strip_type, direction):
        from .data import StripType
        palette = app_state.active_palette
        if palette is None or strip_index < 0 or strip_index >= len(palette.strips):
            return
        strip = palette.strips[strip_index]
        strip.name = name
        # Handle type change
        if strip.strip_type != strip_type:
            if strip_type == StripType.FLAT:
                # Gradient ? Flat: use first stop's color
                color = strip.stops[0][1] if strip.stops else (1.0, 1.0, 1.0, 1.0)
                strip.stops = [(0.0, color), (1.0, color)]
            elif strip_type == StripType.GRADIENT:
                # Flat ? Gradient: make second stop lighter or darker
                color = strip.stops[0][1] if strip.stops else (1.0, 1.0, 1.0, 1.0)
                r, g, b, a = color
                lum = 0.299 * r + 0.587 * g + 0.114 * b
                if lum > 0.5:
                    f = 0.6  # darken
                else:
                    f = 1.5  # lighten
                second = (min(r * f, 1.0), min(g * f, 1.0), min(b * f, 1.0), a)
                strip.stops = [(0.0, color), (1.0, second)]
            strip.strip_type = strip_type
        # Set per-strip direction (None for flat)
        strip.direction = direction
        update_strip(palette, strip_index)
        app_state.notify()
        overlay.tag_redraw()

    def _on_strip_settings_cancel(strip_index, orig_name, orig_type, orig_dir, orig_stops):
        """Revert strip to its original state when Cancel is pressed."""
        palette = app_state.active_palette
        if palette is None or strip_index < 0 or strip_index >= len(palette.strips):
            return
        strip = palette.strips[strip_index]
        strip.name = orig_name
        strip.strip_type = orig_type
        strip.direction = orig_dir
        strip.stops = orig_stops
        update_strip(palette, strip_index)
        app_state.notify()
        overlay.tag_redraw()

    strip_settings_popup, open_strip_settings = build_strip_settings_popup(
        on_change=_on_strip_settings_change,
        on_cancel=_on_strip_settings_cancel)

    # -- Live texture sync: push popup edits ? strip data ? texture --
    def _sync_gradient(gstate):
        """Push GradientState stops back to the active strip and regenerate."""
        palette = app_state.active_palette
        if palette is None:
            return
        idx = app_state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            return
        strip = palette.strips[idx]
        strip.stops = [(s.position, s.color) for s in sorted(gstate.stops, key=lambda s: s.position)]
        strip.color_mode = gstate.color_mode
        strip.interpolation = gstate.interpolation
        strip.hue_interpolation = gstate.hue_interpolation
        strip.effects = dict(gstate.effects)
        update_strip(palette, idx)
        overlay.tag_redraw()

    def _sync_color(cstate):
        """Push single-color change back to the flat strip and regenerate."""
        if _fill_pick["active"]:
            # The colour editor is being used to choose a new palette's fill
            # colour, not to edit an existing strip.  Do not touch any strip.
            return
        palette = app_state.active_palette
        if palette is None:
            return
        idx = app_state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            return
        strip = palette.strips[idx]
        color = cstate.stops[0].color if cstate.stops else (1.0, 1.0, 1.0, 1.0)
        strip.stops = [(pos, color) for pos, _ in strip.stops]
        strip.effects = dict(cstate.effects)
        update_strip(palette, idx)
        overlay.tag_redraw()

    grad_state.add_listener(_sync_gradient)
    color_state.add_listener(_sync_color)

    panel = bgui.SidebarGPUPanel(
        "palette_main", label="Palette Grid", category="Palette Grid",
        height_fraction=0.75, space_type='IMAGE_EDITOR',
    )

    def _open_create(btn=None):
        open_create_popup(btn)

    def _open_import(btn=None):
        bpy.ops.palette_grid.import_palette('INVOKE_DEFAULT')

    def _on_export_palette(datalist, index):
        PALETTE_OT_export._export_index = index
        bpy.ops.palette_grid.export_palette('INVOKE_DEFAULT')

    def _rebuild(state=None):
        if app_state.has_palettes:
            content_root = build_active_root(
                app_state, grad_open, grad_state,
                color_open, color_state,
                on_create_click=_open_create,
                on_import_click=_open_import,
                on_export_click=_on_export_palette,
                on_strip_settings=open_strip_settings,
            )
            # Focus the active palette's texture in the Image Editor
            active = app_state.active_palette
            if active:
                focus_texture(active)
        else:
            content_root = build_empty_root(
                on_create_click=_open_create,
                on_import_click=_open_import,
            )
        root = bgui.ScrollBox(
            scroll_speed=24.0,
            style=bgui.Style(
                width_policy=bgui.SizePolicy.FILL,
                height_policy=bgui.SizePolicy.FILL,
            ),
            children=[content_root],
        )
        panel.set_root(root)
        panel.invalidate()

    app_state.add_listener(_rebuild)
    _rebuild()
    panel.register()
    overlay.register(app_state)
    return panel

