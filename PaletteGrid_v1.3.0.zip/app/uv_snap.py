# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""UV snapping � map selected UVs to the active strip's cell rect.

Provides auto-UV-layer creation, unwrapping, and snap modes (Fill / Contain).
Delegates pure math to ``core.uv``; this module handles bpy/bmesh wiring.
"""
import math

import bpy
import bmesh

from ..core import uv as _uv
from ..core.data import StripType


# -- Recording helper ------------------------------------------------------

def _apply_recording_prefs():
    """If the 'Disable 3D Viewport Overlays' preference is on, turn off
    overlays in all 3D viewports.  Called after each snap operator."""
    try:
        # Extension package: bl_ext.user_default.palette_grid
        # __package__ here is palette_grid.app.uv_snap,
        # but the AddonPreferences bl_idname uses the root __init__.__package__
        # which for extensions is e.g. bl_ext.user_default.palette_grid
        for key, addon in bpy.context.preferences.addons.items():
            if key.endswith('palette_grid') and hasattr(addon, 'preferences'):
                prefs = addon.preferences
                if getattr(prefs, 'disable_3d_overlays', False):
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            for space in area.spaces:
                                if space.type == 'VIEW_3D':
                                    space.overlay.show_overlays = False
                break
    except Exception:
        pass


# -- Edit-mesh helpers -----------------------------------------------------

def find_edit_mesh_context():
    """Return ``(object, bmesh)`` if any 3D Viewport in the current workspace
    has a mesh in Edit Mode, otherwise ``(None, None)``."""
    for area in bpy.context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        for space in area.spaces:
            if space.type == 'VIEW_3D' and hasattr(space, 'region_3d'):
                obj = bpy.context.edit_object
                if obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT':
                    bm = bmesh.from_edit_mesh(obj.data)
                    return obj, bm
    return None, None


def find_all_edit_mesh_contexts():
    """Return list of ``(object, bmesh)`` for every mesh in Edit Mode.

    Uses ``objects_in_mode_unique_data`` so linked-duplicate meshes aren't
    processed twice.  Falls back to the single active edit object.
    """
    results = []
    try:
        objects = bpy.context.objects_in_mode_unique_data
    except AttributeError:
        obj = bpy.context.edit_object
        if obj is not None and obj.type == 'MESH':
            return [(obj, bmesh.from_edit_mesh(obj.data))]
        return []
    for obj in objects:
        if obj.type == 'MESH':
            results.append((obj, bmesh.from_edit_mesh(obj.data)))
    return results


def has_edit_mesh():
    """Quick check: is there an edit-mode mesh available for UV operations?"""
    # Primary: check active edit object (fast path)
    obj = bpy.context.edit_object
    if obj is not None and obj.type == 'MESH':
        return True
    # Fallback: iterate view layer objects (handles context edge cases
    # where edit_object is None despite a mesh being in Edit Mode,
    # e.g. pie menus invoked from Image Editor context)
    try:
        for obj in bpy.context.view_layer.objects:
            if obj.type == 'MESH' and obj.mode == 'EDIT':
                return True
    except (AttributeError, RuntimeError):
        pass
    return False


# -- UV helpers ------------------------------------------------------------

def get_cell_uv_bounds(palette, strip_index):
    """Delegate to ``core.uv.cell_uv_bounds``."""
    return _uv.cell_uv_bounds(palette.grid_cols, palette.grid_rows, strip_index,
                               palette.texture_width, palette.texture_height)


def _get_selected_uv_loops(bm, uv_layer):
    """Return list of BMLoop references whose UV is selected (or whose face is
    selected when sync-selection is on).

    When sync is off and no UV loops are explicitly selected, falls back to
    all loops of selected faces so snap operations still work from 3D selection.
    """
    sync = bpy.context.tool_settings.use_uv_select_sync

    # Blender 5.0+ stores UV selection in a boolean attribute layer;
    # older versions (4.2) use loop[uv_layer].select
    uv_sel_layer = None
    if hasattr(bm.loops.layers, 'bool'):
        uv_sel_layer = bm.loops.layers.bool.get('.uv_select_vert')

    # Check if BMLoopUV has .select (removed in some Blender versions)
    _has_uv_select = False
    for face in bm.faces:
        for loop in face.loops:
            _has_uv_select = hasattr(loop[uv_layer], 'select')
            break
        break

    loops = []
    all_face_loops = []
    for face in bm.faces:
        if not face.select:
            continue
        for loop in face.loops:
            all_face_loops.append(loop)
            if sync:
                loops.append(loop)
            elif uv_sel_layer and loop[uv_sel_layer]:
                loops.append(loop)
            elif not uv_sel_layer and _has_uv_select and loop[uv_layer].select:
                loops.append(loop)
    return loops if loops else all_face_loops


def _uv_bounds(loops, uv_layer):
    """Return (u_min, v_min, u_max, v_max) of the given UV loops."""
    us = [l[uv_layer].uv.x for l in loops]
    vs = [l[uv_layer].uv.y for l in loops]
    return min(us), min(vs), max(us), max(vs)


def _uv_is_degenerate(bm, uv_layer, threshold=1e-6):
    """True if all UV coords collapse to roughly a single point."""
    first = None
    for face in bm.faces:
        for loop in face.loops:
            uv = loop[uv_layer].uv
            if first is None:
                first = (uv.x, uv.y)
            elif abs(uv.x - first[0]) > threshold or abs(uv.y - first[1]) > threshold:
                return False
    return True


def _mesh_has_seams(bm):
    """True if any edge in the mesh is marked as a seam."""
    return any(e.seam for e in bm.edges)


def _ensure_uv_layer(obj, bm, unwrap_mode):
    """Create a UV layer and auto-unwrap if one doesn't exist or is degenerate.

    Returns ``(bm, uv_layer)`` � *bm* may be refreshed after unwrap ops.
    Returns ``(bm, None)`` on failure.
    """
    uv_layer = bm.loops.layers.uv.active
    needs_unwrap = False

    if uv_layer is None:
        uv_layer = bm.loops.layers.uv.new("UVMap")
        bmesh.update_edit_mesh(obj.data)
        needs_unwrap = True
    elif _uv_is_degenerate(bm, uv_layer):
        needs_unwrap = True

    if not needs_unwrap:
        return bm, uv_layer

    # bpy.ops for unwrapping require a 3D Viewport context override
    area_3d = None
    region_3d = None
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        area_3d = area
                        region_3d = region
                        break
                if region_3d:
                    break
        if region_3d:
            break

    if area_3d is None:
        return bm, uv_layer  # no 3D viewport � skip unwrap, layer still usable

    with bpy.context.temp_override(area=area_3d, region=region_3d,
                                    object=obj, edit_object=obj):
        if unwrap_mode == 'SMART_UV':
            bpy.ops.uv.smart_project()
        elif unwrap_mode == 'UNWRAP':
            # Closed manifolds need seams for angle-based unwrap.
            # If none exist, temporarily mark sharp/boundary edges.
            auto_seam_idx = set()
            if not _mesh_has_seams(bm):
                _SHARP = math.radians(55)
                for edge in bm.edges:
                    nf = len(edge.link_faces)
                    if nf <= 1 or (nf == 2 and edge.calc_face_angle(0) > _SHARP):
                        edge.seam = True
                        auto_seam_idx.add(edge.index)
                bmesh.update_edit_mesh(obj.data)
            bpy.ops.uv.unwrap()
            # Clear the temporary seams so the mesh is untouched
            if auto_seam_idx:
                tmp_bm = bmesh.from_edit_mesh(obj.data)
                tmp_bm.edges.ensure_lookup_table()
                for idx in auto_seam_idx:
                    tmp_bm.edges[idx].seam = False
                bmesh.update_edit_mesh(obj.data)
        elif unwrap_mode == 'LIGHTMAP':
            try:
                bpy.ops.uv.lightmap_pack()
            except RuntimeError:
                # Fallback if lightmap_pack can't find the mesh object
                bpy.ops.uv.smart_project()
        elif unwrap_mode == 'CUBE':
            bpy.ops.uv.cube_project()
        elif unwrap_mode == 'CYLINDER':
            bpy.ops.uv.cylinder_project()
        elif unwrap_mode == 'SPHERE':
            bpy.ops.uv.sphere_project()

    # Refresh bmesh after operators modified the mesh
    bm = bmesh.from_edit_mesh(obj.data)
    return bm, bm.loops.layers.uv.active


# -- Snap logic ------------------------------------------------------------

def snap_uvs(app_state, mode, unwrap_mode='SMART_UV', merge=False,
             direction_override=None, margin=0.01):
    """Snap selected UV loops to the active strip's cell rect.

    Extracts plain data from bmesh, delegates math to ``core.uv``, writes back.
    Supports multiple objects in Edit Mode simultaneously.

    When *merge* is True, all objects share a single combined UV bounding box
    so their relative UV positions are preserved when snapped into the cell.
    """
    if app_state is None or app_state.selected_strip_index < 0:
        return {'CANCELLED'}

    palette = app_state.palettes[app_state.active_index]
    strip_idx = app_state.selected_strip_index
    dst_bounds = _uv.cell_uv_bounds(palette.grid_cols, palette.grid_rows, strip_idx)

    contexts = find_all_edit_mesh_contexts()
    if not contexts:
        return {'CANCELLED'}

    # Prepare per-object data
    entries = []  # (obj, bm, uv_layer, loops)
    for obj, _bm in contexts:
        bm = bmesh.from_edit_mesh(obj.data)
        if not bm.faces:
            continue
        bm, uv_layer = _ensure_uv_layer(obj, bm, unwrap_mode)
        if uv_layer is None:
            continue
        loops = _get_selected_uv_loops(bm, uv_layer)
        if not loops:
            continue
        entries.append((obj, bm, uv_layer, loops))

    if not entries:
        return {'CANCELLED'}

    if merge and len(entries) > 1:
        # Combined bounding box across all objects
        all_us, all_vs = [], []
        for _, _, uv_layer, loops in entries:
            for l in loops:
                all_us.append(l[uv_layer].uv.x)
                all_vs.append(l[uv_layer].uv.y)
        src_bounds = (min(all_us), min(all_vs), max(all_us), max(all_vs))
        transform = _uv.compute_snap_transform(src_bounds, dst_bounds, mode, margin)

        for obj, bm, uv_layer, loops in entries:
            uv_coords = [(l[uv_layer].uv.x, l[uv_layer].uv.y) for l in loops]
            new_coords = _uv.remap_uvs(uv_coords, transform)
            for loop, (nu, nv) in zip(loops, new_coords):
                loop[uv_layer].uv.x = nu
                loop[uv_layer].uv.y = nv
            bmesh.update_edit_mesh(obj.data)
    else:
        # Each object snapped independently
        for obj, bm, uv_layer, loops in entries:
            src_bounds = _uv_bounds(loops, uv_layer)
            uv_coords = [(l[uv_layer].uv.x, l[uv_layer].uv.y) for l in loops]
            transform = _uv.compute_snap_transform(src_bounds, dst_bounds, mode, margin)
            new_coords = _uv.remap_uvs(uv_coords, transform)
            for loop, (nu, nv) in zip(loops, new_coords):
                loop[uv_layer].uv.x = nu
                loop[uv_layer].uv.y = nv
            bmesh.update_edit_mesh(obj.data)

    return {'FINISHED'}


# -- Operator --------------------------------------------------------------

class PALETTE_OT_uv_snap(bpy.types.Operator):
    """Snap selected UVs to the active strip's cell rect"""
    bl_idname = "palette_grid.uv_snap"
    bl_label = "UV Snap to Strip"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('FILL', "Fill", "Stretch UVs to exactly fill the strip rect"),
            ('CONTAIN', "Contain", "Uniform scale to fit inside the strip rect"),
        ],
        default='FILL',
    )

    unwrap_mode: bpy.props.EnumProperty(
        name="Auto Unwrap",
        description="Unwrap method used when the mesh has no UV map",
        items=[
            ('SMART_UV', "Smart UV Project", "Automatic projection based on angle"),
            ('UNWRAP', "Unwrap", "Standard angle-based unwrap"),
            ('LIGHTMAP', "Lightmap Pack", "Pack all faces into UV space"),
            ('CUBE', "Cube Projection", "Project from cube"),
            ('CYLINDER', "Cylinder Projection", "Project from cylinder"),
            ('SPHERE', "Sphere Projection", "Project from sphere"),
        ],
        default='SMART_UV',
    )

    _app_state = None  # set by overlay.register()
    needs_unwrap: bpy.props.BoolProperty(options={'HIDDEN', 'SKIP_SAVE'})

    merge_objects: bpy.props.BoolProperty(
        name="Merge Objects",
        description="Treat all edit-mode objects as one when snapping UVs, preserving relative positions",
        default=False,
    )

    direction: bpy.props.EnumProperty(
        name="Direction",
        description="Gradient axis direction for UV distribution",
        items=[
            ('DEFAULT', "Default", "Use the palette's default direction"),
            ('Horizontal', "Horizontal", "Distribute along horizontal axis"),
            ('Vertical', "Vertical", "Distribute along vertical axis"),
        ],
        default='DEFAULT',
    )

    margin: bpy.props.FloatProperty(
        name="Margin",
        description="Inset on each side of the cell to prevent color bleed",
        default=0.01, min=0.0, max=0.1, precision=3,
    )

    def execute(self, context):
        # Check UV state before making any changes (redo undoes first)
        self.needs_unwrap = False
        for obj, bm in find_all_edit_mesh_contexts():
            uv = bm.loops.layers.uv.active
            if uv is None or _uv_is_degenerate(bm, uv):
                self.needs_unwrap = True
                break
        d = None if self.direction == 'DEFAULT' else self.direction
        try:
            result = snap_uvs(PALETTE_OT_uv_snap._app_state, self.mode,
                            self.unwrap_mode, merge=self.merge_objects,
                            direction_override=d, margin=self.margin)
        except Exception as e:
            self.report({'INFO'}, f"Could not snap UVs: {e}")
            return {'CANCELLED'}
        _apply_recording_prefs()
        return result

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mode")
        if self.needs_unwrap:
            layout.prop(self, "unwrap_mode")
        layout.prop(self, "merge_objects")
        layout.prop(self, "direction")
        layout.prop(self, "margin")


# -- Radial Snap -----------------------------------------------------------

def radial_snap_uvs(app_state, direction_override=None, margin=0.01,
                    invert=False):
    """Sort selected UV loops by 3D distance from cursor, distribute along strip.

    Gradient strips: parameterize along gradient direction.
    Flat strips: all UVs go to the center of the cell.
    Supports multiple objects in Edit Mode simultaneously.

    Parameters
    ----------
    direction_override : str or None
        If given, use this direction instead of palette.direction.
    """
    if app_state is None or app_state.selected_strip_index < 0:
        return {'CANCELLED'}

    palette = app_state.palettes[app_state.active_index]
    strip_idx = app_state.selected_strip_index
    strip = palette.strips[strip_idx]
    dst_bounds = _uv.cell_uv_bounds(palette.grid_cols, palette.grid_rows, strip_idx)
    cursor_world = bpy.context.scene.cursor.location

    contexts = find_all_edit_mesh_contexts()
    if not contexts:
        return {'CANCELLED'}

    any_snapped = False
    for obj, _bm in contexts:
        bm = bmesh.from_edit_mesh(obj.data)
        if not bm.faces:
            continue

        bm, uv_layer = _ensure_uv_layer(obj, bm, 'LIGHTMAP')
        if uv_layer is None:
            continue

        loops = _get_selected_uv_loops(bm, uv_layer)
        if not loops:
            continue

        mat = obj.matrix_world
        distances = [((mat @ loop.vert.co) - cursor_world).length for loop in loops]

        if strip.strip_type == StripType.FLAT:
            cu, cv = _uv.compute_flat_center(dst_bounds)
            new_coords = [(cu, cv)] * len(loops)
        else:
            new_coords = _uv.compute_radial_snap(distances, dst_bounds,
                                                   direction_override or palette.direction,
                                                   margin, invert=invert)

        for loop, (nu, nv) in zip(loops, new_coords):
            loop[uv_layer].uv.x = nu
            loop[uv_layer].uv.y = nv

        bmesh.update_edit_mesh(obj.data)
        any_snapped = True

    return {'FINISHED'} if any_snapped else {'CANCELLED'}


def path_snap_uvs(app_state, path_points, path_lengths, region, rv3d,
                  direction_override=None, margin=0.01, invert=False):
    """Project selected mesh vertices along a drawn path into the strip's UV cell.

    1. Screen-projects each selected vert via ``location_3d_to_region_2d``
    2. Finds nearest point on the path polyline ? t-value
    3. Maps t-values to UV coordinates within the active strip's cell
    4. Writes back to the mesh

    Supports multiple objects in Edit Mode simultaneously.

    Returns a status string: ``'OK'``, ``'NO_PALETTE'``, ``'NO_MESH'``,
    ``'NO_UV'``, ``'NO_SELECTION'``, ``'NO_VISIBLE'``.
    """
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    from ..core import path as _path

    if app_state is None or app_state.selected_strip_index < 0:
        return 'NO_PALETTE'

    palette = app_state.palettes[app_state.active_index]
    strip_idx = app_state.selected_strip_index
    dst_bounds = _uv.cell_uv_bounds(palette.grid_cols, palette.grid_rows, strip_idx)

    contexts = find_all_edit_mesh_contexts()
    if not contexts:
        return 'NO_MESH'

    any_snapped = False
    last_error = 'NO_MESH'
    for obj, _bm in contexts:
        # Refresh bmesh � a previous iteration's _ensure_uv_layer may have
        # run bpy.ops (lightmap_pack, etc.) which invalidates stale references.
        bm = bmesh.from_edit_mesh(obj.data)
        if not bm.faces:
            continue

        bm, uv_layer = _ensure_uv_layer(obj, bm, 'LIGHTMAP')
        if uv_layer is None:
            last_error = 'NO_UV'
            continue

        loops = _get_selected_uv_loops(bm, uv_layer)
        if not loops:
            last_error = 'NO_SELECTION'
            continue

        mat = obj.matrix_world
        screen_points = []
        valid_loops = []
        for loop in loops:
            world_co = mat @ loop.vert.co
            sp = location_3d_to_region_2d(region, rv3d, world_co)
            if sp is not None:
                screen_points.append((sp.x, sp.y))
                valid_loops.append(loop)

        if not screen_points:
            last_error = 'NO_VISIBLE'
            continue

        t_values = _path.project_points_batch(screen_points, path_points, path_lengths)
        uv_coords = _uv.compute_path_snap(t_values, dst_bounds,
                                           direction_override or palette.direction,
                                           margin, invert=invert)

        for loop, (u, v) in zip(valid_loops, uv_coords):
            loop[uv_layer].uv.x = u
            loop[uv_layer].uv.y = v

        bmesh.update_edit_mesh(obj.data)
        any_snapped = True

    return 'OK' if any_snapped else last_error


class PALETTE_OT_uv_radial_snap(bpy.types.Operator):
    """Sort UVs by 3D distance from cursor and distribute along strip"""
    bl_idname = "palette_grid.uv_radial_snap"
    bl_label = "Radial Snap"
    bl_options = {'REGISTER', 'UNDO'}

    _app_state = None

    direction: bpy.props.EnumProperty(
        name="Direction",
        description="Gradient axis direction for UV distribution",
        items=[
            ('DEFAULT', "Default", "Use the palette's default direction"),
            ('Horizontal', "Horizontal", "Distribute along horizontal axis"),
            ('Vertical', "Vertical", "Distribute along vertical axis"),
        ],
        default='DEFAULT',
    )

    margin: bpy.props.FloatProperty(
        name="Margin",
        description="Inset on each side of the cell to prevent color bleed",
        default=0.01, min=0.0, max=0.1, precision=3,
    )

    invert: bpy.props.BoolProperty(
        name="Invert",
        description="Flip the gradient direction (swap 0 and 1)",
        default=False,
    )

    def execute(self, context):
        state = PALETTE_OT_uv_radial_snap._app_state
        if self.direction == 'DEFAULT':
            # Follow strip's direction override, else palette default
            palette = state.palettes[state.active_index]
            strip = palette.strips[state.selected_strip_index]
            d = strip.direction  # None ? radial_snap_uvs falls back to palette.direction
        else:
            d = self.direction
        try:
            result = radial_snap_uvs(state,
                                     direction_override=d,
                                     margin=self.margin,
                                     invert=self.invert)
        except Exception as e:
            self.report({'INFO'}, f"Could not radial snap UVs: {e}")
            return {'CANCELLED'}
        _apply_recording_prefs()
        return result

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "direction")
        layout.prop(self, "margin")
        layout.prop(self, "invert")


# -- Project From View -----------------------------------------------------

def _find_3d_viewport():
    """Return ``(area, region)`` for the first 3D Viewport WINDOW region,
    or ``(None, None)`` if no 3D viewport is open."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        return area, region
    return None, None


def project_from_view_uvs(app_state, mode='FILL', merge=False,
                          direction_override=None, margin=0.01):
    """Project UVs from the current 3D viewport camera angle, then snap to strip.

    1. Ensures every edit-mode mesh has a UV layer.
    2. Calls Blender's ``uv.project_from_view`` for each object.
    3. Snaps the resulting UVs into the active strip's cell rect (Contain mode).

    When *merge* is True, all objects share a single combined UV bounding box
    so their relative UV positions are preserved inside the cell.
    """
    if app_state is None or app_state.selected_strip_index < 0:
        return {'CANCELLED'}

    palette = app_state.palettes[app_state.active_index]
    strip_idx = app_state.selected_strip_index
    dst_bounds = _uv.cell_uv_bounds(palette.grid_cols, palette.grid_rows, strip_idx)

    contexts = find_all_edit_mesh_contexts()
    if not contexts:
        return {'CANCELLED'}

    area_3d, region_3d = _find_3d_viewport()
    if area_3d is None:
        return {'CANCELLED'}

    # Phase 1: Project from view and collect per-object data
    entries = []  # (obj, bm, uv_layer, loops)
    for obj, _bm in contexts:
        bm = bmesh.from_edit_mesh(obj.data)
        if not bm.faces:
            continue

        # Ensure a UV layer exists
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            bm.loops.layers.uv.new("UVMap")
            bmesh.update_edit_mesh(obj.data)

        with bpy.context.temp_override(area=area_3d, region=region_3d,
                                        object=obj, edit_object=obj):
            bpy.ops.uv.project_from_view(scale_to_bounds=True)

        # Refresh bmesh after operator
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            continue

        loops = _get_selected_uv_loops(bm, uv_layer)
        if not loops:
            continue

        entries.append((obj, bm, uv_layer, loops))

    if not entries:
        return {'CANCELLED'}

    # Phase 2: Snap projected UVs into the strip cell
    if merge and len(entries) > 1:
        # Combined bounding box across all objects
        all_us, all_vs = [], []
        for _, _, uv_layer, loops in entries:
            for l in loops:
                all_us.append(l[uv_layer].uv.x)
                all_vs.append(l[uv_layer].uv.y)
        src_bounds = (min(all_us), min(all_vs), max(all_us), max(all_vs))
        transform = _uv.compute_snap_transform(src_bounds, dst_bounds, mode, margin)

        for obj, bm, uv_layer, loops in entries:
            uv_coords = [(l[uv_layer].uv.x, l[uv_layer].uv.y) for l in loops]
            new_coords = _uv.remap_uvs(uv_coords, transform)
            for loop, (nu, nv) in zip(loops, new_coords):
                loop[uv_layer].uv.x = nu
                loop[uv_layer].uv.y = nv
            bmesh.update_edit_mesh(obj.data)
    else:
        for obj, bm, uv_layer, loops in entries:
            src_bounds = _uv_bounds(loops, uv_layer)
            uv_coords = [(l[uv_layer].uv.x, l[uv_layer].uv.y) for l in loops]
            transform = _uv.compute_snap_transform(src_bounds, dst_bounds, mode, margin)
            new_coords = _uv.remap_uvs(uv_coords, transform)
            for loop, (nu, nv) in zip(loops, new_coords):
                loop[uv_layer].uv.x = nu
                loop[uv_layer].uv.y = nv
            bmesh.update_edit_mesh(obj.data)

    return {'FINISHED'}


class PALETTE_OT_uv_project_from_view(bpy.types.Operator):
    """Project UVs from the current 3D Viewport angle"""
    bl_idname = "palette_grid.uv_project_from_view"
    bl_label = "Project From View"
    bl_options = {'REGISTER', 'UNDO'}

    _app_state = None

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('FILL', "Fill", "Stretch UVs to exactly fill the strip rect"),
            ('CONTAIN', "Contain", "Uniform scale to fit inside the strip rect"),
        ],
        default='FILL',
    )

    merge_objects: bpy.props.BoolProperty(
        name="Merge Objects",
        description="Treat all edit-mode objects as one when snapping UVs",
        default=False,
    )

    direction: bpy.props.EnumProperty(
        name="Direction",
        description="Gradient axis direction for UV distribution",
        items=[
            ('DEFAULT', "Default", "Use the palette's default direction"),
            ('Horizontal', "Horizontal", "Distribute along horizontal axis"),
            ('Vertical', "Vertical", "Distribute along vertical axis"),
        ],
        default='DEFAULT',
    )

    margin: bpy.props.FloatProperty(
        name="Margin",
        description="Inset on each side of the cell to prevent color bleed",
        default=0.01, min=0.0, max=0.1, precision=3,
    )

    def execute(self, context):
        d = None if self.direction == 'DEFAULT' else self.direction
        try:
            result = project_from_view_uvs(
                PALETTE_OT_uv_project_from_view._app_state,
                mode=self.mode,
                merge=self.merge_objects,
                direction_override=d,
                margin=self.margin,
            )
        except Exception as e:
            self.report({'INFO'}, f"Could not project UVs: {e}")
            return {'CANCELLED'}
        _apply_recording_prefs()
        return result

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mode")
        layout.prop(self, "merge_objects")
        layout.prop(self, "direction")
        layout.prop(self, "margin")


# -- Registration ----------------------------------------------------------

def register(app_state):
    PALETTE_OT_uv_snap._app_state = app_state
    PALETTE_OT_uv_radial_snap._app_state = app_state
    PALETTE_OT_uv_project_from_view._app_state = app_state
    bpy.utils.register_class(PALETTE_OT_uv_snap)
    bpy.utils.register_class(PALETTE_OT_uv_radial_snap)
    bpy.utils.register_class(PALETTE_OT_uv_project_from_view)


def unregister():
    for cls in (PALETTE_OT_uv_project_from_view, PALETTE_OT_uv_radial_snap,
                PALETTE_OT_uv_snap):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    PALETTE_OT_uv_snap._app_state = None
    PALETTE_OT_uv_radial_snap._app_state = None
    PALETTE_OT_uv_project_from_view._app_state = None
