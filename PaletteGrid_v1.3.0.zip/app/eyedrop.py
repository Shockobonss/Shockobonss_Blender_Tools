# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Eyedropper tool with zoom magnifier � picks color from screen.

Shows a circular zoomed view of pixels around the cursor (Affinity-style),
a center crosshair, and an RGB value pill below. Click to pick, ESC to cancel.

Color sampling uses platform-native screen capture (Windows GDI, Linux X11)
with GPU framebuffer fallback for other platforms.
"""
import platform
import ctypes
import bpy
import gpu
import numpy as np
from mathutils import Matrix

from ..bgui.core import Rect, ui_scale
from ..bgui.renderer import Renderer

# -- Constants ----------------------------------------------
_SAMPLE = 11        # sample NxN pixel block
_ZOOM = 8           # magnification factor
_CIRCLE_D = _SAMPLE * _ZOOM  # 88px
_RADIUS = _CIRCLE_D / 2
_PILL_H = 16
_PILL_GAP = 6
_CURSOR_OFFSET = 24  # offset from cursor

_SPACE_NAMES = (
    'SpaceImageEditor', 'SpaceView3D', 'SpaceNodeEditor',
    'SpaceProperties', 'SpaceOutliner', 'SpaceTextEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor',
    'SpaceGraphEditor', 'SpaceNLA', 'SpaceSequenceEditor',
    'SpaceConsole', 'SpaceInfo', 'SpacePreferences',
    'SpaceFileBrowser',
)

_PLATFORM = platform.system()


# -- Platform screen capture --------------------------------

def _sample_screen(size):
    """Read a size�size pixel block from the screen, centered on the cursor.

    Returns (size, size, 4) float32 RGBA array with alpha=1, or None.
    """
    if _PLATFORM == 'Windows':
        return _sample_screen_win(size)
    if _PLATFORM == 'Linux':
        return _sample_screen_linux(size)
    if _PLATFORM == 'Darwin':
        return _sample_screen_mac(size)
    return None


# -- Windows (GDI) -----------------------------------------

def _sample_screen_win(size):
    import ctypes.wintypes as wt

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [
            ('biSize', wt.DWORD), ('biWidth', ctypes.c_long),
            ('biHeight', ctypes.c_long), ('biPlanes', wt.WORD),
            ('biBitCount', wt.WORD), ('biCompression', wt.DWORD),
            ('biSizeImage', wt.DWORD), ('biXPelsPerMeter', ctypes.c_long),
            ('biYPelsPerMeter', ctypes.c_long), ('biClrUsed', wt.DWORD),
            ('biClrImportant', wt.DWORD),
        ]

    cursor = POINT()
    user32.GetCursorPos(ctypes.byref(cursor))
    half = size // 2
    sx, sy = cursor.x - half, cursor.y - half

    hdc = user32.GetDC(0)
    mem_dc = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, size, size)
    old = gdi32.SelectObject(mem_dc, bmp)
    gdi32.BitBlt(mem_dc, 0, 0, size, size, hdc, sx, sy, 0x00CC0020)

    hdr = BITMAPINFOHEADER()
    hdr.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    hdr.biWidth = size
    hdr.biHeight = -size
    hdr.biPlanes = 1
    hdr.biBitCount = 32
    hdr.biCompression = 0

    buf = (ctypes.c_ubyte * (size * size * 4))()
    gdi32.GetDIBits(mem_dc, bmp, 0, size, buf, ctypes.byref(hdr), 0)

    gdi32.SelectObject(mem_dc, old)
    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(mem_dc)
    user32.ReleaseDC(0, hdc)

    raw = np.frombuffer(buf, dtype=np.uint8).reshape(size, size, 4).copy()
    raw[:, :, [0, 2]] = raw[:, :, [2, 0]]   # BGRX ? RGBX
    pixels = raw.astype(np.float32) / 255.0
    pixels[:, :, 3] = 1.0
    return pixels


# -- Linux (X11) -------------------------------------------

def _sample_screen_linux(size):
    try:
        xlib = ctypes.CDLL('libX11.so.6')
    except OSError:
        return None

    display = xlib.XOpenDisplay(None)
    if not display:
        return None
    root = xlib.XDefaultRootWindow(display)

    class XImage(ctypes.Structure):
        _fields_ = [
            ('width', ctypes.c_int), ('height', ctypes.c_int),
            ('xoffset', ctypes.c_int), ('format', ctypes.c_int),
            ('data', ctypes.c_char_p),
            ('byte_order', ctypes.c_int), ('bitmap_unit', ctypes.c_int),
            ('bitmap_bit_order', ctypes.c_int), ('bitmap_pad', ctypes.c_int),
            ('depth', ctypes.c_int), ('bytes_per_line', ctypes.c_int),
            ('bits_per_pixel', ctypes.c_int),
        ]

    xlib.XGetImage.restype = ctypes.POINTER(XImage)

    # Get cursor position
    rx, ry = ctypes.c_int(), ctypes.c_int()
    wx, wy = ctypes.c_int(), ctypes.c_int()
    mask = ctypes.c_uint()
    child = ctypes.c_ulong()
    root_ret = ctypes.c_ulong()
    xlib.XQueryPointer(display, root,
                       ctypes.byref(root_ret), ctypes.byref(child),
                       ctypes.byref(rx), ctypes.byref(ry),
                       ctypes.byref(wx), ctypes.byref(wy),
                       ctypes.byref(mask))

    half = size // 2
    sx = max(0, rx.value - half)
    sy = max(0, ry.value - half)

    img = xlib.XGetImage(display, root, sx, sy, size, size,
                         ctypes.c_ulong(0xFFFFFFFF), 2)  # AllPlanes, ZPixmap
    if not img:
        xlib.XCloseDisplay(display)
        return None

    bpp = img.contents.bits_per_pixel // 8
    bpl = img.contents.bytes_per_line
    data = ctypes.string_at(img.contents.data, bpl * size)
    raw = np.frombuffer(data, dtype=np.uint8).reshape(size, bpl)[:, :size * bpp]
    raw = raw.reshape(size, size, bpp)

    # X11 ZPixmap is typically BGRX
    pixels = np.zeros((size, size, 4), dtype=np.float32)
    pixels[:, :, 0] = raw[:, :, 2].astype(np.float32) / 255.0  # R
    pixels[:, :, 1] = raw[:, :, 1].astype(np.float32) / 255.0  # G
    pixels[:, :, 2] = raw[:, :, 0].astype(np.float32) / 255.0  # B
    pixels[:, :, 3] = 1.0

    xlib.XDestroyImage(img)
    xlib.XCloseDisplay(display)
    return pixels


# -- macOS (CoreGraphics via ctypes) -----------------------
# Blender's bundled Python does NOT ship pyobjc/Quartz, so we drive
# CoreGraphics directly via ctypes. This works in any Python 3 on macOS.

class _CGPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]


class _CGSize(ctypes.Structure):
    _fields_ = [("width", ctypes.c_double), ("height", ctypes.c_double)]


class _CGRect(ctypes.Structure):
    _fields_ = [("origin", _CGPoint), ("size", _CGSize)]


def _load_cg_frameworks():
    try:
        cg = ctypes.CDLL(
            "/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
        cf = ctypes.CDLL(
            "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
    except OSError:
        return None, None

    cg.CGMainDisplayID.restype = ctypes.c_uint32
    cg.CGEventCreate.argtypes = [ctypes.c_void_p]
    cg.CGEventCreate.restype = ctypes.c_void_p
    cg.CGEventGetLocation.argtypes = [ctypes.c_void_p]
    cg.CGEventGetLocation.restype = _CGPoint
    cg.CGWindowListCreateImage.argtypes = [
        _CGRect, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
    cg.CGWindowListCreateImage.restype = ctypes.c_void_p
    cg.CGImageGetWidth.argtypes = [ctypes.c_void_p]
    cg.CGImageGetWidth.restype = ctypes.c_size_t
    cg.CGImageGetHeight.argtypes = [ctypes.c_void_p]
    cg.CGImageGetHeight.restype = ctypes.c_size_t
    cg.CGImageGetBytesPerRow.argtypes = [ctypes.c_void_p]
    cg.CGImageGetBytesPerRow.restype = ctypes.c_size_t
    cg.CGImageGetDataProvider.argtypes = [ctypes.c_void_p]
    cg.CGImageGetDataProvider.restype = ctypes.c_void_p
    cg.CGDataProviderCopyData.argtypes = [ctypes.c_void_p]
    cg.CGDataProviderCopyData.restype = ctypes.c_void_p
    cg.CGColorSpaceCreateDeviceRGB.restype = ctypes.c_void_p
    cg.CGColorSpaceRelease.argtypes = [ctypes.c_void_p]
    cg.CGBitmapContextCreate.argtypes = [
        ctypes.c_void_p, ctypes.c_size_t, ctypes.c_size_t,
        ctypes.c_size_t, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_uint32]
    cg.CGBitmapContextCreate.restype = ctypes.c_void_p
    cg.CGContextDrawImage.argtypes = [
        ctypes.c_void_p, _CGRect, ctypes.c_void_p]
    cg.CGBitmapContextCreateImage.argtypes = [ctypes.c_void_p]
    cg.CGBitmapContextCreateImage.restype = ctypes.c_void_p
    cg.CGContextRelease.argtypes = [ctypes.c_void_p]
    cg.CGImageRelease.argtypes = [ctypes.c_void_p]

    cf.CFDataGetLength.argtypes = [ctypes.c_void_p]
    cf.CFDataGetLength.restype = ctypes.c_long
    cf.CFDataGetBytePtr.argtypes = [ctypes.c_void_p]
    cf.CFDataGetBytePtr.restype = ctypes.POINTER(ctypes.c_ubyte)
    cf.CFRelease.argtypes = [ctypes.c_void_p]

    return cg, cf


# Loaded once on first import. None on non-macOS or framework load failure.
_CG, _CF = (None, None)
if _PLATFORM == 'Darwin':
    _CG, _CF = _load_cg_frameworks()

# CoreGraphics constants
_K_WINDOW_LIST_ON_SCREEN = 1
_K_NULL_WINDOW_ID = 0
_K_WINDOW_IMAGE_DEFAULT = 0
_K_ALPHA_NONE_SKIP_LAST = 5
_K_BYTE_ORDER_32_BIG = 4 << 12  # 0x4000


def _sample_screen_mac(size):
    if _CG is None or _CF is None:
        return None

    # Cursor position in display coordinates (points, top-left origin)
    event = _CG.CGEventCreate(None)
    if not event:
        return None
    cursor = _CG.CGEventGetLocation(event)
    _CF.CFRelease(event)

    half = size // 2
    rect = _CGRect(
        _CGPoint(cursor.x - half, cursor.y - half),
        _CGSize(size, size))

    src = _CG.CGWindowListCreateImage(
        rect,
        _K_WINDOW_LIST_ON_SCREEN,
        _K_NULL_WINDOW_ID,
        _K_WINDOW_IMAGE_DEFAULT)
    if not src:
        return None

    cs = ctx = rendered = cf_data = None
    try:
        src_w = _CG.CGImageGetWidth(src)
        src_h = _CG.CGImageGetHeight(src)
        if src_w == 0 or src_h == 0:
            return None

        # Render through a known RGBA8 context to normalize HDR / wide-gamut /
        # byte-order / row-padding variations across displays.
        cs = _CG.CGColorSpaceCreateDeviceRGB()
        bitmap_info = _K_ALPHA_NONE_SKIP_LAST | _K_BYTE_ORDER_32_BIG
        ctx = _CG.CGBitmapContextCreate(
            None, src_w, src_h, 8, src_w * 4, cs, bitmap_info)
        if not ctx:
            return None

        _CG.CGContextDrawImage(
            ctx, _CGRect(_CGPoint(0, 0), _CGSize(src_w, src_h)), src)

        rendered = _CG.CGBitmapContextCreateImage(ctx)
        if not rendered:
            return None

        provider = _CG.CGImageGetDataProvider(rendered)
        cf_data = _CG.CGDataProviderCopyData(provider)
        if not cf_data:
            return None

        rendered_bpr = _CG.CGImageGetBytesPerRow(rendered)
        data_len = _CF.CFDataGetLength(cf_data)
        byte_ptr = _CF.CFDataGetBytePtr(cf_data)
        raw_bytes = ctypes.string_at(byte_ptr, data_len)

        arr = np.frombuffer(raw_bytes, dtype=np.uint8)
        arr = arr[: rendered_bpr * src_h].reshape(src_h, rendered_bpr)
        arr = arr[:, : src_w * 4].reshape(src_h, src_w, 4)
        # Bytes are RGBX in memory order — no channel swap needed.

        # On Retina, src_w/src_h are physical pixels (2× the requested points).
        # Center-crop size×size; the cursor sits at the center, so the picked
        # pixel remains correct.
        cy0 = max(0, (src_h - size) // 2)
        cx0 = max(0, (src_w - size) // 2)
        crop = arr[cy0:cy0 + size, cx0:cx0 + size]
        if crop.shape[0] != size or crop.shape[1] != size:
            return None

        pixels = crop.astype(np.float32) / 255.0
        pixels[:, :, 3] = 1.0
        return pixels
    finally:
        if cf_data:
            _CF.CFRelease(cf_data)
        if rendered:
            _CG.CGImageRelease(rendered)
        if ctx:
            _CG.CGContextRelease(ctx)
        if cs:
            _CG.CGColorSpaceRelease(cs)
        _CG.CGImageRelease(src)


# -- Module-level state (survives operator StructRNA lifecycle) --

_S = None  # Active eyedrop state dict, or None when inactive

# Flag: True when platform-native screen capture fails (e.g. macOS without Quartz).
# When set, sampling is deferred to draw callbacks via GPU framebuffer readback.
_use_gpu_fallback = False


# -- Operator -----------------------------------------------

class PALETTE_OT_eyedrop(bpy.types.Operator):
    """Pick a color from any screen area with a zoomed magnifier"""
    bl_idname = "palette.eyedrop"
    bl_label = "Eyedropper"
    bl_options = {'INTERNAL'}

    _on_pick_callback = None
    _on_finish_callback = None

    def invoke(self, context, event):
        global _S, _use_gpu_fallback
        _S = {
            'mx': event.mouse_x,
            'my': event.mouse_y,
            'color': (0.0, 0.0, 0.0, 1.0),
            'zoom_tex': None,
            'pixels': None,
            'tex_dirty': False,
            'cursor_in_ui': False,
            'handlers': [],
        }

        for name in _SPACE_NAMES:
            space_cls = getattr(bpy.types, name, None)
            if space_cls:
                h = space_cls.draw_handler_add(
                    _draw_overlay, (), 'WINDOW', 'POST_PIXEL')
                _S['handlers'].append((space_cls, h, 'WINDOW'))
                # UI-region handler draws on top of sidebar panels/popups
                try:
                    h2 = space_cls.draw_handler_add(
                        _draw_overlay_top, (), 'UI', 'POST_PIXEL')
                    _S['handlers'].append((space_cls, h2, 'UI'))
                except TypeError:
                    pass  # Space type has no 'UI' region

        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('EYEDROPPER')

        # Initial sample
        px = _sample_screen(_SAMPLE)
        if px is not None:
            _S['pixels'] = px
            half = _SAMPLE // 2
            _S['color'] = tuple(px[half, half])
            _S['tex_dirty'] = True
            _use_gpu_fallback = False
        else:
            # Platform capture failed (e.g. macOS without Quartz) �
            # defer sampling to draw callbacks via GPU framebuffer
            _use_gpu_fallback = True

        for area in context.screen.areas:
            area.tag_redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if _S is None:
            return {'CANCELLED'}

        evt_type = event.type
        evt_value = event.value

        if evt_type == 'MOUSEMOVE':
            _S['mx'] = event.mouse_x
            _S['my'] = event.mouse_y
            # Determine if cursor is in a UI region so the WINDOW handler
            # can defer drawing (avoids double magnifier at the boundary).
            in_ui = False
            for area in context.screen.areas:
                for r in area.regions:
                    if r.type == 'UI' and r.width > 0:
                        if (r.x <= _S['mx'] < r.x + r.width and
                                r.y <= _S['my'] < r.y + r.height):
                            in_ui = True
                            break
                if in_ui:
                    break
            _S['cursor_in_ui'] = in_ui
            if not _use_gpu_fallback:
                px = _sample_screen(_SAMPLE)
                if px is not None:
                    _S['pixels'] = px
                    half = _SAMPLE // 2
                    _S['color'] = tuple(float(c) for c in px[half, half])
                    _S['tex_dirty'] = True
            # When using GPU fallback, sampling happens in the draw callback
            for area in context.screen.areas:
                area.tag_redraw()
            return {'RUNNING_MODAL'}

        if evt_type == 'LEFTMOUSE' and evt_value == 'PRESS':
            if not _use_gpu_fallback:
                px = _sample_screen(_SAMPLE)
                if px is not None:
                    half = _SAMPLE // 2
                    _S['color'] = tuple(float(c) for c in px[half, half])
            # GPU fallback: _S['color'] was already set by the last draw callback
            color = _S['color']
            self._cleanup(context)
            cb = PALETTE_OT_eyedrop._on_pick_callback
            if cb:
                cb(color)
            fin = PALETTE_OT_eyedrop._on_finish_callback
            if fin:
                fin()
            return {'FINISHED'}

        if evt_type in ('RIGHTMOUSE', 'ESC') and evt_value == 'PRESS':
            self._cleanup(context)
            fin = PALETTE_OT_eyedrop._on_finish_callback
            if fin:
                fin()
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def _cleanup(self, context):
        global _S
        if _S:
            for space_cls, h, rt in _S['handlers']:
                space_cls.draw_handler_remove(h, rt)
            _S = None
        context.window.cursor_modal_restore()
        for area in context.screen.areas:
            area.tag_redraw()


# -- Draw helpers -------------------------------------------

def _sample_gpu(region, size):
    """Read a size�size pixel block from the GPU framebuffer at the cursor.

    Works on all platforms (Metal, Vulkan, OpenGL) but only within
    Blender's own windows.  Must be called from a draw callback
    (active GPU context required).

    Returns (size, size, 4) float32 RGBA array, or None on failure.
    """
    if _S is None:
        return None
    half = size // 2
    # Region-local cursor position (bottom-left origin for GPU)
    rx = _S['mx'] - region.x - half
    ry = _S['my'] - region.y - half

    # Clamp � if cursor is near region edge, shift the sample rect inward
    if rx < 0:
        rx = 0
    if ry < 0:
        ry = 0
    if rx + size > region.width:
        rx = max(0, region.width - size)
    if ry + size > region.height:
        ry = max(0, region.height - size)

    if rx < 0 or ry < 0 or size <= 0:
        return None

    try:
        fb = gpu.state.active_framebuffer_get()
        buf = fb.read_color(rx, ry, size, size, 4, 0, 'FLOAT')
        pixels = np.array(buf, dtype=np.float32).reshape(size, size, 4)
        return pixels
    except Exception:
        return None

def _srgb_to_linear(c):
    """Convert sRGB channel values [0-1] to linear light."""
    return np.where(c <= 0.04045, c / 12.92,
                    ((c + 0.055) / 1.055) ** 2.4)


def _update_zoom_texture():
    """Build GPU texture from pixel data when dirty."""
    if _S['tex_dirty'] and _S['pixels'] is not None:
        _S['tex_dirty'] = False
        zoomed = np.repeat(
            np.repeat(_S['pixels'], _ZOOM, axis=0), _ZOOM, axis=1)
        # Flip vertically: screen capture is top-down, GPU textures have
        # bottom-left origin � without flip the content appears Y-mirrored.
        zoomed = np.flipud(zoomed)
        size = _SAMPLE * _ZOOM
        flat = zoomed.flatten()
        gpu_buf = gpu.types.Buffer('FLOAT', len(flat), flat.tolist())
        _S['zoom_tex'] = gpu.types.GPUTexture(
            (size, size), format='RGBA32F', data=gpu_buf)


def _draw_magnifier(renderer, rx, ry, rw, rh):
    """Core magnifier drawing: circle, crosshair, color pill."""
    sc = ui_scale()
    my = rh - ry

    circle_d = _CIRCLE_D * sc
    radius = circle_d / 2
    pill_h = _PILL_H * sc
    pill_gap = _PILL_GAP * sc
    cursor_off = _CURSOR_OFFSET * sc

    ox = rx + cursor_off
    oy = my - cursor_off - circle_d

    if ox + circle_d > rw - 4 * sc:
        ox = rx - cursor_off - circle_d
    if oy < 4 * sc:
        oy = my + cursor_off
    if oy + circle_d + pill_gap + pill_h > rh - 4 * sc:
        oy = rh - 4 * sc - circle_d - pill_gap - pill_h

    circle_rect = Rect(ox, oy, circle_d, circle_d)

    renderer.draw_shadow(circle_rect, (0, 0, 0, 0.25), 6 * sc, (0, 4 * sc),
                         radius=radius)

    if _S['zoom_tex']:
        renderer.draw_texture_rounded(
            _S['zoom_tex'], circle_rect,
            border_radius=radius, opacity=1.0)
    else:
        renderer.draw_rounded_rect(
            circle_rect, (0.12, 0.12, 0.14, 1.0), radius)

    renderer.draw_rounded_rect(
        circle_rect, (0, 0, 0, 0), radius,
        border_color=(0.04, 0.04, 0.04, 1.0),
        border_width=3 * sc)

    inset = 3 * sc
    inner_rect = Rect(ox + inset, oy + inset,
                       circle_d - inset * 2, circle_d - inset * 2)
    renderer.draw_rounded_rect(
        inner_rect, (0, 0, 0, 0), (circle_d - inset * 2) / 2,
        border_color=(0.34, 0.34, 0.38, 1.0),
        border_width=2 * sc)

    ch = 6 * sc
    ch_rect = Rect(ox + circle_d / 2 - ch / 2,
                    oy + circle_d / 2 - ch / 2, ch, ch)
    renderer.draw_rect_outline(ch_rect, (0, 0, 0, 1), 1 * sc)
    ch_inner = Rect(ch_rect.x + 1 * sc, ch_rect.y + 1 * sc, ch - 2 * sc, ch - 2 * sc)
    renderer.draw_rect_outline(ch_inner, (1, 1, 1, 1), 1 * sc)

    r, g, b, a = _S['color']
    pill_rect = Rect(ox, oy + circle_d + pill_gap,
                      circle_d, pill_h)
    renderer.draw_rounded_rect(
        pill_rect, (r, g, b, 1.0), pill_h / 2,
        border_color=(0, 0, 0, 0.4), border_width=0.5 * sc)

    ri, gi, bi = int(r * 255), int(g * 255), int(b * 255)
    text = f"R:{ri} G:{gi} B:{bi}"
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    tc = (0, 0, 0, 1) if lum > 0.45 else (1, 1, 1, 1)
    _, th = Renderer.measure_text(text, 10, font_weight='medium')
    renderer.draw_text(text, pill_rect.x + 8 * sc,
                       pill_rect.y + (pill_h - th) / 2,
                       size=10, color=tc, font_weight='medium')


# -- WINDOW draw handler -----------------------------------

def _draw_overlay():
    """POST_PIXEL/WINDOW: draw magnifier in the main content region."""
    if _S is None:
        return
    # Skip if cursor is in a UI region � the UI handler draws on top instead
    if _S.get('cursor_in_ui'):
        return
    region = bpy.context.region
    if not region:
        return

    rx = _S['mx'] - region.x
    ry = _S['my'] - region.y

    if not (0 <= rx < region.width and 0 <= ry < region.height):
        return

    # GPU fallback: sample framebuffer BEFORE drawing our overlay
    if _use_gpu_fallback:
        px = _sample_gpu(region, _SAMPLE)
        if px is not None:
            _S['pixels'] = px
            half = _SAMPLE // 2
            _S['color'] = tuple(float(c) for c in px[half, half])
            _S['tex_dirty'] = True

    _update_zoom_texture()
    renderer = Renderer(region.height)
    _draw_magnifier(renderer, rx, ry, region.width, region.height)


# -- UI draw handler (draws on top of sidebar panels & popups) --

def _draw_overlay_top():
    """POST_PIXEL/UI: draw magnifier on top of sidebar panel content.

    Uses native UI-region coordinates � no viewport override needed.
    When the cursor is over the sidebar, this handler draws the
    magnifier on top of all panel/popup content in that region.
    """
    if _S is None:
        return
    region = bpy.context.region
    if not region or region.width < 1:
        return

    rx = _S['mx'] - region.x
    ry = _S['my'] - region.y

    if not (0 <= rx < region.width and 0 <= ry < region.height):
        return

    # GPU fallback: sample framebuffer BEFORE drawing our overlay
    if _use_gpu_fallback:
        px = _sample_gpu(region, _SAMPLE)
        if px is not None:
            _S['pixels'] = px
            half = _SAMPLE // 2
            _S['color'] = tuple(float(c) for c in px[half, half])
            _S['tex_dirty'] = True

    _update_zoom_texture()
    renderer = Renderer(region.height)
    _draw_magnifier(renderer, rx, ry, region.width, region.height)


# -- Registration -------------------------------------------

def register():
    bpy.utils.register_class(PALETTE_OT_eyedrop)


def unregister():
    global _S
    if _S:
        for space_cls, h, rt in _S['handlers']:
            try:
                space_cls.draw_handler_remove(h, rt)
            except Exception:
                pass
        _S = None
    bpy.utils.unregister_class(PALETTE_OT_eyedrop)
