# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Color Picker popup � single-color editing for flat strips.

Same picker widgets as the Gradient Editor (SV picker, hue slider,
transparency slider, last-used colors), but without the gradient bar
and stop management controls.

Top section matches Figma spec: split color swatch | hex input | opacity | pencil.
"""
import os

from .. import bgui
from ..bgui.core import Rect, Widget, ui_scale

# Reuse widgets and state from gradient popup
from .gradient_popup import (
    GradientState, GradientStop,
    _SVPickerWidget, _HueSlider, _TransparencySlider,
    _ColorLump, _ToolButton,
    _DragHandle,
    _build_effects_section,
    _animate_popup_section,
    POPUP_BG, CONTAINER, INPUT_BG, INPUT_BORDER,
    TEXT_COLOR, SEPARATOR, WHITE, TRANSPARENT,
    parse_clipboard_color,
)

_ASSETS = os.path.join(os.path.dirname(__file__), "assets")


# -- Color Picker specific widgets -------------------------

class _SplitSwatchWidget(Widget):
    """37�17 split swatch: current color (left) | old color (right).

    Rounded mask (r=2) clips both halves.  The 'old_color' is captured
    when the popup opens and stays fixed; 'current' updates live.
    """

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self.old_color = (1.0, 0.5, 0.0, 1.0)   # set on open

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        half_w = cr.width / 2

        # Current color � left half
        stop = self.gstate.selected_stop
        cur = stop.color if stop else (0.5, 0.5, 0.5, 1.0)
        r2 = 2 * sc
        renderer.draw_rounded_rect(
            Rect(cr.x, cr.y, half_w, cr.height),
            cur, (r2, 0, 0, r2),
        )

        # Old color � right half
        renderer.draw_rounded_rect(
            Rect(cr.x + half_w, cr.y, cr.width - half_w, cr.height),
            self.old_color, (0, r2, r2, 0),
        )

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            return False
        cr = self.content_rect
        half_w = cr.width / 2
        if x >= cr.x + half_w:
            # Click on old color half � restore it
            stop = self.gstate.selected_stop
            if stop:
                import colorsys
                stop.color = self.old_color
                r, g, b = self.old_color[:3]
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                self.gstate.hue = h
                self.gstate.saturation = s
                self.gstate.value = v
                self.gstate.opacity = self.old_color[3] if len(self.old_color) > 3 else 1.0
                self.gstate.notify()
        return True


class _HexCodeField(Widget):
    """90�17 editable hex code field for the selected color."""

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._editing = False
        self._buf = ""
        self._cursor_pos = 0
        self._sel_start = None
        self._self_notify = False
        state.add_listener(self._on_state_change)

    def _on_state_change(self, st):
        if self._self_notify:
            self._self_notify = False
        elif self._editing:
            self._editing = False
        stop = st.selected_stop
        if stop:
            r, g, b = stop.color[:3]
            self._buf = "{:02X}{:02X}{:02X}".format(
                int(r * 255), int(g * 255), int(b * 255))

    def _start_edit(self):
        stop = self.gstate.selected_stop
        if not stop:
            return
        r, g, b = stop.color[:3]
        self._buf = "{:02X}{:02X}{:02X}".format(
            int(r * 255), int(g * 255), int(b * 255))
        self._cursor_pos = len(self._buf)
        self._editing = True
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        """Commit and exit edit mode (called by global blur)."""
        if self._editing:
            self._commit()

    def _commit(self):
        import colorsys
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        stop = self.gstate.selected_stop
        if stop:
            raw = self._buf.strip().lstrip('#')
            if len(raw) == 6:
                try:
                    ri = int(raw[0:2], 16)
                    gi = int(raw[2:4], 16)
                    bi = int(raw[4:6], 16)
                    old_a = stop.color[3] if len(stop.color) > 3 else 1.0
                    stop.color = (ri / 255.0, gi / 255.0, bi / 255.0, old_a)
                    r, g, b = stop.color[:3]
                    h, s, v = colorsys.rgb_to_hsv(r, g, b)
                    self.gstate.hue = h
                    self.gstate.saturation = s
                    self.gstate.value = v
                except ValueError:
                    pass
        self._editing = False
        self._self_notify = True
        self.gstate.notify()

    def _del_sel(self):
        """Delete selected range from buffer. Returns True if selection existed."""
        if self._sel_start is None:
            return False
        s, e = min(self._sel_start, self._cursor_pos), max(self._sel_start, self._cursor_pos)
        self._buf = self._buf[:s] + self._buf[e:]
        self._cursor_pos = s
        self._sel_start = None
        return True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        if not self._editing:
            return False
        if key == 'RET':
            self._commit()
            return True
        if key == 'ESC':
            self._editing = False
            self._sel_start = None
            self.gstate.notify()
            return True
        if ctrl and key == 'A':
            self._sel_start = 0
            self._cursor_pos = len(self._buf)
            return True
        if key == 'BACK_SPACE':
            if not self._del_sel():
                if self._cursor_pos > 0:
                    self._buf = self._buf[:self._cursor_pos - 1] + self._buf[self._cursor_pos:]
                    self._cursor_pos -= 1
            return True
        if key == 'DEL':
            if not self._del_sel():
                if self._cursor_pos < len(self._buf):
                    self._buf = self._buf[:self._cursor_pos] + self._buf[self._cursor_pos + 1:]
            return True
        if key == 'LEFT_ARROW':
            self._sel_start = None
            self._cursor_pos = max(0, self._cursor_pos - 1)
            return True
        if key == 'RIGHT_ARROW':
            self._sel_start = None
            self._cursor_pos = min(len(self._buf), self._cursor_pos + 1)
            return True
        if key == 'HOME':
            self._sel_start = None
            self._cursor_pos = 0
            return True
        if key == 'END':
            self._sel_start = None
            self._cursor_pos = len(self._buf)
            return True
        if ctrl and key == 'V':
            self._del_sel()
            import bpy
            clip = (bpy.context.window_manager.clipboard or "").strip().lstrip('#')
            for ch in clip:
                if ch.upper() in '0123456789ABCDEF' and len(self._buf) < 6:
                    self._buf = self._buf[:self._cursor_pos] + ch.upper() + self._buf[self._cursor_pos:]
                    self._cursor_pos += 1
            return True
        if ascii_char and not ctrl:
            self._del_sel()
            if ascii_char.upper() in '0123456789ABCDEF' and len(self._buf) < 6:
                self._buf = self._buf[:self._cursor_pos] + ascii_char.upper() + self._buf[self._cursor_pos:]
                self._cursor_pos += 1
            return True
        return False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        from ..bgui.renderer import Renderer as R

        border_c = (0.784, 1.0, 0.0, 0.8) if self._editing else INPUT_BORDER
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=border_c, border_width=1 * sc,
        )
        stop = self.gstate.selected_stop
        if not stop:
            return
        r, g, b = stop.color[:3]

        if self._editing:
            hex_str = "#" + self._buf
        else:
            hex_str = "#{:02X}{:02X}{:02X}".format(
                int(r * 255), int(g * 255), int(b * 255))

        tw, ref_h = R.measure_text(hex_str, 11, font_weight='semibold')
        tx = cr.x + 8 * sc
        ty = cr.y + (cr.height - ref_h) / 2
        color = WHITE if self._editing else TEXT_COLOR
        renderer.draw_text(hex_str, tx, ty, size=11,
                           color=color, font_weight='semibold',
                           ref_height=ref_h)

        if self._editing:
            before = "#" + self._buf[:self._cursor_pos]
            cw, _ = R.measure_text(before, 11, font_weight='semibold')
            # Selection highlight
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw, _ = R.measure_text("#" + self._buf[:s], 11, font_weight='semibold')
                ew, _ = R.measure_text("#" + self._buf[:e], 11, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(tx + sw, cr.y + 2 * sc, ew - sw, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            renderer.draw_rounded_rect(
                Rect(tx + cw, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            if self._editing:
                self._commit()
            return False
        self._start_edit()
        return True


class _OpacityField(Widget):
    """32�17 editable opacity percentage field."""

    def __init__(self, state: GradientState, **kwargs):
        super().__init__(**kwargs)
        self.gstate = state
        self._editing = False
        self._buf = ""
        self._cursor_pos = 0
        self._sel_start = None
        self._self_notify = False
        state.add_listener(self._on_state_change)

    def _on_state_change(self, st):
        if self._self_notify:
            self._self_notify = False
        elif self._editing:
            self._editing = False
        stop = st.selected_stop
        if stop:
            a = stop.color[3] if len(stop.color) > 3 else 1.0
            self._buf = "{}".format(int(a * 100))

    def _start_edit(self):
        stop = self.gstate.selected_stop
        if not stop:
            return
        a = stop.color[3] if len(stop.color) > 3 else 1.0
        self._buf = "{}".format(int(a * 100))
        self._cursor_pos = len(self._buf)
        self._editing = True
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        """Commit and exit edit mode (called by global blur)."""
        if self._editing:
            self._commit()

    def _commit(self):
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        stop = self.gstate.selected_stop
        if stop:
            raw = self._buf.strip().rstrip('%')
            try:
                val = max(0, min(100, int(raw)))
                r, g, b = stop.color[:3]
                stop.color = (r, g, b, val / 100.0)
                self.gstate.opacity = val / 100.0
            except ValueError:
                pass
        self._editing = False
        self._self_notify = True
        self.gstate.notify()

    def _del_sel(self):
        if self._sel_start is None:
            return False
        s, e = min(self._sel_start, self._cursor_pos), max(self._sel_start, self._cursor_pos)
        self._buf = self._buf[:s] + self._buf[e:]
        self._cursor_pos = s
        self._sel_start = None
        return True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        if not self._editing:
            return False
        if key == 'RET':
            self._commit()
            return True
        if key == 'ESC':
            self._editing = False
            self._sel_start = None
            self.gstate.notify()
            return True
        if ctrl and key == 'A':
            self._sel_start = 0
            self._cursor_pos = len(self._buf)
            return True
        if key == 'BACK_SPACE':
            if not self._del_sel():
                if self._cursor_pos > 0:
                    self._buf = self._buf[:self._cursor_pos - 1] + self._buf[self._cursor_pos:]
                    self._cursor_pos -= 1
            return True
        if key == 'DEL':
            if not self._del_sel():
                if self._cursor_pos < len(self._buf):
                    self._buf = self._buf[:self._cursor_pos] + self._buf[self._cursor_pos + 1:]
            return True
        if key == 'LEFT_ARROW':
            self._sel_start = None
            self._cursor_pos = max(0, self._cursor_pos - 1)
            return True
        if key == 'RIGHT_ARROW':
            self._sel_start = None
            self._cursor_pos = min(len(self._buf), self._cursor_pos + 1)
            return True
        if key == 'HOME':
            self._sel_start = None
            self._cursor_pos = 0
            return True
        if key == 'END':
            self._sel_start = None
            self._cursor_pos = len(self._buf)
            return True
        if ctrl and key == 'V':
            self._del_sel()
            import bpy
            clip = (bpy.context.window_manager.clipboard or "").strip().rstrip('%')
            try:
                val = float(clip)
                if val <= 1.0 and '.' in clip:
                    val = int(val * 100)
                else:
                    val = int(val)
                val = max(0, min(100, val))
                self._buf = str(val)
                self._cursor_pos = len(self._buf)
            except ValueError:
                pass
            return True
        if ascii_char and not ctrl:
            self._del_sel()
            if ascii_char in '0123456789' and len(self._buf) < 3:
                self._buf = self._buf[:self._cursor_pos] + ascii_char + self._buf[self._cursor_pos:]
                self._cursor_pos += 1
            return True
        return False

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        from ..bgui.renderer import Renderer as R

        border_c = (0.784, 1.0, 0.0, 0.8) if self._editing else INPUT_BORDER
        renderer.draw_rounded_rect(cr, INPUT_BG, 4 * sc)
        renderer.draw_rounded_rect(
            cr, TRANSPARENT, 4 * sc,
            border_color=border_c, border_width=1 * sc,
        )
        stop = self.gstate.selected_stop
        if not stop:
            return
        a = stop.color[3] if len(stop.color) > 3 else 1.0

        if self._editing:
            text = self._buf + "%"
        else:
            text = "{}%".format(int(a * 100))

        tw, ref_h = R.measure_text(text, 11, font_weight='semibold')
        tx = cr.x + (cr.width - tw) / 2
        ty = cr.y + (cr.height - ref_h) / 2
        color = WHITE if self._editing else TEXT_COLOR
        renderer.draw_text(text, tx, ty, size=11,
                           color=color, font_weight='semibold',
                           ref_height=ref_h)

        if self._editing:
            before = self._buf[:self._cursor_pos]
            cw, _ = R.measure_text(before, 11, font_weight='semibold')
            full = self._buf + "%"
            fw, _ = R.measure_text(full, 11, font_weight='semibold')
            tx_base = cr.x + (cr.width - fw) / 2
            # Selection highlight
            if self._sel_start is not None:
                s = min(self._sel_start, self._cursor_pos)
                e = max(self._sel_start, self._cursor_pos)
                sw, _ = R.measure_text(self._buf[:s], 11, font_weight='semibold')
                ew, _ = R.measure_text(self._buf[:e], 11, font_weight='semibold')
                renderer.draw_rounded_rect(
                    Rect(tx_base + sw, cr.y + 2 * sc, ew - sw, cr.height - 4 * sc),
                    (0.784, 1.0, 0.0, 0.3), 2 * sc)
            renderer.draw_rounded_rect(
                Rect(tx_base + cw, cr.y + 3 * sc, 1.5 * sc, cr.height - 6 * sc),
                WHITE, 0)

    def handle_mouse_press(self, x, y):
        if not self.rect or not self.rect.contains(x, y):
            if self._editing:
                self._commit()
            return False
        self._start_edit()
        return True


def build_color_picker_popup(on_close=None):
    """Build the Color Picker modal popup.

    Returns:
        (popup, open_fn, state) � call open_fn(color) to show with a color.
    """
    state = GradientState()
    # Start with a single stop � no gradient bar shown
    state.stops = [GradientStop(0.0, (1.0, 0.5, 0.0, 1.0))]
    state.selected_index = 0
    _params_expanded = [False]
    _adj_section = [None]
    _popup_ref = [None]

    # -- Header ------------------------------------
    def _close(btn=None):
        # Push current color to last-used on close
        stop = state.selected_stop
        if stop:
            state.push_last_used(stop.color)
        popup.hide()
        if on_close:
            on_close(state)

    close_btn = bgui.Button(
        "✕",
        style=bgui.Style(
            background_color=TRANSPARENT,
            border_radius=4,
            width=20, height=20,
            font_size=13,
            font_color=TEXT_COLOR,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
            hover_style={"background_color": (1, 1, 1, 0.1)},
        ),
        on_click=_close,
    )

    params_btn = _ToolButton(
        os.path.join(_ASSETS, "Params.svg"),
        style=bgui.Style(width=22, height=20),
    )

    def _toggle_params(btn):
        _params_expanded[0] = not _params_expanded[0]
        _animate_popup_section(_adj_section[0], _params_expanded[0], _popup_ref[0])

    params_btn.on_click = _toggle_params

    header_right = bgui.Row(
        style=bgui.Style(
            gap=4,
            alignment=bgui.Alignment.CENTER,
        ),
        children=[params_btn, close_btn],
    )

    header = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            alignment=bgui.Alignment.CENTER,
            padding=bgui.EdgeInsets(9, 9, 5, 9),
        ),
        children=[
            bgui.Label("Color Picker", style=bgui.Style(
                font_size=13, font_weight="bold", font_color=TEXT_COLOR,
            )),
            header_right,
        ],
    )

    # -- Separator ---------------------------------
    def _sep():
        return bgui.Box(style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            height=1,
            background_color=SEPARATOR,
        ))

    # -- Tool Row: swatch | hex | opacity | pencil --
    split_swatch = _SplitSwatchWidget(
        state,
        style=bgui.Style(width=44, height=20),
    )

    hex_field = _HexCodeField(
        state,
        style=bgui.Style(width=108, height=20),
    )

    opacity_field = _OpacityField(
        state,
        style=bgui.Style(width=38, height=20),
    )

    def _start_eyedrop(btn):
        import bpy, colorsys
        from .eyedrop import PALETTE_OT_eyedrop
        def _on_pick(color):
            stop = state.selected_stop
            if stop:
                stop.color = color
                r, g, b = color[:3]
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                state.hue = h
                state.saturation = s
                state.value = v
                state.opacity = color[3] if len(color) > 3 else 1.0
                state.notify()
        PALETTE_OT_eyedrop._on_pick_callback = _on_pick
        PALETTE_OT_eyedrop._on_finish_callback = None
        bpy.ops.palette.eyedrop('INVOKE_DEFAULT')

    color_picker_btn = _ToolButton(
        os.path.join(_ASSETS, "ColorEyedrop.svg"),
        on_click=_start_eyedrop,
        style=bgui.Style(width=22, height=20),
    )

    tool_row = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
            gap=5,
        ),
        children=[split_swatch, hex_field, opacity_field, color_picker_btn],
    )

    # -- Color Picker Area -------------------------
    sv_picker = _SVPickerWidget(
        state,
        style=bgui.Style(width=164, height=164, border_radius=9),
    )

    transparency_slider = _TransparencySlider(
        state,
        style=bgui.Style(width=26, height=164),
    )

    hue_slider = _HueSlider(
        state,
        style=bgui.Style(width=26, height=164),
    )

    picker_area = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=7,
            alignment=bgui.Alignment.START,
        ),
        children=[sv_picker, transparency_slider, hue_slider],
    )

    # -- Last Used ---------------------------------
    last_used_label = bgui.Label("Last Used", style=bgui.Style(
        font_size=11, font_weight="semibold", font_color=TEXT_COLOR,
    ))

    lumps = []
    for i, color in enumerate(state.last_used):
        lumps.append(_ColorLump(
            color, state=state, lump_index=i,
            style=bgui.Style(width=29, height=29),
        ))

    last_used_row = bgui.Row(
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            gap=9,
            alignment=bgui.Alignment.CENTER,
        ),
        children=lumps,
    )

    effects_section = _build_effects_section(state, visible=False)
    _adj_section[0] = effects_section

    # -- Assemble ----------------------------------
    drag_handle = _DragHandle(
        _popup_ref,
        style=bgui.Style(
            width=40, height=14,
            alignment=bgui.Alignment.CENTER,
        ),
    )

    popup_content = bgui.ScrollBox(
        scroll_speed=24.0,
        style=bgui.Style(
            width=270,
            height_policy=bgui.SizePolicy.FILL,
            background_color=POPUP_BG,
            border_radius=13,
            padding=bgui.EdgeInsets(4, 7, 7, 7),
            gap=3,
            alignment=bgui.Alignment.CENTER,
        ),
        children=[
            bgui.Row(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    main_alignment=bgui.MainAxisAlignment.CENTER,
                ),
                children=[drag_handle],
            ),
            bgui.Column(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    background_color=CONTAINER,
                    border_radius=7,
                    padding=bgui.EdgeInsets(10, 13, 12, 13),
                    gap=9,
                ),
                children=[
                    header,
                    _sep(),
                    tool_row,
                    _sep(),
                    picker_area,
                    _sep(),
                    last_used_label,
                    last_used_row,
                    effects_section,
                ],
            ),
        ],
    )

    popup = bgui.ModalPopup("color_picker_popup", space_type='IMAGE_EDITOR')
    popup.set_root(popup_content)
    popup.on_dismiss = _close
    _popup_ref[0] = popup

    # Ctrl+Z / Ctrl+Shift+Z undo/redo at popup root level
    def _popup_key_handler(key, shift=False, ctrl=False, ascii_char=""):
        if ctrl and key == 'Z':
            if shift:
                state.redo()
            else:
                state.undo()
            return True
        if ctrl and key == 'V':
            import bpy, colorsys
            clip = bpy.context.window_manager.clipboard or ""
            color = parse_clipboard_color(clip)
            if color:
                stop = state.selected_stop
                if stop:
                    state.push_undo()
                    stop.color = color
                    r, g, b = color[:3]
                    h, s, v = colorsys.rgb_to_hsv(r, g, b)
                    state.hue = h
                    state.saturation = s
                    state.value = v
                    state.opacity = color[3] if len(color) > 3 else 1.0
                    state.notify()
                return True
        return False
    popup_content.handle_key_event = _popup_key_handler

    def open_fn():
        # Capture old color on open
        stop = state.selected_stop
        if stop:
            split_swatch.old_color = stop.color
        popup.show()

    return popup, open_fn, state
