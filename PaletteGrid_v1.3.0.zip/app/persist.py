# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Persistence � save/load palette data to .blend file via scene custom properties."""
import json

import bpy
from bpy.app.handlers import persistent

from ..core.data import SPPalette
from .state import app_state
from .texture import generate_texture, update_texture, focus_texture, find_image_by_palette_id

_PROP_KEY = "palette_grid"
_VERSION = 1

# Guard flag � prevents handler activity during/after unregister
_shutting_down = False

# Track active timer functions so we can cancel them on unregister
_active_timers: set = set()


# -- Serialization --------------------------------------------

def _serialize() -> str:
    """Serialize current AppState to JSON string."""
    data = {
        "version": _VERSION,
        "active_index": app_state.active_index,
        "palettes": [p.to_dict() for p in app_state.palettes],
    }

    def _default(o):
        # Handle numpy float32/float64/int32 etc.
        try:
            return o.item()
        except (AttributeError, ValueError):
            raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")

    return json.dumps(data, separators=(",", ":"), default=_default)


def _deserialize(raw: str) -> tuple:
    """Deserialize JSON string ? (list[SPPalette], active_index).

    Returns ([], -1) on any error.
    """
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return [], -1

    if not isinstance(data, dict):
        return [], -1

    palettes = []
    for d in data.get("palettes", []):
        try:
            palettes.append(SPPalette.from_dict(d))
        except (KeyError, TypeError, ValueError):
            continue

    active = data.get("active_index", 0)
    return palettes, active


# -- Scene read/write -----------------------------------------

# Exact string last written to the scene property.  Used to tell whether undo
# has since replaced it, without paying for a re-serialize.
_last_written = None


def save_to_scene():
    """Persist palettes into the current scene's custom properties."""
    global _last_written
    scene = bpy.context.scene
    if scene is None:
        return
    raw = _serialize()
    scene[_PROP_KEY] = raw
    _last_written = raw


def _scene_matches_last_write() -> bool:
    """True when the scene property still holds exactly what we last wrote.

    Undo restores the scene -- including this custom property -- to an earlier
    snapshot, so this is how `_on_undo_redo` tells whether it has anything to
    repair.  Comparing against the cached string is a ~0.02 ms memcmp, versus
    ~12 ms to re-serialize and write (153 KB at 1250 strips).

    NOTE this answers "did something else overwrite the property", NOT "did the
    palette data change".  It is only valid where the caller has not itself
    mutated app_state -- i.e. in the undo/redo handler.  `_on_state_change`
    fires *because* data changed and must always write.
    """
    if _last_written is None:
        return False
    scene = bpy.context.scene
    if scene is None:
        return False
    return scene.get(_PROP_KEY) == _last_written


def load_from_scene():
    """Restore palettes from the current scene's custom properties.

    For each palette, check if the Blender image still exists.
    If not, regenerate it from the strip data.
    """
    global _last_written
    # A different file is now current, so the cached "last written" string
    # belongs to the previous one.  Drop it -- stale data here would make
    # _scene_matches_last_write() compare against the wrong file and wrongly
    # skip a needed rewrite.  Loading also normalises the data (clamped
    # active_index, dropped invalid palettes), so the raw text just read is not
    # necessarily what _serialize() would now produce.
    _last_written = None

    scene = bpy.context.scene
    if scene is None:
        return

    raw = scene.get(_PROP_KEY)
    if not raw:
        # New/empty file � clear any leftover state from previous file
        app_state.reset_listeners()
        app_state.add_listener(_on_state_change)
        app_state.palettes = []
        app_state.active_index = -1
        app_state.selected_strip_index = -1
        return

    palettes, active_index = _deserialize(raw)
    if not palettes:
        app_state.reset_listeners()
        app_state.add_listener(_on_state_change)
        app_state.palettes = []
        app_state.active_index = -1
        app_state.selected_strip_index = -1
        return

    # Restore or regenerate textures � strip data is the source of truth.
    # Without packing, pixel data is lost on save/reopen, so always refill.
    for p in palettes:
        if p.image_name and p.image_name in bpy.data.images:
            # Image datablock survived � refill pixels from strip data
            update_texture(p)
        else:
            # Try to find by palette ID (handles renames)
            img = find_image_by_palette_id(p.id)
            if img is not None:
                p.image_name = img.name
                update_texture(p)
            else:
                # Image truly gone � create new and fill
                generate_texture(p)

    # Clear stale listeners before replacing � the deferred _on_file_loaded
    # callback will rebuild the panel with fresh listeners.
    app_state.reset_listeners()
    app_state.add_listener(_on_state_change)
    app_state.palettes = palettes
    app_state.active_index = max(0, min(active_index, len(palettes) - 1)) if palettes else -1
    app_state.selected_strip_index = -1

    # Defer focus to after Blender finishes loading (areas may not exist yet)
    def _deferred_focus():
        _active_timers.discard(_deferred_focus)
        if _shutting_down:
            return None
        active = app_state.active_palette
        if active:
            focus_texture(active)
        return None  # don't repeat
    _active_timers.add(_deferred_focus)
    bpy.app.timers.register(_deferred_focus, first_interval=0.2)


# -- Auto-save listener --------------------------------------

def _on_state_change(state):
    """Auto-persist after every state mutation."""
    if _shutting_down:
        return
    save_to_scene()


# -- Blender handlers ----------------------------------------

# Callback set by __init__.py to rebuild the panel after file load
_on_file_loaded = None


@persistent
def _on_save_pre(*_args):
    """Called before .blend file is saved � ensure data is up-to-date."""
    if _shutting_down:
        return
    save_to_scene()


@persistent
def _on_load_post(*_args):
    """Called after .blend file is loaded � restore palette state and rebuild panel."""
    if _shutting_down:
        return
    load_from_scene()
    # Blender cancels all modals on file load � restart BGUI interaction
    from ..bgui.panel import restart_interaction
    restart_interaction()
    # Defer full panel rebuild so Blender finishes setting up the screen
    if _on_file_loaded:
        def _deferred_rebuild():
            _active_timers.discard(_deferred_rebuild)
            if _shutting_down:
                return None
            _on_file_loaded()
            return None
        _active_timers.add(_deferred_rebuild)
        bpy.app.timers.register(_deferred_rebuild, first_interval=0.15)


@persistent
def _on_depsgraph_update(scene, depsgraph=None):
    """Check if any palette's image was deleted and regenerate if needed."""
    if _shutting_down or not app_state.palettes:
        return
    for p in app_state.palettes:
        if p.image_name and p.image_name not in bpy.data.images:
            # Image was deleted or renamed � try finding by pg_id
            img = find_image_by_palette_id(p.id)
            if img is not None:
                p.image_name = img.name
            else:
                # Truly gone � regenerate from strip data
                generate_texture(p)
            save_to_scene()
            # Focus the regenerated image
            active = app_state.active_palette
            if active and active.id == p.id:
                focus_texture(p)


# -- Texture protection --------------------------------------

_VALIDATE_INTERVAL = 3.0  # seconds


def _validate_textures():
    """Periodic check � regenerate any palette texture whose pixels went blank."""
    if _shutting_down or not app_state.palettes:
        return _VALIDATE_INTERVAL

    for p in app_state.palettes:
        if not p.image_name:
            continue
        img = bpy.data.images.get(p.image_name)
        if img is None:
            try:
                generate_texture(p)
            except Exception:
                pass
            continue
        # `has_data` is False exactly when the pixel buffer is gone, and reading
        # it is O(1) at any texture size.
        #
        # It MUST be read before any other property on the image.  Touching
        # img.size -- or img.pixels -- re-materialises a freed buffer as zeros
        # and flips has_data back to True, hiding the very condition being
        # tested for.
        #
        # Do NOT sample img.pixels here.  Slicing it is O(total pixels):
        # Blender materialises the whole RNA float array to serve even a
        # 4-element slice (62 ms on a 4096x4096 image, every 3 seconds).  It was
        # also the wrong pixel -- index 0 is the image's BOTTOM-left, which is
        # legitimately black whenever the palette has fewer strips than grid
        # cells, yet it was compared against strips[0], the TOP-left cell.  So
        # every partially filled palette rebuilt its whole texture on every
        # tick, forever.  Worse, that read resurrected freed buffers as black
        # and then "detected" the blackness it had just created.
        try:
            if not img.has_data:
                img.use_fake_user = True
                update_texture(p)
                continue
            img.use_fake_user = True
            if img.size[0] == 0 or img.size[1] == 0:
                generate_texture(p)
        except Exception:
            pass

    return _VALIDATE_INTERVAL


@persistent
def _on_undo_redo(*_args):
    """Re-persist palette state to scene after undo/redo.

    Blender's undo restores the entire scene � including
    scene["palette_grid"] � to an earlier snapshot.  Palette edits
    should NOT be part of Blender's undo timeline (users expect
    Ctrl+Z to undo viewport/mesh actions, not palette colour changes).

    We re-write the current app_state back to scene (overwriting
    whatever stale data undo restored) and regenerate textures
    (image pixel data is also part of undo and may be stale).
    """
    if _shutting_down:
        return
    # Only rewrite when undo actually replaced the stored palette data.  An
    # undo unrelated to palettes leaves the property byte-identical, and
    # re-serializing 153 KB on every undo step cost ~12 ms a time.
    if not _scene_matches_last_write():
        save_to_scene()

    # Image pixels are part of Blender's undo system and undo really can
    # discard them, so the texture still has to be repaired here -- but only
    # when it was actually damaged.
    #
    # `has_data` is the reliable signal and costs O(1).  Rebuilding
    # unconditionally cost 256 ms per undo event on a 4096x4096 palette, on
    # every undo anywhere in Blender, palette-related or not.
    #
    # Note this cannot be decided by comparing serialized palette data: an
    # unrelated undo can blank the image while scene["palette_grid"] stays
    # byte-identical, so a data comparison would skip exactly the undos that
    # need repairing.
    for p in app_state.palettes:
        if not p.image_name:
            continue
        img = bpy.data.images.get(p.image_name)
        if img is None:
            # Image datablock may have been removed by undo
            existing = find_image_by_palette_id(p.id)
            if existing is None:
                generate_texture(p)
                continue
            p.image_name = existing.name
            img = existing
        if not img.has_data:
            update_texture(p)



# -- Registration --------------------------------------------

_registered = False


def _ensure_handler(collection, fn):
    """Register *fn* exactly once, dropping any stale copies first.

    `bpy.app.handlers` lists hold direct function references and `append()`
    does not deduplicate.  `register()` runs again after every .blend load
    (see `__init__._on_file_loaded`), so appending unconditionally added one
    more copy of every handler per file load -- multiplying the cost of every
    undo, depsgraph update and save, and getting worse the longer a session
    ran.
    """
    # Match on identity first, then on module+name.  A hot-reload re-imports
    # this module, so previous registrations are different function objects
    # that `in` would never find, yet they keep firing.
    name = getattr(fn, "__name__", None)
    module = getattr(fn, "__module__", None)
    for existing in list(collection):
        if existing is fn or (
            name is not None
            and getattr(existing, "__name__", None) == name
            and getattr(existing, "__module__", None) == module
        ):
            try:
                collection.remove(existing)
            except (ValueError, RuntimeError):
                pass
    collection.append(fn)


def register():
    """Idempotent -- safe to call repeatedly (and it is, on every file load)."""
    global _registered, _shutting_down
    _registered = True
    _shutting_down = False

    _ensure_handler(bpy.app.handlers.save_pre, _on_save_pre)
    _ensure_handler(bpy.app.handlers.load_post, _on_load_post)
    _ensure_handler(bpy.app.handlers.depsgraph_update_post, _on_depsgraph_update)
    _ensure_handler(bpy.app.handlers.undo_post, _on_undo_redo)
    _ensure_handler(bpy.app.handlers.redo_post, _on_undo_redo)

    app_state.remove_listener(_on_state_change)
    app_state.add_listener(_on_state_change)

    # Start periodic texture validation (timers duplicate the same way)
    _active_timers.add(_validate_textures)
    if not bpy.app.timers.is_registered(_validate_textures):
        bpy.app.timers.register(_validate_textures,
                                first_interval=_VALIDATE_INTERVAL)


def unregister():
    global _registered, _shutting_down, _last_written
    if not _registered:
        return
    _shutting_down = True
    _registered = False
    _last_written = None

    # Cancel any pending timers before removing handlers
    for fn in list(_active_timers):
        try:
            if bpy.app.timers.is_registered(fn):
                bpy.app.timers.unregister(fn)
        except Exception:
            pass
    _active_timers.clear()

    if _on_save_pre in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_on_save_pre)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_undo_redo in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(_on_undo_redo)
    if _on_undo_redo in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.remove(_on_undo_redo)
