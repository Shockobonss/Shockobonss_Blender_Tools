# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Central application state � palette list, active selection, observers."""

from .data import SPPalette


class AppState:
    """Singleton-style app state. Holds all palettes and notifies listeners on change."""

    def __init__(self):
        self.palettes: list = []       # list[SPPalette]
        self.active_index: int = -1    # index into palettes, -1 = none
        self.selected_strip_index: int = -1  # currently-selected strip, -1 = none
        self._strip_datalist = None  # ref set by build_active_root for scroll-to
        self._listeners = []

    # -- Properties -----------------------------------------

    @property
    def has_palettes(self) -> bool:
        return len(self.palettes) > 0

    @property
    def active_palette(self):
        if 0 <= self.active_index < len(self.palettes):
            return self.palettes[self.active_index]
        return None

    # -- Mutations (all call notify) ------------------------

    def add_palette(self, palette: SPPalette):
        self.palettes.append(palette)
        self.active_index = len(self.palettes) - 1
        self.notify()

    def remove_palette(self, index: int):
        if 0 <= index < len(self.palettes):
            self.palettes.pop(index)
            if self.active_index >= len(self.palettes):
                self.active_index = len(self.palettes) - 1
            self.notify()

    def set_active(self, index: int):
        if 0 <= index < len(self.palettes):
            changed = self.active_index != index
            self.active_index = index
            if changed:
                self.selected_strip_index = -1
            self.notify()

    def replace_all(self, palettes: list, active_index: int = 0):
        """Bulk-replace all palettes (used by persistence load)."""
        self.palettes = palettes
        if palettes:
            self.active_index = max(0, min(active_index, len(palettes) - 1))
        else:
            self.active_index = -1
        self.selected_strip_index = -1
        self.notify()

    # -- Observer pattern -----------------------------------

    def add_listener(self, fn):
        self._listeners.append(fn)

    def remove_listener(self, fn):
        """Remove every registration of fn. Safe if it was never added."""
        while fn in self._listeners:
            self._listeners.remove(fn)

    def notify(self):
        for fn in self._listeners:
            fn(self)

    def reset_listeners(self):
        """Clear all listeners. Called on hot-reload to avoid stale refs."""
        self._listeners.clear()


# Module-level singleton
app_state = AppState()
