# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Empty-state palette panel � shown when no palettes exist yet."""
import os

from .. import bgui
from ..bgui.core import ui_scale
from ..bgui.theme import StyleSheet as SS, DesignTokens as DT
from .popup import LIME, PANEL_BG, CARD_BG, DARK_TEXT

_ASSETS = os.path.join(os.path.dirname(__file__), 'assets')


class _LazyImage(bgui.ImageWidget):
    def __init__(self, image_path: str, **kwargs):
        super().__init__(image=None, **kwargs)
        self._image_path = image_path
        self._loaded = False

    def _draw_content(self, renderer, style):
        if not self._loaded:
            self._loaded = True
            self.image = bgui.load_ui_image(self._image_path)
        super()._draw_content(renderer, style)


class _CardWithIcon(bgui.Column):
    """Column that draws a centered icon overlapping its top edge."""
    _ICON_SIZE = 52

    def __init__(self, icon_path: str, **kwargs):
        super().__init__(**kwargs)
        self._icon_path = icon_path
        self._icon_img = None
        self._icon_loaded = False

    def draw(self, renderer):
        super().draw(renderer)
        if not self._icon_loaded:
            self._icon_loaded = True
            self._icon_img = bgui.load_ui_image(self._icon_path)
        if self._icon_img:
            sc = ui_scale()
            s = self._ICON_SIZE * sc
            cx = self.rect.x + self.rect.width / 2 - s / 2
            cy = self.rect.y - s / 2
            renderer.draw_image(self._icon_img, bgui.Rect(cx, cy, s, s))


class _FlexButton(bgui.Button):
    def _measure_content_width(self) -> float:
        return 0


def build_empty_root(on_create_click=None, on_import_click=None):
    """Build the empty-state root widget (no panel). Returns a Column."""

    root = bgui.Column(
        style=SS.panel(
            background_color=PANEL_BG,
            padding=bgui.EdgeInsets(14, 12, 14, 12),
            gap=12, border_width=0, border_color=None,
        ),
        children=[
            bgui.Label("Palette Grid", style=bgui.Style(
                font_size=DT.font.xxl, font_color=(1.0, 1.0, 1.0, 1.0),
                font_weight='bold', width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER,
                padding=bgui.EdgeInsets(4, 0, 20, 0),
            )),
            _CardWithIcon(
                icon_path=os.path.join(_ASSETS, 'paintbrush_icon.png'),
                style=bgui.Style(
                    background_color=CARD_BG, border_radius=DT.radius.xl,
                    padding=bgui.EdgeInsets(40, 16, 16, 16), gap=6,
                    width_policy=bgui.SizePolicy.FILL, clip_children=True,
                ),
                children=[
                    bgui.Label("No palettes yet", style=bgui.Style(
                        font_size=DT.font.xl, font_weight='regular',
                        font_color=(0.55, 0.55, 0.60, 1.0),
                        alignment=bgui.Alignment.CENTER,
                        width_policy=bgui.SizePolicy.FILL,
                    )),
                    bgui.Label("Create your first palette", style=bgui.Style(
                        font_size=DT.font.xxl, font_weight='bold',
                        font_color=(1.0, 1.0, 1.0, 1.0),
                        alignment=bgui.Alignment.CENTER,
                        width_policy=bgui.SizePolicy.FILL,
                        padding=bgui.EdgeInsets(0, 0, 10, 0),
                    )),
                    _LazyImage(
                        image_path=os.path.join(_ASSETS, 'color_strips.png'),
                        style=bgui.Style(
                            width_policy=bgui.SizePolicy.FILL, height=120,
                            border_radius=DT.radius.lg,
                            padding=bgui.EdgeInsets(0, 0, 10, 0),
                        ),
                    ),
                    bgui.Row(
                        style=bgui.Style(
                            background_color=LIME, border_radius=DT.radius.xl,
                            width_policy=bgui.SizePolicy.FILL,
                            alignment=bgui.Alignment.CENTER,
                            padding=bgui.EdgeInsets(0, 0, 0, 0),
                            gap=0, clip_children=True,
                        ),
                        children=[
                            _FlexButton("Create New",
                                icon_path=os.path.join(_ASSETS, 'plus_icon.png'),
                                icon_size=18,
                                style=bgui.Style(
                                    background_color=(0, 0, 0, 0), border_radius=0,
                                    font_size=DT.font.lg, font_color=DARK_TEXT,
                                    font_weight='semibold',
                                    padding=bgui.EdgeInsets(12, 4, 12, 4),
                                    flex=1, width_policy=bgui.SizePolicy.FILL,
                                    alignment=bgui.Alignment.CENTER,
                                    hover_style={'background_color': (0, 0, 0, 0.08)},
                                    active_style={'background_color': (0, 0, 0, 0.15)},
                                ),
                                on_click=on_create_click,
                            ),
                            bgui.Box(style=bgui.Style(
                                width=1, height=24,
                                background_color=(0.098, 0.098, 0.11, 0.2),
                            )),
                            _FlexButton("Import",
                                icon_path=os.path.join(_ASSETS, 'import_icon.png'),
                                icon_size=18,
                                style=bgui.Style(
                                    background_color=(0, 0, 0, 0), border_radius=0,
                                    font_size=DT.font.lg, font_color=DARK_TEXT,
                                    font_weight='semibold',
                                    padding=bgui.EdgeInsets(12, 4, 12, 4),
                                    flex=1, width_policy=bgui.SizePolicy.FILL,
                                    alignment=bgui.Alignment.CENTER,
                                    hover_style={'background_color': (0, 0, 0, 0.08)},
                                    active_style={'background_color': (0, 0, 0, 0.15)},
                                ),
                                on_click=on_import_click,
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )

    return root
