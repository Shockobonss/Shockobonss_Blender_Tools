# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Blender operators for palette import/export via file browser."""

import bpy
from bpy.props import StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .state import app_state
from .texture import generate_texture, focus_texture
from ..core.io import export_palette, import_palette


class PALETTE_OT_export(bpy.types.Operator, ExportHelper):
    """Export the active palette to a file"""
    bl_idname = "palette_grid.export_palette"
    bl_label = "Export Palette"

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    _export_index: int = -1

    def invoke(self, context, event):
        palette = None
        idx = self.__class__._export_index
        if 0 <= idx < len(app_state.palettes):
            palette = app_state.palettes[idx]
        else:
            palette = app_state.active_palette
        if palette is None:
            self.report({'WARNING'}, "No palette to export")
            return {'CANCELLED'}
        self.filepath = palette.name + self.filename_ext
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        idx = self.__class__._export_index
        if 0 <= idx < len(app_state.palettes):
            palette = app_state.palettes[idx]
        else:
            palette = app_state.active_palette
        if palette is None:
            self.report({'WARNING'}, "No palette to export")
            return {'CANCELLED'}
        try:
            data = export_palette(palette)
            with open(self.filepath, 'w', encoding='utf-8') as f:
                f.write(data)
            self.report({'INFO'}, f"Exported '{palette.name}' to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class PALETTE_OT_import(bpy.types.Operator, ImportHelper):
    """Import a palette from a file"""
    bl_idname = "palette_grid.import_palette"
    bl_label = "Import Palette"

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                raw = f.read()
            palette = import_palette(raw)
            generate_texture(palette)
            app_state.add_palette(palette)
            focus_texture(palette)
            self.report({'INFO'}, f"Imported '{palette.name}'")
        except ValueError as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


_classes = [PALETTE_OT_export, PALETTE_OT_import]


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
