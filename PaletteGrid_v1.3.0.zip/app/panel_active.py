# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Active palette panel � shown when palettes exist."""
import os

from .. import bgui
from ..bgui.core import ui_scale
from ..bgui.theme import StyleSheet as SS, DesignTokens as DT
from ..core import palette as core_palette
from ..core.effects import apply_pipeline_rgba
from .popup import PANEL_BG, CARD_BG
from .data import SPPalette, SPStrip, StripType
from .texture import remove_texture, get_color_spaces, apply_color_space, update_strip
from .gradient_popup import GradientStop

_ASSETS = os.path.join(os.path.dirname(__file__), "assets")

LIME      = (0.784, 1.0, 0.0, 1.0)
DARK_TEXT = (0.098, 0.098, 0.11, 1.0)


class _CardWithIcon(bgui.Column):
    """Column that draws a centered icon overlapping its top edge."""
    _ICON_SIZE = 52

    def __init__(self, icon_path: str, **kwargs):
        super().__init__(**kwargs)
        self._icon_path = icon_path
        self._icon_img = None
        self._icon_loaded = False

    def draw(self, renderer):
        super().draw(renderer)
        if not self._icon_loaded:
            self._icon_loaded = True
            self._icon_img = bgui.load_ui_image(self._icon_path)
        if self._icon_img:
            sc = ui_scale()
            s = self._ICON_SIZE * sc
            cx = self.rect.x + self.rect.width / 2 - s / 2
            cy = self.rect.y - s / 2
            renderer.draw_image(self._icon_img, bgui.Rect(cx, cy, s, s))


class _FlexButton(bgui.Button):
    def _measure_content_width(self) -> float:
        return 0


class PaletteDataList(bgui.DataList):
    """DataList for palettes � shows a delete icon on the selected item.

    Double-click an item to inline-rename it.
    """
    _ICON_SIZE = 14
    _ICON_PAD_R = 8  # right padding inside item rect

    def __init__(self, on_delete=None, on_rename=None, on_export=None, **kwargs):
        super().__init__(**kwargs)
        self.on_delete = on_delete
        self.on_rename = on_rename
        self.on_export = on_export
        self._bin_img = None
        self._bin_loaded = False
        self._export_img = None
        self._export_loaded = False
        # Inline rename state
        self._editing_index = -1
        self._edit_input = None
        self._edit_cancelled = False
        # Wire double-click to start editing
        self.on_double_click = lambda w, idx: self._start_editing(idx)

    def _start_editing(self, index):
        """Begin inline rename for the item at *index*."""
        if index < 0 or index >= len(self.items):
            return
        if self._editing_index >= 0:
            self._commit_edit()
        self._editing_index = index
        self._edit_cancelled = False
        name = self.items[index].get('name', '')
        inp = bgui.TextInput(
            text=name,
            on_submit=lambda w: self._commit_edit(),
            style=bgui.Style(
                background_color=(0.16, 0.16, 0.18, 1.0),
                border_color=(0.784, 1.0, 0.0, 0.8),
                border_width=1.5,
                border_radius=4,
                font_size=self.style.font_size,
                font_color=(1.0, 1.0, 1.0, 1.0),
                font_weight=self.style.font_weight or 'medium',
                height=self.item_height - 4,
                padding=bgui.EdgeInsets(2, 8, 2, 8),
            ),
        )
        # Intercept ESC to distinguish cancel from click-away blur
        _orig_handle_key = inp.handle_key_event
        def _key_wrapper(key, shift=False, ctrl=False, ascii_char=""):
            if key == 'ESC':
                self._edit_cancelled = True
            return _orig_handle_key(key, shift=shift, ctrl=ctrl, ascii_char=ascii_char)
        inp.handle_key_event = _key_wrapper

        self._edit_input = inp
        self.children.append(inp)
        inp.focus()
        # Select all text
        inp.selection_start = 0
        inp.cursor_pos = len(name)

    def _commit_edit(self):
        """Commit the rename and finish editing."""
        if self._editing_index < 0 or not self._edit_input:
            return
        new_name = self._edit_input.text.strip()
        idx = self._editing_index
        self._finish_editing()
        if new_name and self.on_rename:
            self.on_rename(self, idx, new_name)

    def _finish_editing(self):
        """Clean up editing state."""
        self._editing_index = -1
        self._edit_cancelled = False
        inp = self._edit_input
        self._edit_input = None
        if inp:
            if inp in self.children:
                self.children.remove(inp)
            if bgui.TextInput._focused_instance is inp:
                bgui.TextInput._focused_instance = None
            inp.focused = False

    def _ensure_bin_icon(self):
        if self._bin_loaded:
            return
        self._bin_loaded = True
        assets = os.path.join(os.path.dirname(__file__), "assets")
        bin_path = os.path.join(assets, "Bin.svg")
        self._bin_img = bgui.load_ui_image(
            bin_path, svg_size=32, svg_color=(0.85, 0.85, 0.88, 1.0))

    def _ensure_export_icon(self):
        if self._export_loaded:
            return
        self._export_loaded = True
        assets = os.path.join(os.path.dirname(__file__), "assets")
        export_path = os.path.join(assets, "export.svg")
        self._export_img = bgui.load_ui_image(
            export_path, svg_size=32, svg_color=(0.85, 0.85, 0.88, 1.0))

    def _draw_content(self, renderer, style):
        # Detect blur ? commit or cancel editing
        if self._editing_index >= 0 and self._edit_input and not self._edit_input.focused:
            if self._edit_cancelled:
                self._finish_editing()
            else:
                self._commit_edit()

        # Draw base DataList content first
        super()._draw_content(renderer, style)

        # Overlay delete and export icons on the selected item (skip if editing)
        self._ensure_bin_icon()
        self._ensure_export_icon()
        if (0 <= self.selected < len(self.items)
                and self._editing_index != self.selected):
            cr = self.content_rect
            sc = ui_scale()
            pad_v = self._pad_v * sc
            pad_r = 8 * sc
            has_scrollbar = self._max_scroll > 0
            sb_gap = 10 * sc if has_scrollbar else 0
            sb_w = 3 * sc if has_scrollbar else 0
            s = self._ICON_SIZE * sc
            icon_gap = 6 * sc
            ih = self.item_height * sc
            iy = cr.y + pad_v + self.selected * ih - self.scroll_offset
            clip_top = cr.y + pad_v
            clip_bottom = cr.y + cr.height - pad_v
            if not (iy + ih < clip_top or iy > clip_bottom):
                icon_y = iy + (ih - s) / 2
                # Delete icon (rightmost)
                bin_x = cr.right - pad_r - sb_w - sb_gap - self._ICON_PAD_R * sc - s
                if self._bin_img is not None:
                    renderer.draw_image(self._bin_img, bgui.Rect(bin_x, icon_y, s, s))
                # Export icon (left of delete)
                export_x = bin_x - icon_gap - s
                if self._export_img is not None:
                    renderer.draw_image(self._export_img, bgui.Rect(export_x, icon_y, s, s))

        # Position TextInput overlay for the editing item (drawn by _draw_children)
        if self._editing_index >= 0 and self._edit_input:
            cr = self.content_rect
            sc = ui_scale()
            idx = self._editing_index
            ih = self.item_height * sc
            iy = cr.y + self._pad_v * sc + idx * ih - self.scroll_offset
            pad_l = 8 * sc
            pad_r = 8 * sc
            has_scrollbar = self._max_scroll > 0
            sb_gap = 10 * sc if has_scrollbar else 0
            sb_w = 3 * sc if has_scrollbar else 0
            edit_rect = bgui.Rect(
                cr.x + pad_l + 2 * sc, iy + 2 * sc,
                cr.width - pad_l - pad_r - sb_gap - sb_w - 2 * sc, ih - 4 * sc,
            )
            self._edit_input.rect = edit_rect
            pad = self._edit_input.style.padding or bgui.EdgeInsets(0, 0, 0, 0)
            self._edit_input.content_rect = edit_rect.inset(
                pad.top, pad.right, pad.bottom, pad.left)

    def handle_mouse_press(self, x, y):
        if not self.visible or not self.rect.contains(x, y):
            return False
        # If editing, let TextInput handle clicks inside it
        if self._editing_index >= 0 and self._edit_input:
            if self._edit_input.rect and self._edit_input.rect.contains(x, y):
                return self._edit_input.handle_mouse_press(x, y)
        cr = self.content_rect
        sc = ui_scale()
        ih = self.item_height * sc
        idx = int((y - cr.y - self._pad_v * sc + self.scroll_offset) / ih)
        # Check delete / export icons on selected item
        if 0 <= idx < len(self.items) and idx == self.selected:
            pad_r = 8 * sc
            has_scrollbar = self._max_scroll > 0
            sb_gap = 10 * sc if has_scrollbar else 0
            sb_w = 3 * sc if has_scrollbar else 0
            s = self._ICON_SIZE * sc
            icon_gap = 6 * sc
            iy = cr.y + self._pad_v * sc + idx * ih - self.scroll_offset
            icon_y = iy + (ih - s) / 2
            # Delete icon (rightmost)
            bin_x = cr.right - pad_r - sb_w - sb_gap - self._ICON_PAD_R * sc - s
            if bin_x <= x <= bin_x + s and icon_y <= y <= icon_y + s:
                if self.on_delete:
                    self.on_delete(self, idx)
                return True
            # Export icon (left of delete)
            export_x = bin_x - icon_gap - s
            if export_x <= x <= export_x + s and icon_y <= y <= icon_y + s:
                if self.on_export:
                    self.on_export(self, idx)
                return True
        return super().handle_mouse_press(x, y)


class _LazyIcon(bgui.ImageWidget):
    """ImageWidget that loads an SVG on first draw."""
    def __init__(self, path: str, **kwargs):
        super().__init__(image=None, **kwargs)
        self._path = path

    def _draw_content(self, renderer, style):
        if self.image is None:
            self.image = bgui.load_ui_image(self._path, svg_size=32)
        super()._draw_content(renderer, style)


class StripDataList(bgui.DataList):
    """DataList that renders SPStrip items as gradient/flat color bars.

    On the selected item, Edit and Delete icons appear on the right side,
    tinted to contrast with the gradient background.
    """
    _ICON_SIZE = 16
    _ICON_PAD_R = 8    # right padding from bar edge
    _LIGHT = (0.91, 0.90, 0.90, 1.0)  # #E8E5E5
    _DARK  = (0.18, 0.18, 0.20, 1.0)  # #2E2E33

    def __init__(self, on_edit=None, on_settings=None, on_rename=None, on_color_paste=None, **kwargs):
        super().__init__(**kwargs)
        self.on_edit = on_edit
        self.on_settings = on_settings
        self.on_rename = on_rename
        self.on_color_paste = on_color_paste
        self._icons_loaded = False
        self._edit_light = self._edit_dark = None
        self._settings_light = self._settings_dark = None
        # Inline rename state
        self._editing_index: int = -1
        self._edit_text: str = ""
        self._edit_cursor: int = 0
        self._edit_sel_start = None
        # Wire double-click to start inline rename
        self.on_double_click = lambda w, idx: self._start_edit(idx)

    def _ensure_icons(self):
        if self._icons_loaded:
            return
        self._icons_loaded = True
        assets = os.path.join(os.path.dirname(__file__), "assets")
        edit_path = os.path.join(assets, "Edit.svg")
        self._edit_light = bgui.load_ui_image(edit_path, svg_size=32, svg_color=self._LIGHT)
        self._edit_dark = bgui.load_ui_image(edit_path, svg_size=32, svg_color=self._DARK)
        settings_path = os.path.join(assets, "Settings.svg")
        self._settings_light = bgui.load_ui_image(settings_path, svg_size=32, svg_color=self._LIGHT)
        self._settings_dark = bgui.load_ui_image(settings_path, svg_size=32, svg_color=self._DARK)

    @staticmethod
    def _luminance(color):
        """Perceived luminance (0-1) of an RGBA color."""
        return 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]

    @staticmethod
    def _preview_color(strip, color):
        """Return a strip color with non-destructive effects applied for preview use."""
        effects = getattr(strip, 'effects', None)
        if effects:
            return apply_pipeline_rgba(color, effects)
        return color

    @classmethod
    def _pick_contrast(cls, strip):
        """Pick light or dark icons based on the overall strip brightness.

        Uses the average luminance of both gradient endpoints so the
        choice is stable regardless of bar width or icon position.
        """
        c1 = cls._preview_color(strip, strip.stops[0][1])
        c2 = cls._preview_color(strip, strip.stops[-1][1])
        avg_lum = (cls._luminance(c1) + cls._luminance(c2)) / 2
        return "dark" if avg_lum > 0.45 else "light"

    @classmethod
    def _contrast_color(cls, strip):
        """Return a text color that contrasts with the strip gradient."""
        return cls._DARK if cls._pick_contrast(strip) == "dark" else cls._LIGHT

    def _start_edit(self, index):
        """Enter inline rename mode for the strip at *index*."""
        if index < 0 or index >= len(self.items):
            return
        strip = self.items[index].get('data')
        if not isinstance(strip, SPStrip):
            return
        self._editing_index = index
        self._edit_text = strip.name if strip.name else ""
        self._edit_cursor = len(self._edit_text)
        from ..bgui.core import register_editing
        register_editing(self)

    def blur(self):
        """Commit and exit edit mode (called by global blur)."""
        if self._editing_index >= 0:
            self._confirm_edit()

    def _confirm_edit(self):
        """Commit the edited name and exit edit mode."""
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        idx = self._editing_index
        if idx < 0:
            return
        name = self._edit_text.strip()
        self._editing_index = -1
        self._edit_text = ""
        self._edit_cursor = 0
        self._edit_sel_start = None
        if self.on_rename:
            self.on_rename(self, idx, name)

    def _cancel_edit(self):
        """Discard changes and exit edit mode."""
        from ..bgui.core import unregister_editing
        unregister_editing(self)
        self._editing_index = -1
        self._edit_text = ""
        self._edit_cursor = 0
        self._edit_sel_start = None

    def _del_edit_sel(self):
        """Delete selected range in inline edit. Returns True if selection existed."""
        if self._edit_sel_start is None:
            return False
        s = min(self._edit_sel_start, self._edit_cursor)
        e = max(self._edit_sel_start, self._edit_cursor)
        self._edit_text = self._edit_text[:s] + self._edit_text[e:]
        self._edit_cursor = s
        self._edit_sel_start = None
        return True

    def handle_key_event(self, key, shift=False, ctrl=False, ascii_char=""):
        """Handle keyboard input during inline rename, copy/paste strip, or color paste."""
        # Copy/paste/undo works when NOT editing
        if self._editing_index < 0:
            if ctrl and key == 'C':
                return self._copy_strip()
            if ctrl and key == 'V':
                # Try strip paste first, fall back to color paste
                if self._paste_strip():
                    return True
                return self._paste_color_to_strip()
            return False
        if key == 'RET':
            self._confirm_edit()
            return True
        if key == 'ESC':
            self._cancel_edit()
            return True
        if ctrl and key == 'A':
            self._edit_sel_start = 0
            self._edit_cursor = len(self._edit_text)
            return True
        if key == 'BACK_SPACE':
            if not self._del_edit_sel():
                if self._edit_cursor > 0:
                    self._edit_text = (self._edit_text[:self._edit_cursor - 1]
                                       + self._edit_text[self._edit_cursor:])
                    self._edit_cursor -= 1
            return True
        if key == 'DEL':
            if not self._del_edit_sel():
                if self._edit_cursor < len(self._edit_text):
                    self._edit_text = (self._edit_text[:self._edit_cursor]
                                       + self._edit_text[self._edit_cursor + 1:])
            return True
        if key == 'LEFT_ARROW':
            self._edit_sel_start = None
            if self._edit_cursor > 0:
                self._edit_cursor -= 1
            return True
        if key == 'RIGHT_ARROW':
            self._edit_sel_start = None
            if self._edit_cursor < len(self._edit_text):
                self._edit_cursor += 1
            return True
        if key == 'HOME':
            self._edit_sel_start = None
            self._edit_cursor = 0
            return True
        if key == 'END':
            self._edit_sel_start = None
            self._edit_cursor = len(self._edit_text)
            return True
        if ctrl and key == 'V':
            self._del_edit_sel()
            import bpy
            clip = bpy.context.window_manager.clipboard or ""
            clip = clip.split('\n')[0].split('\r')[0]
            self._edit_text = (self._edit_text[:self._edit_cursor]
                               + clip
                               + self._edit_text[self._edit_cursor:])
            self._edit_cursor += len(clip)
            return True
        # Printable character
        if ascii_char and not ctrl:
            self._del_edit_sel()
            self._edit_text = (self._edit_text[:self._edit_cursor]
                               + ascii_char
                               + self._edit_text[self._edit_cursor:])
            self._edit_cursor += len(ascii_char)
            return True
        return False

    def _paste_color_to_strip(self):
        """Paste a clipboard color into the selected flat strip."""
        import bpy
        from .gradient_popup import parse_clipboard_color
        clip = bpy.context.window_manager.clipboard or ""
        color = parse_clipboard_color(clip)
        if not color:
            return False
        idx = self.selected
        if idx < 0 or idx >= len(self.items):
            return False
        strip = self.items[idx].get('data')
        if not isinstance(strip, SPStrip) or strip.strip_type != StripType.FLAT:
            return False
        strip.stops = [(0.0, color), (1.0, color)]
        if self.on_color_paste:
            self.on_color_paste(self, idx)
        return True

    def _get_hover_enabled(self):
        """Check if hover-based copy/paste is enabled in preferences."""
        import bpy
        addon_id = __package__.rsplit('.', 1)[0]
        prefs = bpy.context.preferences.addons.get(addon_id)
        return prefs and prefs.preferences.hover_copy_paste

    def _copy_strip(self):
        """Copy the hovered (or selected) strip to clipboard."""
        import bpy
        from .state import app_state
        if self._get_hover_enabled() and self._hover_index >= 0:
            idx = self._hover_index
        else:
            idx = self.selected
        if idx < 0 or idx >= len(self.items):
            return False
        strip = self.items[idx].get('data')
        if not isinstance(strip, SPStrip):
            return False
        palette = app_state.active_palette
        from .strip_ops import _serialize_strip
        bpy.context.window_manager.clipboard = _serialize_strip(
            strip,
            palette.direction if palette else None,
        )
        return True

    def _paste_strip(self):
        """Paste a strip from clipboard onto the hovered (or selected) strip."""
        import bpy
        clip = bpy.context.window_manager.clipboard or ""
        from .strip_ops import _deserialize_strip
        strip = _deserialize_strip(clip)
        if strip is None:
            return False
        if self._get_hover_enabled() and self._hover_index >= 0:
            idx = self._hover_index
            # Select the hovered strip so the paste operator targets it
            from .state import app_state
            self.selected = idx
            app_state.selected_strip_index = idx
            if self.on_select:
                self.on_select(self, idx)
        else:
            idx = self.selected
            # Ensure app_state is in sync with DataList selection
            from .state import app_state
            app_state.selected_strip_index = idx
        if idx < 0 or idx >= len(self.items):
            return False
        bpy.ops.palette_grid.paste_strip()
        return True

    def _on_right_click(self, x, y):
        """Right-click on a strip � select it and open native context menu."""
        import bpy
        from . import strip_ops
        cr = self.content_rect
        if not cr:
            return
        sc = ui_scale()
        ih = self.item_height * sc
        idx = int((y - cr.y - self._pad_v * sc + self.scroll_offset) / ih)
        if idx < 0 or idx >= len(self.items):
            return
        # Select the right-clicked strip
        self.selected = idx
        if self.on_select:
            self.on_select(self, idx)
        strip_ops._target_index = idx
        bpy.ops.wm.call_menu(name="PALETTE_MT_strip_context")

    def _draw_content(self, renderer, style):
        self._ensure_icons()
        cr = self.content_rect
        sc = ui_scale()
        pad_v = self._pad_v * sc
        clip_rect = bgui.Rect(cr.x, cr.y + pad_v, cr.width, cr.height - pad_v * 2)
        renderer.push_clip(clip_rect)

        pad_l = 8 * sc
        pad_r = 8 * sc
        max_scroll = self._max_scroll
        has_scrollbar = max_scroll > 0
        sb_gap = 10 * sc if has_scrollbar else 0
        sb_w = 3 * sc if has_scrollbar else 0
        ih = self.item_height * sc

        for i, item in enumerate(self.items):
            iy = cr.y + pad_v + i * ih - self.scroll_offset
            if iy + ih < clip_rect.y or iy > clip_rect.bottom:
                continue

            item_rect = bgui.Rect(
                cr.x + pad_l, iy + 1 * sc,
                cr.width - pad_l - sb_gap - sb_w - pad_r, ih - 2 * sc,
            )
            is_selected = (i == self.selected)

            # Selection / hover highlight
            if is_selected:
                sel_color = (*self.active_color[:3], 0.2)
                renderer.draw_rounded_rect(item_rect, sel_color, 4 * sc)
                bar_rect = bgui.Rect(cr.x + pad_l, iy + 4 * sc, 3 * sc, ih - 8 * sc)
                renderer.draw_rounded_rect(bar_rect, self.active_color, 1.5 * sc)
            elif i == self._hover_index:
                renderer.draw_rounded_rect(item_rect, self.hover_color, 4 * sc)

            strip = item.get('data')
            if not isinstance(strip, SPStrip):
                continue

            # Draw gradient/flat color bar � fills the item row
            bar_inset = 4 * sc
            bar = bgui.Rect(
                item_rect.x + bar_inset, item_rect.y + bar_inset,
                item_rect.width - bar_inset * 2, item_rect.height - bar_inset * 2,
            )

            c1 = self._preview_color(strip, strip.stops[0][1])
            c2 = self._preview_color(strip, strip.stops[-1][1])
            if strip.strip_type == StripType.GRADIENT:
                if len(strip.stops) > 2:
                    grad_stops = [
                        (pos, self._preview_color(strip, color))
                        for pos, color in sorted(strip.stops, key=lambda s: s[0])
                    ]
                    renderer.draw_multi_stop_gradient(
                        bar, grad_stops, 3 * sc,
                        gradient_angle=0.0,
                    )
                else:
                    renderer.draw_rounded_rect(bar, c1, 3 * sc, color2=c2, gradient_angle=0.0)
            else:
                renderer.draw_rounded_rect(bar, c1, 3 * sc)

            # Draw strip name or inline edit text
            is_editing = (i == self._editing_index)
            display_name = self._edit_text if is_editing else strip.name
            txt_color = self._contrast_color(strip)
            font_sz = 11
            _, ref_h = renderer.measure_text("Ag", font_sz, font_weight="medium")
            txt_x = bar.x + 6 * sc
            txt_y = bar.y + (bar.height - ref_h) / 2
            if display_name:
                renderer.draw_text(display_name, txt_x, txt_y,
                                   size=font_sz, color=txt_color,
                                   font_weight="medium", ref_height=ref_h)
            # Draw cursor when editing
            if is_editing:
                pre_text = self._edit_text[:self._edit_cursor]
                pre_w, _ = renderer.measure_text(
                    pre_text or " ", font_sz, font_weight="medium")
                if not pre_text:
                    pre_w = 0
                # Selection highlight
                if self._edit_sel_start is not None:
                    s = min(self._edit_sel_start, self._edit_cursor)
                    e = max(self._edit_sel_start, self._edit_cursor)
                    sw, _ = renderer.measure_text(
                        self._edit_text[:s] or " ", font_sz, font_weight="medium")
                    if not self._edit_text[:s]:
                        sw = 0
                    ew, _ = renderer.measure_text(
                        self._edit_text[:e] or " ", font_sz, font_weight="medium")
                    if not self._edit_text[:e]:
                        ew = 0
                    renderer.draw_rounded_rect(
                        bgui.Rect(txt_x + sw, bar.y + 2 * sc, ew - sw, bar.height - 4 * sc),
                        (0.784, 1.0, 0.0, 0.3), 2 * sc)
                cur_x = txt_x + pre_w
                renderer.draw_rounded_rect(
                    bgui.Rect(cur_x, bar.y + 3 * sc, 1.5 * sc, bar.height - 6 * sc),
                    txt_color, 0.5 * sc)

            # Draw Settings + Edit icons on selected item
            if is_selected:
                s = self._ICON_SIZE * sc
                icon_y = bar.y + (bar.height - s) / 2
                edit_x = bar.x + bar.width - self._ICON_PAD_R * sc - s
                settings_x = edit_x - s - 4 * sc  # 4px gap between icons

                variant = self._pick_contrast(strip)
                edit_img = self._edit_dark if variant == "dark" else self._edit_light
                settings_img = self._settings_dark if variant == "dark" else self._settings_light

                if settings_img:
                    renderer.draw_image(settings_img, bgui.Rect(settings_x, icon_y, s, s))
                if edit_img:
                    renderer.draw_image(edit_img, bgui.Rect(edit_x, icon_y, s, s))

        # Scrollbar
        if has_scrollbar:
            track_y = cr.y + pad_v
            track_h = cr.height - pad_v * 2
            thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
            thumb_y = track_y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
            thumb_rect = bgui.Rect(cr.right - pad_r - 3 * sc, thumb_y, 3 * sc, thumb_h)
            renderer.draw_rounded_rect(thumb_rect, (1, 1, 1, 0.15), 1.5 * sc)

        renderer.pop_clip()

    def handle_mouse_press(self, x, y):
        if not self.visible or not self.rect.contains(x, y):
            # Click outside � confirm any ongoing edit
            if self._editing_index >= 0:
                self._confirm_edit()
            return False

        # Confirm edit if clicking a different strip
        cr = self.content_rect
        sc = ui_scale()
        ih = self.item_height * sc
        idx = int((y - cr.y - self._pad_v * sc + self.scroll_offset) / ih)
        if self._editing_index >= 0 and idx != self._editing_index:
            self._confirm_edit()

        # Check edit icon click on currently selected item
        if 0 <= idx < len(self.items) and idx == self.selected:
            pad_l = 8 * sc
            pad_r = 8 * sc
            max_scroll = self._max_scroll
            has_scrollbar = max_scroll > 0
            sb_gap = 10 * sc if has_scrollbar else 0
            sb_w = 3 * sc if has_scrollbar else 0
            item_w = cr.width - pad_l - sb_gap - sb_w - pad_r
            bar_inset = 4 * sc
            bar_right = cr.x + pad_l + item_w - bar_inset
            s = self._ICON_SIZE * sc
            iy = cr.y + self._pad_v * sc + idx * ih - self.scroll_offset
            icon_y = iy + 1 * sc + bar_inset + (ih - 2 * sc - bar_inset * 2 - s) / 2

            edit_x = bar_right - self._ICON_PAD_R * sc - s
            settings_x = edit_x - s - 4 * sc

            if edit_x <= x <= edit_x + s and icon_y <= y <= icon_y + s:
                if self.on_edit:
                    self.on_edit(self, idx)
                return True

            if settings_x <= x <= settings_x + s and icon_y <= y <= icon_y + s:
                if self.on_settings:
                    self.on_settings(self, idx)
                return True

        return super().handle_mouse_press(x, y)


def _section_title(text: str, icon_path: str = None):
    children = []
    if icon_path:
        children.append(_LazyIcon(icon_path, style=bgui.Style(width=14, height=14)))
    children.append(bgui.Label(text, style=bgui.Style(
        font_size=DT.font.lg,
        font_weight="semibold",
        font_color=(1.0, 1.0, 1.0, 1.0),
    )))
    return bgui.Row(style=bgui.Style(
        width_policy=bgui.SizePolicy.FILL,
        alignment=bgui.Alignment.CENTER,
        gap=6,
        padding=bgui.EdgeInsets(12, 0, 6, 0),
    ), children=children)


def _make_strip_datalist(app_state, items, on_edit, on_settings, on_select_fn,
                         on_rename=None, on_color_paste=None):
    """Create the StripDataList and store a reference on app_state for external scroll-to."""
    dl = StripDataList(
        items=items,
        selected=app_state.selected_strip_index,
        on_edit=on_edit,
        on_settings=on_settings,
        on_rename=on_rename,
        on_color_paste=on_color_paste,
        on_select=lambda w, idx: on_select_fn(idx),
        style=bgui.Style(
            width_policy=bgui.SizePolicy.FILL,
            height=160,
        ),
    )
    dl.on_right_click = lambda x, y: dl._on_right_click(x, y)
    # Preserve scroll position from previous DataList on rebuild
    old_dl = app_state._strip_datalist
    sel = app_state.selected_strip_index
    if old_dl is not None and hasattr(old_dl, 'scroll_offset'):
        dl.scroll_offset = old_dl.scroll_offset
        dl._scroll_target = old_dl.scroll_offset
    elif sel > 0:
        # Pre-scroll on first creation so selected item is visible
        sc = ui_scale()
        view_h = 160 * sc - dl._pad_v * sc * 2
        item_bottom = (sel + 1) * dl.item_height * sc
        if item_bottom > view_h:
            dl.scroll_offset = item_bottom - view_h
            dl._scroll_target = dl.scroll_offset
    app_state._strip_datalist = dl
    return dl


def build_active_root(app_state, grad_open, grad_state,
                      color_open=None, color_state=None,
                      on_create_click=None, on_import_click=None,
                      on_export_click=None,
                      on_strip_settings=None):
    """Build the active-state root widget (no panel). Returns a Column.

    Args:
        app_state: AppState with palettes and active_index.
        grad_open: callable to open gradient popup.
        grad_state: GradientState for the gradient editor.
        color_open: callable to open color picker popup.
        color_state: GradientState (single-stop) for the color picker.
        on_create_click: callback for Create New button.
        on_import_click: callback for Import button.
        on_export_click: callback for Export icon (datalist, index).
    """
    palette = app_state.active_palette
    palette_name = palette.name if palette else "Untitled"
    strips = palette.strips if palette else []

    palette_items = [
        {"name": p.name, "icon": os.path.join(_ASSETS, "Image.svg"), "data": p}
        for p in app_state.palettes
    ]

    # Buttons row: flat top corners, rounded bottom corners (matches card bottom)
    action_buttons = bgui.Row(
        style=bgui.Style(
            background_color=LIME,
            border_radius_tl=0,
            border_radius_tr=0,
            border_radius_br=DT.radius.xl,
            border_radius_bl=DT.radius.xl,
            width_policy=bgui.SizePolicy.FILL,
            alignment=bgui.Alignment.CENTER,
            padding=bgui.EdgeInsets(0, 0, 0, 0),
            gap=0,
        ),
        children=[
            _FlexButton("Create New",
                icon_path=os.path.join(_ASSETS, "plus_icon.png"),
                icon_size=18,
                style=bgui.Style(
                    background_color=(0, 0, 0, 0),
                    border_radius=0,
                    font_size=DT.font.md,
                    font_color=DARK_TEXT,
                    font_weight="semibold",
                    padding=bgui.EdgeInsets(8, 4, 8, 4),
                    flex=1,
                    width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={"background_color": (0, 0, 0, 0.08)},
                    active_style={"background_color": (0, 0, 0, 0.15)},
                ),
                on_click=on_create_click,
            ),
            bgui.Box(style=bgui.Style(
                width=1, height=20,
                background_color=(0.098, 0.098, 0.11, 0.2),
            )),
            _FlexButton("Import",
                icon_path=os.path.join(_ASSETS, "import_icon.png"),
                icon_size=18,
                style=bgui.Style(
                    background_color=(0, 0, 0, 0),
                    border_radius=0,
                    font_size=DT.font.md,
                    font_color=DARK_TEXT,
                    font_weight="semibold",
                    padding=bgui.EdgeInsets(8, 4, 8, 4),
                    flex=1,
                    width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    hover_style={"background_color": (0, 0, 0, 0.08)},
                    active_style={"background_color": (0, 0, 0, 0.15)},
                ),
                on_click=on_import_click,
            ),
        ],
    )

    # -- Active Palette Settings section ---------------------------------
    _color_spaces = get_color_spaces()
    _current_cs = palette.color_space if palette else "sRGB"
    _cs_idx = _color_spaces.index(_current_cs) if _current_cs in _color_spaces else 0
    color_dropdown = bgui.Dropdown(
        options=_color_spaces,
        selected=_cs_idx,
        columns=2,
        max_visible_rows=6,
        style=bgui.Style(
            background_color=(0.30, 0.30, 0.34, 1.0),
            border_color=(0.30, 0.30, 0.34, 1.0),
            border_width=0,
            border_radius=5,
            font_size=12,
            font_color=(1.0, 1.0, 1.0, 1.0),
            font_weight="semibold",
            height=26,
            width=120,
            padding=bgui.EdgeInsets(4, 20, 4, 8),
            hover_style={"background_color": (0.35, 0.35, 0.39, 1.0)},
        ),
    )

    def _on_color_space_change(dropdown):
        p = app_state.active_palette
        if p and 0 <= dropdown.selected < len(_color_spaces):
            apply_color_space(p, _color_spaces[dropdown.selected])
            app_state.notify()
    color_dropdown.on_change = _on_color_space_change

    def _setting_row(label_text, control):
        return bgui.Row(
            style=bgui.Style(
                width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER,
                main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
            ),
            children=[
                bgui.Label(label_text, style=bgui.Style(
                    font_size=DT.font.md,
                    font_weight="medium",
                    font_color=(1.0, 1.0, 1.0, 1.0),
                )),
                control,
            ],
        )

    strip_items = [{"name": s.name, "data": s} for s in strips]

    def _on_delete_palette(datalist, index):
        if 0 <= index < len(app_state.palettes):
            p = app_state.palettes[index]
            remove_texture(p)
            app_state.remove_palette(index)

    def _on_rename_palette(datalist, index, new_name):
        if 0 <= index < len(app_state.palettes):
            app_state.palettes[index].name = new_name
            app_state.notify()

    def _on_edit_strip(datalist, index):
        strip = strips[index]
        if strip.strip_type == StripType.FLAT and color_state and color_open:
            # Flat strip ? open color picker with the strip's color
            color_state.stops.clear()
            color = strip.stops[0][1] if strip.stops else (1.0, 1.0, 1.0, 1.0)
            color_state.stops.append(GradientStop(0.0, color))
            color_state.effects = dict(getattr(strip, 'effects', {}))
            color_state.select_stop(0)
            color_open()
        else:
            # Gradient strip ? open gradient editor with all stops
            grad_state.stops.clear()
            for pos, color in sorted(strip.stops, key=lambda s: s[0]):
                grad_state.stops.append(GradientStop(pos, color))
            grad_state.color_mode = getattr(strip, 'color_mode', 'RGB')
            grad_state.interpolation = getattr(strip, 'interpolation', 'LINEAR')
            grad_state.hue_interpolation = getattr(strip, 'hue_interpolation', 'NEAR')
            grad_state.effects = dict(getattr(strip, 'effects', {}))
            grad_state.select_stop(0)
            grad_open()

    def _on_rename_strip(datalist, index, new_name):
        if 0 <= index < len(strips):
            strips[index].name = new_name
            app_state.notify()

    def _on_color_paste_strip(datalist, index):
        """Handle Ctrl+V color paste on a flat strip."""
        if palette and 0 <= index < len(strips):
            update_strip(palette, index)
            app_state.notify()

    def _on_settings_strip(datalist, index):
        """Open settings popup for the strip."""
        if on_strip_settings and 0 <= index < len(strips):
            on_strip_settings(strips[index], index)

    def _set_strip_idx(idx):
        app_state.selected_strip_index = idx
        from . import overlay
        overlay.tag_redraw()

    settings_card = bgui.Column(
        style=bgui.Style(
            background_color=CARD_BG, border_radius=DT.radius.xl,
            padding=bgui.EdgeInsets(16, 16, 16, 16), gap=6,
            width_policy=bgui.SizePolicy.FILL, clip_children=True,
        ),
        children=[
            _section_title(
                "Active Palette Settings",
                icon_path=os.path.join(_ASSETS, "Settings.svg"),
            ),
            # Active palette name � left-aligned
            bgui.Label(palette_name, style=bgui.Style(
                font_size=DT.font.xl, font_weight="regular",
                font_color=(0.55, 0.55, 0.60, 1.0),
                width_policy=bgui.SizePolicy.FILL,
            )),
            bgui.Row(
                style=bgui.Style(
                    width_policy=bgui.SizePolicy.FILL,
                    alignment=bgui.Alignment.CENTER,
                    main_alignment=bgui.MainAxisAlignment.SPACE_BETWEEN,
                ),
                children=[
                    bgui.Row(
                        style=bgui.Style(
                            alignment=bgui.Alignment.CENTER,
                            gap=6,
                            height=26,
                        ),
                        children=[
                            _LazyIcon(
                                os.path.join(_ASSETS, "color_space.svg"),
                                style=bgui.Style(width=14, height=14),
                            ),
                            bgui.Label("Color Space", style=bgui.Style(
                                font_size=DT.font.lg,
                                font_weight="semibold",
                                font_color=(1.0, 1.0, 1.0, 1.0),
                            )),
                        ],
                    ),
                    color_dropdown,
                ],
            ),
            _section_title(
                "Strips",
                icon_path=os.path.join(_ASSETS, "Strips.svg"),
            ),
            _make_strip_datalist(
                app_state, strip_items, _on_edit_strip, _on_settings_strip, _set_strip_idx,
                on_rename=_on_rename_strip,
                on_color_paste=_on_color_paste_strip,
            ),
        ],
    )

    # -- Root ---------------------------------------------------------------
    root = bgui.Column(
        style=SS.panel(
            background_color=PANEL_BG,
            padding=bgui.EdgeInsets(14, 12, 14, 12),
            gap=12, border_width=0, border_color=None,
        ),
        children=[
            bgui.Label("Palette Grid", style=bgui.Style(
                font_size=DT.font.xxl, font_color=(1.0, 1.0, 1.0, 1.0),
                font_weight="bold", width_policy=bgui.SizePolicy.FILL,
                alignment=bgui.Alignment.CENTER,
                padding=bgui.EdgeInsets(4, 0, 20, 0),
            )),
            _CardWithIcon(
                icon_path=os.path.join(_ASSETS, "paintbrush_icon.png"),
                style=bgui.Style(
                    background_color=CARD_BG, border_radius=DT.radius.xl,
                    padding=bgui.EdgeInsets(40, 16, DT.radius.xl, 16), gap=0,
                    width_policy=bgui.SizePolicy.FILL, clip_children=True,
                ),
                children=[
                    _section_title(
                        "Palettes",
                        icon_path=os.path.join(_ASSETS, "Palletes.svg"),
                    ),
                    PaletteDataList(
                        items=palette_items,
                        selected=app_state.active_index,
                        on_select=lambda w, idx: app_state.set_active(idx),
                        on_delete=_on_delete_palette,
                        on_rename=_on_rename_palette,
                        on_export=on_export_click,
                        style=bgui.Style(
                            width_policy=bgui.SizePolicy.FILL,
                            height=160,
                            border_radius_br=0,
                            border_radius_bl=0,
                        ),
                    ),
                    action_buttons,
                ],
            ),
            settings_card,
        ],
    )

    return root
