# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Gradient Path drawing � modal stroke + real-time visualization in 3D Viewport.

The user draws a freehand path in the 3D Viewport.  While drawing, a thick
gradient-colored polyline is rendered as a POST_PIXEL overlay.  On release the
path is finalized (future phases add shape detection + UV projection).

Flow:
  1. Invoked from Image Editor pie menu ? enters modal
  2. User clicks (LEFTMOUSE) inside a 3D Viewport to start drawing
  3. MOUSEMOVE while held adds points to the path
  4. LEFTMOUSE RELEASE finalizes the path
  5. ESC / RIGHTMOUSE cancels at any time
"""
import math
import bpy
import gpu
from time import perf_counter as _clock
from gpu_extras.batch import batch_for_shader

from ..core import path as _path
from ..core.data import StripType
from ..bgui.core import ui_scale

# -- Module state ----------------------------------------------------------

_app_state = None
_draw_handle = None

# Live drawing state (set by the modal operator, read by the draw handler)
_active_points = []          # list of (x, y) screen-space (raw input)
_smooth_points = []          # list of (x, y) smoothed for rendering
_smooth_colors = []          # per-vertex (r, g, b, a) of smoothed path
_active_stops = []           # gradient stops for live re-sampling
_is_drawing = False
_waiting_for_start = False   # True = modal active, waiting for first click

# Stored result from last modal execution (used by execute() for redo panel)
_last_finalized_points = []
_last_finalized_lengths = []

# Shape detection state
_shape_detected = False      # True = currently showing detected shape
_detected_result = None      # dict from core.path.detect_shape()
_last_mouse_pos = (0, 0)     # for jitter check on shape cancel
_last_move_time = 0.0        # wallclock time of last significant mouse movement
_STILL_DELAY = 1.0           # seconds of stillness before shape detection fires
_shape_check_pending = False # True = a bpy.app.timers callback is scheduled

# Shape editing state (active after detection, user adjusts the shape)
_shape_edit_mode = False      # True = user is adjusting a detected shape
_shape_anchor = (0, 0)        # last mouse pos during editing (updated each frame)
_shape_base_points = []       # detected shape points before transform
_shape_cum_scale = 1.0        # accumulated scale factor
_shape_cum_angle = 0.0        # accumulated rotation (radians)
_shape_centroid = (0.0, 0.0)  # bounding-box center of shape (pivot)

# Appearance
_PATH_WIDTH = 5.0
_PATH_FEATHER = 2.0           # px � soft edge width for AA
_MIN_POINT_DIST = 6.0         # px � avoid oversampling
_SMOOTH_ITERATIONS = 2        # Chaikin passes for stabilization
_START_MARKER_RADIUS = 6.0
_END_MARKER_RADIUS = 4.0


# -- Draw callback (POST_PIXEL on SpaceView3D) ----------------------------

def _draw_path_callback():
    """Render the in-progress gradient path as an anti-aliased ribbon."""
    from ..bgui.panel import _shutting_down
    if _shutting_down:
        return
    if not _is_drawing or len(_smooth_points) < 2:
        return

    try:
        gpu.state.blend_set('ALPHA')

        # Build the ribbon geometry
        _draw_ribbon()

        # Start marker
        _draw_endpoint_marker(_smooth_points[0], _smooth_colors[0], _START_MARKER_RADIUS)

        # End marker
        if len(_smooth_points) > 1:
            _draw_endpoint_marker(_smooth_points[-1], _smooth_colors[-1],
                                  _END_MARKER_RADIUS)

        gpu.state.blend_set('NONE')
    except Exception:
        pass


def _compute_normals(points):
    """Compute perpendicular normals at each vertex of a polyline.

    Returns a list of (nx, ny) unit vectors, one per point.
    At interior vertices the normal is the average of adjacent segment normals.
    """
    import math
    n = len(points)
    if n < 2:
        return [(0.0, 1.0)] * n

    normals = []
    for i in range(n):
        # Tangent from previous and/or next segment
        if i == 0:
            dx = points[1][0] - points[0][0]
            dy = points[1][1] - points[0][1]
        elif i == n - 1:
            dx = points[-1][0] - points[-2][0]
            dy = points[-1][1] - points[-2][1]
        else:
            dx = points[i + 1][0] - points[i - 1][0]
            dy = points[i + 1][1] - points[i - 1][1]

        length = math.hypot(dx, dy)
        if length < 1e-8:
            normals.append((0.0, 1.0))
        else:
            # Perpendicular (rotate 90� CCW)
            normals.append((-dy / length, dx / length))
    return normals


def _draw_ribbon():
    """Draw a feathered quad-strip ribbon along the path with per-vertex gradient colors.

    Cross-section (4 columns):
        outer_left (alpha=0)  |  inner_left (full)  |  inner_right (full)  |  outer_right (alpha=0)
    This gives soft anti-aliased edges.
    """
    points = _smooth_points
    colors = _smooth_colors
    normals = _compute_normals(points)
    n = len(points)

    sc = ui_scale()
    half_w = _PATH_WIDTH * 0.5 * sc
    feather = _PATH_FEATHER * sc

    verts = []
    vert_colors = []

    for i in range(n):
        px, py = points[i]
        nx, ny = normals[i]
        r, g, b, a = colors[i]

        # 4 vertices per path point: outer_L, inner_L, inner_R, outer_R
        ol = (px + nx * (half_w + feather), py + ny * (half_w + feather))
        il = (px + nx * half_w, py + ny * half_w)
        ir = (px - nx * half_w, py - ny * half_w)
        orr = (px - nx * (half_w + feather), py - ny * (half_w + feather))

        verts.extend([ol, il, ir, orr])
        vert_colors.extend([
            (r, g, b, 0.0),   # outer left  � transparent
            (r, g, b, a),     # inner left  � full
            (r, g, b, a),     # inner right � full
            (r, g, b, 0.0),   # outer right � transparent
        ])

    # Build triangle indices for the ribbon
    indices = []
    for i in range(n - 1):
        base = i * 4
        nxt = (i + 1) * 4
        # 3 quads per segment, each as 2 triangles
        for col in range(3):
            v0 = base + col
            v1 = base + col + 1
            v2 = nxt + col + 1
            v3 = nxt + col
            indices.append((v0, v1, v2))
            indices.append((v0, v2, v3))

    shader = gpu.shader.from_builtin('SMOOTH_COLOR')
    batch = batch_for_shader(
        shader, 'TRIS',
        {"pos": verts, "color": vert_colors},
        indices=indices,
    )
    shader.bind()
    batch.draw(shader)


def _draw_endpoint_marker(pos, color, radius, segments=16):
    """Draw a small filled circle at *pos* with the given *color*."""
    import math
    cx, cy = pos
    radius = radius * ui_scale()
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    verts = [(cx, cy)]
    for i in range(segments + 1):
        a = 2.0 * math.pi * i / segments
        verts.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
    indices = [(0, i, i + 1) for i in range(1, len(verts) - 1)]
    batch = batch_for_shader(shader, 'TRIS', {"pos": verts}, indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)

    # White rim
    rim_verts = verts[1:]  # skip center
    rim_batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": rim_verts})
    gpu.state.line_width_set(1.5 * ui_scale())
    shader.uniform_float("color", (1.0, 1.0, 1.0, 0.8))
    rim_batch.draw(shader)


# -- Helpers ---------------------------------------------------------------

def _recompute_smooth():
    """Rebuild smoothed path + per-vertex colors from raw input points."""
    global _smooth_points, _smooth_colors
    if len(_active_points) < 2 or not _active_stops:
        _smooth_points = list(_active_points)
        _smooth_colors = [(1.0, 1.0, 1.0, 1.0)] * len(_smooth_points)
        return

    _smooth_points = _path.smooth_path(_active_points, _SMOOTH_ITERATIONS)
    _apply_gradient_colors()


def _apply_shape_visual(shape_points):
    """Replace the visualization with a detected shape's geometry."""
    global _smooth_points, _smooth_colors
    # Lines need subdivision for multi-stop gradient visibility
    if len(shape_points) == 2:
        _smooth_points = _subdivide_line(shape_points[0], shape_points[1])
    else:
        _smooth_points = shape_points
    _apply_gradient_colors()


def _apply_gradient_colors():
    """Recompute per-vertex gradient colors for the current _smooth_points."""
    global _smooth_colors
    if len(_smooth_points) < 2:
        _smooth_colors = [(1.0, 1.0, 1.0, 1.0)] * len(_smooth_points)
        return
    cum = _path.arc_lengths(_smooth_points)
    t_values = _path.normalize_lengths(cum)
    _smooth_colors = [_path.sample_gradient(_active_stops, 1.0 - t) for t in t_values]


def _add_point(x, y):
    """Append a point if it's far enough from the last one, then recolor."""
    global _active_points
    if _active_points:
        lx, ly = _active_points[-1]
        dx, dy = x - lx, y - ly
        min_dist = _MIN_POINT_DIST * ui_scale()
        if dx * dx + dy * dy < min_dist * min_dist:
            return False
    _active_points.append((x, y))
    _recompute_smooth()
    return True


def _schedule_shape_check():
    """Schedule a lightweight app-timer callback to detect shape after stillness."""
    global _shape_check_pending
    if _shape_check_pending or _shape_detected:
        return
    if len(_active_points) < 5:
        return
    _shape_check_pending = True
    bpy.app.timers.register(_shape_check_callback, first_interval=_STILL_DELAY)


def _shape_check_callback():
    """bpy.app.timers callback � runs once after _STILL_DELAY.

    If the user hasn't moved since scheduling, trigger shape detection.
    If not still long enough yet, re-schedules for the remaining time.
    Returns None to unregister, or a float to re-schedule.
    """
    global _shape_detected, _detected_result, _shape_check_pending
    _shape_check_pending = False

    if not _is_drawing or _shape_detected:
        return None

    if len(_active_points) < 5:
        return None

    elapsed = _clock() - _last_move_time
    if elapsed >= _STILL_DELAY:
        result = _path.detect_shape(_active_points)
        if result['type'] != 'freehand':
            _shape_detected = True
            _detected_result = result
            _apply_shape_visual(result['points'])
            _tag_3d_redraw()
        return None

    # Not still long enough � re-schedule for the remaining time.
    _shape_check_pending = True
    return _STILL_DELAY - elapsed


def _subdivide_line(start, end, n=32):
    """Generate n+1 evenly spaced points along a line segment."""
    sx, sy = start
    ex, ey = end
    return [(sx + (ex - sx) * i / n, sy + (ey - sy) * i / n) for i in range(n + 1)]


def _update_line_endpoint(mx, my):
    """Move the line's endpoint to the mouse position (start stays fixed)."""
    global _smooth_points, _detected_result
    start = _shape_base_points[0]
    subdivided = _subdivide_line(start, (mx, my))
    _smooth_points = subdivided
    _detected_result['points'] = [start, (mx, my)]
    _apply_gradient_colors()


def _update_shape_transform(dx, dy):
    """Scale (horizontal delta) or rotate (vertical delta) the detected shape.

    Incremental � dx/dy are small deltas from the previous frame.
    Accumulated values are always applied from the base shape (no drift).
    """
    global _smooth_points, _detected_result, _shape_cum_scale, _shape_cum_angle

    if abs(dx) >= abs(dy):
        _shape_cum_scale -= dx * 0.005
        if _shape_cum_scale < 0.1:
            _shape_cum_scale = 0.1
    else:
        _shape_cum_angle += -dy * 0.005

    cx, cy = _shape_centroid

    cos_a = math.cos(_shape_cum_angle)
    sin_a = math.sin(_shape_cum_angle)

    new_points = []
    for px, py in _shape_base_points:
        rx, ry = px - cx, py - cy
        rx *= _shape_cum_scale
        ry *= _shape_cum_scale
        nx = rx * cos_a - ry * sin_a
        ny = rx * sin_a + ry * cos_a
        new_points.append((cx + nx, cy + ny))

    _smooth_points = new_points
    _detected_result['points'] = new_points
    _apply_gradient_colors()


def _enter_shape_edit(mx, my, context):
    """Initialize shape editing mode on first movement after detection."""
    global _shape_edit_mode, _shape_anchor, _shape_base_points
    global _shape_cum_scale, _shape_cum_angle, _shape_centroid
    _shape_edit_mode = True
    _shape_anchor = (mx, my)
    _shape_base_points = list(_smooth_points)
    _shape_cum_scale = 1.0
    _shape_cum_angle = 0.0
    # Bounding-box center as pivot (immune to point distribution)
    xs = [p[0] for p in _shape_base_points]
    ys = [p[1] for p in _shape_base_points]
    _shape_centroid = ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2)
    if _detected_result['type'] == 'line':
        context.workspace.status_text_set(
            "Move to adjust endpoint | Release to confirm | ESC to cancel")
    else:
        context.workspace.status_text_set(
            "\u2190\u2192 Scale | \u2191\u2193 Rotate | Release to confirm | ESC to cancel")


def _tag_3d_redraw():
    """Redraw all 3D Viewport areas."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# -- Modal operator --------------------------------------------------------

class PALETTE_OT_path_draw(bpy.types.Operator):
    """Draw a gradient path in the 3D Viewport"""
    bl_idname = "palette_grid.path_draw"
    bl_label = "Draw Gradient Path"
    bl_options = {'REGISTER', 'UNDO'}

    _app_state_ref = None

    direction: bpy.props.EnumProperty(
        name="Direction",
        description="Gradient axis direction for UV distribution",
        items=[
            ('DEFAULT', "Default", "Use the strip/palette direction"),
            ('Horizontal', "Horizontal", "Distribute along horizontal axis"),
            ('Vertical', "Vertical", "Distribute along vertical axis"),
        ],
        default='DEFAULT',
        options={'SKIP_SAVE'},
    )

    margin: bpy.props.FloatProperty(
        name="Margin",
        description="Inset on each side of the cell to prevent color bleed",
        default=0.01, min=0.0, max=0.1, precision=3,
        options={'SKIP_SAVE'},
    )

    invert: bpy.props.BoolProperty(
        name="Invert",
        description="Flip the gradient direction (swap 0 and 1)",
        default=False,
        options={'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        global _is_drawing, _waiting_for_start
        global _active_points, _active_stops
        global _smooth_points, _smooth_colors
        global _shape_detected, _detected_result, _last_mouse_pos, _last_move_time
        global _shape_edit_mode

        self._timer = None

        state = PALETTE_OT_path_draw._app_state_ref
        if state is None or state.active_palette is None:
            self.report({'WARNING'}, "No active palette")
            return {'CANCELLED'}
        if state.selected_strip_index < 0:
            self.report({'WARNING'}, "No strip selected")
            return {'CANCELLED'}

        # Find a 3D Viewport to register the modal in (needed for correct
        # mouse_region coordinates and context.space_data).
        target_area = None
        target_region = None
        if context.area and context.area.type == 'VIEW_3D':
            target_area = context.area
            for r in context.area.regions:
                if r.type == 'WINDOW':
                    target_region = r
                    break
        else:
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    target_area = area
                    for r in area.regions:
                        if r.type == 'WINDOW':
                            target_region = r
                            break
                    break

        if target_area is None or target_region is None:
            self.report({'WARNING'}, "No 3D Viewport found")
            return {'CANCELLED'}

        # Set up modal state
        palette = state.active_palette
        strip = palette.strips[state.selected_strip_index]

        _active_stops = list(strip.stops)
        _active_points = []
        _smooth_points = []
        _smooth_colors = []
        _is_drawing = False
        _waiting_for_start = True

        # Shape detection state reset
        _shape_detected = False
        _detected_result = None
        _last_mouse_pos = (0, 0)
        _last_move_time = 0.0
        _shape_edit_mode = False
        _shape_base_points.clear()

        _ensure_draw_handler()

        # Timer to keep the event loop alive during stillness so
        # bpy.app.timers (shape detection) actually fire.
        self._timer = context.window_manager.event_timer_add(
            0.1, window=context.window)

        # Register modal handler in the 3D Viewport context so that
        # event.mouse_region_x/y and context.space_data are correct.
        with context.temp_override(area=target_area, region=target_region):
            context.window_manager.modal_handler_add(self)

        context.workspace.status_text_set("LMB-draw in 3D Viewport | ESC to cancel")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _is_drawing, _waiting_for_start
        global _active_points
        global _shape_detected, _detected_result, _last_mouse_pos, _last_move_time
        global _shape_anchor

        # Cache event properties once to avoid repeated RNA lookups
        # (unknown event type codes trigger a Blender warning per access)
        evt_type = event.type
        evt_value = event.value

        # Timer events keep the loop alive for bpy.app.timers � just consume them.
        if evt_type == 'TIMER':
            return {'RUNNING_MODAL'}

        # Cancel at any time
        if evt_type in {'RIGHTMOUSE', 'ESC'}:
            self._cancel(context)
            return {'CANCELLED'}

        # Phase 1: Waiting for LMB press inside a 3D Viewport
        if _waiting_for_start:
            if evt_type == 'LEFTMOUSE' and evt_value == 'PRESS':
                if context.area and context.area.type == 'VIEW_3D':
                    _waiting_for_start = False
                    _is_drawing = True
                    mx, my = event.mouse_region_x, event.mouse_region_y
                    _active_points = [(mx, my)]
                    _last_mouse_pos = (mx, my)
                    _last_move_time = _clock()
                    _recompute_smooth()
                    _tag_3d_redraw()
                    return {'RUNNING_MODAL'}
            return {'RUNNING_MODAL'}

        # Phase 2: Drawing � capturing mouse movement

        if evt_type == 'MOUSEMOVE':
            mx, my = event.mouse_region_x, event.mouse_region_y
            lx, ly = _last_mouse_pos

            if _shape_detected:
                # -- Shape editing mode ----------------------------
                if abs(mx - lx) > 3 or abs(my - ly) > 3:
                    _last_mouse_pos = (mx, my)
                    if not _shape_edit_mode:
                        _enter_shape_edit(mx, my, context)
                    if _detected_result['type'] == 'line':
                        _update_line_endpoint(mx, my)
                    else:
                        dx = mx - _shape_anchor[0]
                        dy = my - _shape_anchor[1]
                        _shape_anchor = (mx, my)  # reset for next frame
                        _update_shape_transform(dx, dy)
                    _tag_3d_redraw()
                return {'RUNNING_MODAL'}

            # -- Normal drawing (no shape detected) ------------
            if abs(mx - lx) > 3 or abs(my - ly) > 3:
                _last_mouse_pos = (mx, my)
                _last_move_time = _clock()
                _schedule_shape_check()

            _add_point(mx, my)
            _tag_3d_redraw()
            return {'RUNNING_MODAL'}

        if evt_type == 'LEFTMOUSE' and evt_value == 'RELEASE':
            # Use detected shape if active, otherwise freehand
            if _shape_detected and _detected_result is not None:
                final_points = _detected_result['points']
            else:
                _add_point(event.mouse_region_x, event.mouse_region_y)
                final_points = _path.simplify_path(list(_active_points),
                                                   _MIN_POINT_DIST * ui_scale())

            self._finalized_points = final_points
            self._finalized_lengths = _path.arc_lengths(final_points)
            self._finalized_shape = (_detected_result['type']
                                     if _detected_result else 'freehand')

            # Store for execute() redo panel re-application
            global _last_finalized_points, _last_finalized_lengths
            _last_finalized_points = list(final_points)
            _last_finalized_lengths = list(self._finalized_lengths)

            # Phase 3: UV projection
            from . import uv_snap as _uv_snap
            state = PALETTE_OT_path_draw._app_state_ref
            rv3d = context.space_data.region_3d
            if self.direction == 'DEFAULT':
                # Follow strip's direction override, else palette default
                palette = state.palettes[state.active_index]
                strip = palette.strips[state.selected_strip_index]
                d = strip.direction  # None ? path_snap_uvs falls back to palette.direction
            else:
                d = self.direction
            uv_result = _uv_snap.path_snap_uvs(
                state,
                final_points,
                self._finalized_lengths,
                context.region,
                rv3d,
                direction_override=d,
                margin=self.margin,
                invert=self.invert,
            )
            if uv_result == 'OK':
                self.report({'INFO'},
                            f"Gradient path applied ({self._finalized_shape})")
                _uv_snap._apply_recording_prefs()
            elif uv_result == 'NO_MESH':
                self.report({'INFO'}, "No edit mesh � UVs not applied")
            elif uv_result == 'NO_SELECTION':
                self.report({'INFO'}, "No faces selected � UVs not applied")
            elif uv_result == 'NO_VISIBLE':
                self.report({'INFO'}, "No visible vertices � UVs not applied")

            self._finish(context)
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "direction")
        layout.prop(self, "margin")
        layout.prop(self, "invert")

    def execute(self, context):
        """Re-apply UV snap with current properties (called by redo panel)."""
        from . import uv_snap as _uv_snap
        state = PALETTE_OT_path_draw._app_state_ref
        if state is None or state.active_palette is None:
            return {'CANCELLED'}
        if not _last_finalized_points:
            return {'CANCELLED'}

        # Find 3D viewport region and rv3d
        rv3d = None
        region = None
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        rv3d = space.region_3d
                        break
                for r in area.regions:
                    if r.type == 'WINDOW':
                        region = r
                        break
                break
        if rv3d is None or region is None:
            return {'CANCELLED'}

        if self.direction == 'DEFAULT':
            palette = state.palettes[state.active_index]
            strip = palette.strips[state.selected_strip_index]
            d = strip.direction
        else:
            d = self.direction

        uv_result = _uv_snap.path_snap_uvs(
            state,
            _last_finalized_points,
            _last_finalized_lengths,
            region,
            rv3d,
            direction_override=d,
            margin=self.margin,
            invert=self.invert,
        )
        if uv_result == 'OK':
            _uv_snap._apply_recording_prefs()
            return {'FINISHED'}
        return {'CANCELLED'}

    def _cancel(self, context):
        global _is_drawing, _waiting_for_start
        global _shape_detected, _detected_result, _shape_check_pending
        global _shape_edit_mode
        _is_drawing = False
        _waiting_for_start = False
        _shape_detected = False
        _detected_result = None
        _shape_edit_mode = False
        _shape_base_points.clear()
        if _shape_check_pending:
            _shape_check_pending = False
            try:
                bpy.app.timers.unregister(_shape_check_callback)
            except ValueError:
                pass
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        _active_points.clear()
        _smooth_points.clear()
        _smooth_colors.clear()
        context.workspace.status_text_set(None)
        _tag_3d_redraw()

    def _finish(self, context):
        global _is_drawing, _waiting_for_start
        global _shape_detected, _detected_result, _shape_check_pending
        global _shape_edit_mode
        _is_drawing = False
        _waiting_for_start = False
        _shape_detected = False
        _detected_result = None
        _shape_edit_mode = False
        _shape_base_points.clear()
        if _shape_check_pending:
            _shape_check_pending = False
            try:
                bpy.app.timers.unregister(_shape_check_callback)
            except ValueError:
                pass
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        _tag_3d_redraw()


# -- Draw handler management -----------------------------------------------

def _ensure_draw_handler():
    """Register the POST_PIXEL handler on SpaceView3D if not already active."""
    global _draw_handle
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_path_callback, (), 'WINDOW', 'POST_PIXEL')


# -- Registration ----------------------------------------------------------

def register(app_state):
    global _app_state
    _app_state = app_state
    PALETTE_OT_path_draw._app_state_ref = app_state
    _ensure_draw_handler()
    bpy.utils.register_class(PALETTE_OT_path_draw)


def unregister():
    global _draw_handle, _app_state, _is_drawing
    _is_drawing = False
    try:
        bpy.utils.unregister_class(PALETTE_OT_path_draw)
    except RuntimeError:
        pass
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, 'WINDOW')
        _draw_handle = None
    _app_state = None
