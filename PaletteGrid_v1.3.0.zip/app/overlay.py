# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Image Editor overlay � selection outline, gradient stop markers, hover tool.

Registers a POST_PIXEL draw handler on SpaceImageEditor, a modal operator
for interactive stop repositioning, a Strip Picker workspace tool with
hover-highlight and click-to-select, and a right-click pie menu.
"""
import bpy
import gpu
import math
import os
from gpu_extras.batch import batch_for_shader

from ..core.data import StripType
from ..bgui.core import ui_scale
from . import uv_snap as _uv_snap
from . import path_draw as _path_draw

_draw_handle = None
_app_state_ref = None
_custom_icon_handle = None
_ASSETS = os.path.join(os.path.dirname(__file__), "assets")

# -- Appearance constants --------------------------------------------------

_OUTLINE_COLOR = (0.784, 1.0, 0.0, 0.85)   # lime green
_OUTLINE_WIDTH = 2.0

_HOVER_COLOR = (1.0, 1.0, 1.0, 0.15)        # semi-transparent white
_HOVER_BORDER = (1.0, 1.0, 1.0, 0.4)
_HOVER_BORDER_WIDTH = 1.5

_LINE_COLOR = (1.0, 1.0, 1.0, 0.3)          # subtle guide line
_LINE_WIDTH = 1.5

_STOP_RADIUS = 7.0        # screen px
_STOP_RIM_WIDTH = 2.0
_STOP_RIM_COLOR = (1.0, 1.0, 1.0, 0.95)

_HIT_MARGIN = 4.0         # extra px for easier click detection
_CIRCLE_SEGMENTS = 24

# -- Hover state -----------------------------------------------------------

_hover_strip_index = -1    # cell the mouse is over (-1 = none)


# -- Geometry helpers ------------------------------------------------------

# -- Geometry helpers ------------------------------------------------------

_get_cell_uv_bounds = _uv_snap.get_cell_uv_bounds


def _stop_screen_pos(v2d, palette, strip, stop_pos, u_min, v_min, u_max, v_max):
    """Convert a gradient stop position (0-1) to screen (x, y)."""
    direction = strip.direction or palette.direction
    if direction == "Vertical":
        u = (u_min + u_max) / 2
        v = v_max - stop_pos * (v_max - v_min)
        return v2d.view_to_region(u, v, clip=False)
    else:
        u = u_min + stop_pos * (u_max - u_min)
        v = (v_min + v_max) / 2
        return v2d.view_to_region(u, v, clip=False)


def _hit_test_cell(context, event):
    """Return the strip index at the mouse position, or -1."""
    state = _app_state_ref
    if state is None:
        return -1
    palette = state.active_palette
    if palette is None or palette.image_name is None:
        return -1
    space = context.space_data
    if not hasattr(space, 'image') or space.image is None:
        return -1
    if space.image.name != palette.image_name:
        return -1

    v2d = context.region.view2d
    u, v = v2d.region_to_view(event.mouse_region_x, event.mouse_region_y)
    if u != u or v != v:  # NaN check
        return -1
    cols = palette.grid_cols
    rows = palette.grid_rows
    col = int(u * cols)
    row = int((1.0 - v) * rows)

    if 0 <= col < cols and 0 <= row < rows:
        idx = row * cols + col
        if idx < len(palette.strips):
            return idx
    return -1


def _circle_fill_batch(shader, cx, cy, radius, segments=_CIRCLE_SEGMENTS):
    """Create a TRIS batch for a filled circle (triangle-fan)."""
    verts = [(cx, cy)]
    for i in range(segments + 1):
        a = 2.0 * math.pi * i / segments
        verts.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
    indices = [(0, i, i + 1) for i in range(1, len(verts) - 1)]
    return batch_for_shader(shader, 'TRIS', {"pos": verts}, indices=indices)


def _circle_outline_batch(shader, cx, cy, radius, segments=_CIRCLE_SEGMENTS):
    """Create a LINE_STRIP batch for a circle outline."""
    verts = []
    for i in range(segments + 1):
        a = 2.0 * math.pi * i / segments
        verts.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
    return batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})


# -- Draw callback ---------------------------------------------------------

def _draw_callback():
    """POST_PIXEL handler � hover highlight, selection outline, gradient stops."""
    from ..bgui.panel import _shutting_down
    if _shutting_down:
        return

    state = _app_state_ref
    if state is None:
        return

    palette = state.active_palette
    if palette is None or palette.image_name is None:
        return

    context = bpy.context
    space = context.space_data
    if not hasattr(space, 'image') or space.image is None:
        return
    if space.image.name != palette.image_name:
        return

    try:
        _draw_callback_inner(context, state, palette)
    except Exception:
        pass


def _draw_callback_inner(context, state, palette):
    """GPU drawing logic � separated for exception safety."""
    region = context.region
    v2d = region.view2d
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    sc = ui_scale()
    gpu.state.blend_set('ALPHA')

    # -- Hover highlight ------------------------------------------------
    hover_idx = _hover_strip_index
    strip_idx = state.selected_strip_index
    if hover_idx >= 0 and hover_idx != strip_idx and hover_idx < len(palette.strips):
        hu, hv, hu2, hv2 = _get_cell_uv_bounds(palette, hover_idx)
        hx1, hy1 = v2d.view_to_region(hu, hv, clip=False)
        hx2, hy2 = v2d.view_to_region(hu2, hv2, clip=False)
        if hx1 != hx2 and hy1 != hy2:
            # Filled hover rect
            fill_verts = [(hx1, hy1), (hx2, hy1), (hx2, hy2), (hx1, hy2)]
            fill_batch = batch_for_shader(shader, 'TRIS', {"pos": fill_verts},
                                          indices=[(0, 1, 2), (0, 2, 3)])
            shader.bind()
            shader.uniform_float("color", _HOVER_COLOR)
            fill_batch.draw(shader)
            # Hover border
            gpu.state.line_width_set(_HOVER_BORDER_WIDTH * sc)
            border_verts = [*fill_verts, fill_verts[0]]
            border_batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": border_verts})
            shader.bind()
            shader.uniform_float("color", _HOVER_BORDER)
            border_batch.draw(shader)

    # -- Selection outline ----------------------------------------------
    if strip_idx < 0 or strip_idx >= len(palette.strips):
        gpu.state.line_width_set(1.0 * sc)
        gpu.state.blend_set('NONE')
        return

    u_min, v_min, u_max, v_max = _get_cell_uv_bounds(palette, strip_idx)
    x1, y1 = v2d.view_to_region(u_min, v_min, clip=False)
    x2, y2 = v2d.view_to_region(u_max, v_max, clip=False)

    if x1 == x2 or y1 == y2:
        gpu.state.line_width_set(1.0 * sc)
        gpu.state.blend_set('NONE')
        return

    gpu.state.line_width_set(_OUTLINE_WIDTH * sc)
    verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)]
    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})
    shader.bind()
    shader.uniform_float("color", _OUTLINE_COLOR)
    batch.draw(shader)

    # -- Gradient stop markers ------------------------------------------
    strip = palette.strips[strip_idx]
    if strip.strip_type == StripType.GRADIENT and len(strip.stops) > 0:
        _draw_gradient_stops(shader, v2d, palette, strip, u_min, v_min, u_max, v_max)

    gpu.state.line_width_set(1.0 * sc)
    gpu.state.blend_set('NONE')


def _draw_gradient_stops(shader, v2d, palette, strip, u_min, v_min, u_max, v_max):
    """Draw the gradient guide line and circular stop markers."""
    is_vert = (strip.direction or palette.direction) == "Vertical"
    sc = ui_scale()
    stop_radius = _STOP_RADIUS * sc

    if is_vert:
        uc = (u_min + u_max) / 2
        lx0, ly0 = v2d.view_to_region(uc, v_min, clip=False)
        lx1, ly1 = v2d.view_to_region(uc, v_max, clip=False)
    else:
        vc = (v_min + v_max) / 2
        lx0, ly0 = v2d.view_to_region(u_min, vc, clip=False)
        lx1, ly1 = v2d.view_to_region(u_max, vc, clip=False)

    gpu.state.line_width_set(_LINE_WIDTH * sc)
    line = batch_for_shader(shader, 'LINE_STRIP', {"pos": [(lx0, ly0), (lx1, ly1)]})
    shader.bind()
    shader.uniform_float("color", _LINE_COLOR)
    line.draw(shader)

    for pos, color in sorted(strip.stops, key=lambda s: s[0]):
        sx, sy = _stop_screen_pos(v2d, palette, strip, pos, u_min, v_min, u_max, v_max)
        fill = _circle_fill_batch(shader, sx, sy, stop_radius)
        shader.bind()
        shader.uniform_float("color", color)
        fill.draw(shader)
        gpu.state.line_width_set(_STOP_RIM_WIDTH * sc)
        rim = _circle_outline_batch(shader, sx, sy, stop_radius)
        shader.bind()
        shader.uniform_float("color", _STOP_RIM_COLOR)
        rim.draw(shader)


# -- Drag-stop modal operator ---------------------------------------------

class PALETTE_OT_drag_stop(bpy.types.Operator):
    """Drag a gradient stop marker in the Image Editor"""
    bl_idname = "palette_grid.drag_stop"
    bl_label = "Drag Gradient Stop"
    bl_options = {'INTERNAL'}

    _dragging_index: int = -1
    _original_pos: float = 0.0
    _palette = None
    _strip = None

    def invoke(self, context, event):
        state = _app_state_ref
        if state is None:
            return {'PASS_THROUGH'}

        palette = state.active_palette
        if palette is None or palette.image_name is None:
            return {'PASS_THROUGH'}

        strip_idx = state.selected_strip_index
        if strip_idx < 0 or strip_idx >= len(palette.strips):
            return {'PASS_THROUGH'}

        strip = palette.strips[strip_idx]
        if strip.strip_type != StripType.GRADIENT:
            return {'PASS_THROUGH'}

        space = context.space_data
        if not hasattr(space, 'image') or space.image is None:
            return {'PASS_THROUGH'}
        if space.image.name != palette.image_name:
            return {'PASS_THROUGH'}

        v2d = context.region.view2d
        u_min, v_min, u_max, v_max = _get_cell_uv_bounds(palette, strip_idx)
        mx, my = event.mouse_region_x, event.mouse_region_y

        best_idx = -1
        best_dist = (_STOP_RADIUS + _HIT_MARGIN) * ui_scale()
        for i, (pos, _color) in enumerate(strip.stops):
            sx, sy = _stop_screen_pos(v2d, palette, strip, pos, u_min, v_min, u_max, v_max)
            dist = math.hypot(mx - sx, my - sy)
            if dist < best_dist:
                best_dist = dist
                best_idx = i

        if best_idx < 0:
            return {'PASS_THROUGH'}

        self._dragging_index = best_idx
        self._original_pos = strip.stops[best_idx][0]
        self._palette = palette
        self._strip = strip
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        evt_type = event.type
        evt_value = event.value

        if evt_type == 'MOUSEMOVE':
            self._update_stop_pos(context, event)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if evt_type == 'LEFTMOUSE' and evt_value == 'RELEASE':
            self._update_stop_pos(context, event)
            from .texture import update_texture
            update_texture(self._palette)
            context.area.tag_redraw()
            self._cleanup()
            return {'FINISHED'}

        if evt_type in {'RIGHTMOUSE', 'ESC'}:
            idx = self._dragging_index
            self._strip.stops[idx] = (self._original_pos, self._strip.stops[idx][1])
            context.area.tag_redraw()
            self._cleanup()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _update_stop_pos(self, context, event):
        v2d = context.region.view2d
        strip_idx = _app_state_ref.selected_strip_index
        u_min, v_min, u_max, v_max = _get_cell_uv_bounds(self._palette, strip_idx)
        u, v = v2d.region_to_view(event.mouse_region_x, event.mouse_region_y)
        if self._palette.direction == "Vertical":
            span = v_max - v_min
            new_pos = (v_max - v) / span if span else 0.0
        else:
            span = u_max - u_min
            new_pos = (u - u_min) / span if span else 0.0
        new_pos = max(0.0, min(1.0, new_pos))
        idx = self._dragging_index
        self._strip.stops[idx] = (new_pos, self._strip.stops[idx][1])

    def _cleanup(self):
        self._dragging_index = -1
        self._palette = None
        self._strip = None


# -- Strip Picker tool operators -------------------------------------------

def _is_picker_active():
    """Check if our Strip Picker is the active IMAGE_EDITOR tool."""
    try:
        ws = bpy.context.workspace
        if ws is None:
            return False
        # Determine the current Image Editor mode so we check the right tool slot
        area = bpy.context.area
        mode = 'VIEW'
        if area and area.type == 'IMAGE_EDITOR' and area.spaces.active:
            mode = area.spaces.active.mode
        for ref in ws.tools:
            if ref.space_type == 'IMAGE_EDITOR' and ref.mode == mode:
                return ref.idname == "palette_grid.strip_picker"
    except Exception:
        pass
    return False


class PALETTE_OT_strip_hover(bpy.types.Operator):
    """Update hover highlight over texture cells (invoked on MOUSEMOVE)"""
    bl_idname = "palette_grid.strip_hover"
    bl_label = "Strip Hover"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        global _hover_strip_index
        if not _is_picker_active():
            if _hover_strip_index != -1:
                _hover_strip_index = -1
                if context.area:
                    context.area.tag_redraw()
            return {'PASS_THROUGH'}
        old = _hover_strip_index
        _hover_strip_index = _hit_test_cell(context, event)
        if _hover_strip_index != old and context.area:
            context.area.tag_redraw()
        return {'PASS_THROUGH'}


class PALETTE_OT_strip_pick(bpy.types.Operator):
    """Select a strip by clicking its cell in the texture"""
    bl_idname = "palette_grid.strip_pick"
    bl_label = "Pick Strip"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if not _is_picker_active():
            return {'PASS_THROUGH'}
        idx = _hit_test_cell(context, event)
        if idx < 0:
            return {'PASS_THROUGH'}

        state = _app_state_ref
        state.selected_strip_index = idx

        # Update the DataList widget in the sidebar
        dl = state._strip_datalist
        if dl is not None:
            dl.selected = idx
            dl.scroll_to_index(idx)

        # Redraw Image Editor + sidebar
        _tag_all_redraw()
        return {'FINISHED'}


# -- Strip Pie Menu (right-click) -----------------------------------------

class PALETTE_MT_strip_pie(bpy.types.Menu):
    bl_idname = "PALETTE_MT_strip_pie"
    bl_label = "Strip Actions"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        # Check preference: allow bypassing edit mode detection
        skip_check = False
        try:
            pkg = __package__.rsplit('.', 1)[0]  # palette_grid
            prefs = context.preferences.addons[pkg].preferences
            skip_check = prefs.skip_edit_mode_check
        except (KeyError, AttributeError):
            pass
        if not skip_check and not _uv_snap.has_edit_mesh():
            pie.label(text="No mesh in Edit Mode", icon='ERROR')
            return
        pie.operator("palette_grid.uv_snap", text="UV Snap", icon='UV_FACESEL')
        # Radial Snap
        pie.operator("palette_grid.uv_radial_snap", text="Radial Snap", icon='PIVOT_CURSOR')
        # Gradient Path
        pie.operator("palette_grid.path_draw", text="Gradient Path", icon='GREASEPENCIL')
        # Project From View
        pie.operator("palette_grid.uv_project_from_view", text="Project From View", icon='VIEW3D')


class PALETTE_OT_strip_pie(bpy.types.Operator):
    """Open the strip actions pie menu"""
    bl_idname = "palette_grid.strip_pie"
    bl_label = "Strip Pie Menu"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if not _is_picker_active():
            return {'PASS_THROUGH'}
        state = _app_state_ref
        if state is None or state.selected_strip_index < 0:
            return {'PASS_THROUGH'}
        idx = _hit_test_cell(context, event)
        if idx < 0 or idx != state.selected_strip_index:
            return {'PASS_THROUGH'}
        bpy.ops.wm.call_menu_pie(name=PALETTE_MT_strip_pie.bl_idname)
        return {'FINISHED'}


class PG_ToolStripPicker(bpy.types.WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'VIEW'
    bl_idname = "palette_grid.strip_picker"
    bl_label = "Strip Picker"
    bl_description = "Hover to highlight strips, click to select"
    bl_icon = "palette_grid.strip_picker"
    bl_cursor = 'DEFAULT'
    bl_keymap = (
        ("palette_grid.strip_pie",
         {"type": 'RIGHTMOUSE', "value": 'PRESS'}, None),
        ("palette_grid.overlay_copy_strip",
         {"type": 'C', "value": 'PRESS', "ctrl": True}, None),
        ("palette_grid.overlay_paste_strip",
         {"type": 'V', "value": 'PRESS', "ctrl": True}, None),
    )

# -- Overlay copy/paste (only when Strip Picker tool is active) ---------

class PALETTE_OT_overlay_copy_strip(bpy.types.Operator):
    """Copy the hovered or selected strip from the Image Editor overlay"""
    bl_idname = "palette_grid.overlay_copy_strip"
    bl_label = "Copy Strip (Overlay)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if not _is_picker_active():
            return {'PASS_THROUGH'}
        state = _app_state_ref
        if state is None:
            return {'PASS_THROUGH'}
        palette = state.active_palette
        if palette is None:
            return {'PASS_THROUGH'}
        # Use hovered strip if available, else fall back to selected
        idx = _hover_strip_index if _hover_strip_index >= 0 else state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            return {'PASS_THROUGH'}
        from .strip_ops import _serialize_strip
        strip = palette.strips[idx]
        context.window_manager.clipboard = _serialize_strip(strip, palette.direction)
        self.report({'INFO'}, f"Copied '{strip.name}'")
        return {'FINISHED'}


class PALETTE_OT_overlay_paste_strip(bpy.types.Operator):
    """Paste a strip onto the hovered or selected strip in the Image Editor overlay"""
    bl_idname = "palette_grid.overlay_paste_strip"
    bl_label = "Paste Strip (Overlay)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if not _is_picker_active():
            return {'PASS_THROUGH'}
        state = _app_state_ref
        if state is None:
            return {'PASS_THROUGH'}
        palette = state.active_palette
        if palette is None:
            return {'PASS_THROUGH'}
        from .strip_ops import _deserialize_strip
        from .texture import update_strip as _update_strip
        clip = context.window_manager.clipboard or ""
        payload = _deserialize_strip(clip)
        if payload is None:
            return {'PASS_THROUGH'}
        strip, effective_direction = payload
        # Use hovered strip if available, else fall back to selected
        idx = _hover_strip_index if _hover_strip_index >= 0 else state.selected_strip_index
        if idx < 0 or idx >= len(palette.strips):
            return {'PASS_THROUGH'}
        target = palette.strips[idx]
        target_was_flat = (target.strip_type == StripType.FLAT)
        target.strip_type = strip.strip_type
        target.stops = list(strip.stops)
        if target_was_flat and strip.strip_type == StripType.GRADIENT:
            target.direction = strip.direction or effective_direction
        else:
            target.direction = strip.direction
        target.color_mode = strip.color_mode
        target.interpolation = strip.interpolation
        target.hue_interpolation = strip.hue_interpolation
        target.effects = dict(getattr(strip, 'effects', {}))
        _update_strip(palette, idx)
        state.notify()
        tag_redraw()
        self.report({'INFO'}, f"Pasted onto '{target.name}'")
        return {'FINISHED'}


# Register the same tool in every Image Editor mode
_TOOL_MODES = ('VIEW', 'UV', 'PAINT', 'MASK')
_tool_classes = []


# -- Keymap (drag stop � always active in Image Editor) --------------------

_keymaps = []


def _register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc is None:
        return
    km = kc.keymaps.new(name='Image Generic', space_type='IMAGE_EDITOR')
    # Strip picker: hover + click (operators check tool state internally)
    # Register pick BEFORE drag_stop so drag_stop has higher priority
    # (last registered = checked first in Blender's keymap system).
    kmi_pick = km.keymap_items.new(
        PALETTE_OT_strip_pick.bl_idname, 'LEFTMOUSE', 'PRESS')
    _keymaps.append((km, kmi_pick))
    kmi_hover = km.keymap_items.new(
        PALETTE_OT_strip_hover.bl_idname, 'MOUSEMOVE', 'ANY')
    _keymaps.append((km, kmi_hover))
    # Drag stop registered last ? highest priority for LEFTMOUSE
    kmi_drag = km.keymap_items.new(
        PALETTE_OT_drag_stop.bl_idname, 'LEFTMOUSE', 'PRESS')
    _keymaps.append((km, kmi_drag))
    # Right-click pie menu on selected strip
    kmi_pie = km.keymap_items.new(
        PALETTE_OT_strip_pie.bl_idname, 'RIGHTMOUSE', 'PRESS')
    _keymaps.append((km, kmi_pie))
    # Ctrl+C / Ctrl+V for strip copy/paste (operators check picker tool state)
    kmi_copy = km.keymap_items.new(
        PALETTE_OT_overlay_copy_strip.bl_idname, 'C', 'PRESS', ctrl=True)
    _keymaps.append((km, kmi_copy))
    kmi_paste = km.keymap_items.new(
        PALETTE_OT_overlay_paste_strip.bl_idname, 'V', 'PRESS', ctrl=True)
    _keymaps.append((km, kmi_paste))


def _unregister_keymap():
    for km, kmi in _keymaps:
        km.keymap_items.remove(kmi)
    _keymaps.clear()


# -- Public API ------------------------------------------------------------

def tag_redraw():
    """Force redraw of all Image Editor areas."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.tag_redraw()


def _tag_all_redraw():
    """Force redraw of Image Editor + all N-panel regions."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                for region in area.regions:
                    region.tag_redraw()


def _create_strip_icon():
    """Load pre-generated ``.dat`` icon for the Strip Picker workspace tool.

    Uses ``bpy.app.icons.new_triangles_from_file()`` exclusively.
    ``bpy.app.icons.new_triangles()`` is NOT used � it passes Python-managed
    memory that Blender's ``MEM_lockfree_freeN`` cannot free, causing
    EXCEPTION_ACCESS_VIOLATION on exit (see v1.0.1 bug #1).
    """
    dat_path = os.path.join(_ASSETS, "palettegridv2_tool.dat")
    if os.path.isfile(dat_path):
        return bpy.app.icons.new_triangles_from_file(dat_path)
    return None


def _inject_tool_icon(handle):
    """Pre-populate the module-level ``_icon_cache`` so our icon name resolves
    without needing a ``.dat`` file in the system icons directory."""
    from bl_ui import space_toolsystem_common
    space_toolsystem_common._icon_cache["palette_grid.strip_picker"] = handle


def _eject_tool_icon():
    """Remove our entry from the icon cache."""
    from bl_ui import space_toolsystem_common
    space_toolsystem_common._icon_cache.pop("palette_grid.strip_picker", None)


def register(app_state):
    """Start drawing the overlay + register operators, tool, and keymap.

    Idempotent � safe to call multiple times (e.g. after file load).
    On subsequent calls only the internal state reference is updated.
    """
    global _draw_handle, _app_state_ref, _custom_icon_handle
    _app_state_ref = app_state
    if _draw_handle is not None:
        # Already fully registered � just update state reference
        return
    _draw_handle = bpy.types.SpaceImageEditor.draw_handler_add(
        _draw_callback, (), 'WINDOW', 'POST_PIXEL')
    bpy.utils.register_class(PALETTE_OT_drag_stop)
    bpy.utils.register_class(PALETTE_OT_strip_hover)
    bpy.utils.register_class(PALETTE_OT_strip_pick)
    _uv_snap.register(app_state)
    _path_draw.register(app_state)
    bpy.utils.register_class(PALETTE_MT_strip_pie)
    bpy.utils.register_class(PALETTE_OT_strip_pie)
    bpy.utils.register_class(PALETTE_OT_overlay_copy_strip)
    bpy.utils.register_class(PALETTE_OT_overlay_paste_strip)
    # Custom tool icon � programmatic triangles + cache injection
    try:
        _custom_icon_handle = _create_strip_icon()
        if _custom_icon_handle is not None:
            _inject_tool_icon(_custom_icon_handle)
    except Exception as e:
        import traceback; traceback.print_exc()
        print(f"[PaletteGrid] Icon creation failed: {e}")
        _custom_icon_handle = None
    # Register tool for every Image Editor mode
    for mode in _TOOL_MODES:
        cls = type(
            f'PG_ToolStripPicker_{mode}',
            (PG_ToolStripPicker,),
            {'bl_context_mode': mode},
        )
        try:
            bpy.utils.register_tool(cls, separator=True)
            _tool_classes.append(cls)
        except Exception:
            pass
    _register_keymap()


def unregister():
    """Remove overlay, operators, tool, and keymap."""
    global _draw_handle, _app_state_ref, _hover_strip_index, _custom_icon_handle
    _hover_strip_index = -1
    _unregister_keymap()
    for cls in reversed(_tool_classes):
        try:
            bpy.utils.unregister_tool(cls)
        except RuntimeError:
            pass
    _tool_classes.clear()
    _uv_snap.unregister()
    _path_draw.unregister()
    for cls in (PALETTE_OT_overlay_paste_strip, PALETTE_OT_overlay_copy_strip,
                 PALETTE_OT_strip_pie, PALETTE_MT_strip_pie,
                 PALETTE_OT_strip_pick, PALETTE_OT_strip_hover, PALETTE_OT_drag_stop):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _eject_tool_icon()
    # NOTE: Do NOT call bpy.app.icons.release() � Blender's exit cleanup
    # (BKE_icons_free) handles file-loaded icons correctly via MEM_freeN.
    # Explicit release() is unnecessary and risks double-free on hot-reload.
    _custom_icon_handle = None
    if _draw_handle is not None:
        bpy.types.SpaceImageEditor.draw_handler_remove(_draw_handle, 'WINDOW')
        _draw_handle = None
    _app_state_ref = None
