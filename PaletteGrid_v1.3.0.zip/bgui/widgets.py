# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Widgets � Label, Button, Separator, ColorSwatch, Section, IconButton, Header, Toggle, PropertyRow, ScrollBox, TextInput, Slider, Dropdown, ColorPicker."""
from __future__ import annotations
from typing import Optional, Callable, List
import time
import colorsys
from .core import Widget, Style, Rect, Color, EdgeInsets, SizePolicy, WidgetState, Alignment, ui_scale


class UIImage:
    """Lightweight GPU-only image. Not stored in bpy.data.images."""
    __slots__ = ('gpu_texture', 'size')

    def __init__(self, gpu_texture, width: int, height: int):
        self.gpu_texture = gpu_texture
        self.size = (width, height)


_png_cache: dict = {}  # path ? UIImage


def load_ui_image(path: str, svg_size: int = 64, svg_color=None, svg_rotation: float = 0):
    """Load an image for UI rendering with correct color space (Non-Color).

    Transparently handles SVG files by rasterising them to a bitmap.
    *svg_color* � optional (r,g,b,a) override for SVG fill colors.
    *svg_rotation* � degrees to rotate the SVG around its center.
    """
    import bpy, os
    name = '.' + os.path.basename(path)

    # SVG: rasterise via our minimal rasteriser
    if path.lower().endswith('.svg'):
        from .svg import load_svg_as_image
        phys = max(int(svg_size * ui_scale()), svg_size)
        return load_svg_as_image(path, width=phys, height=phys,
                                 color=svg_color, rotation=svg_rotation)

    # PNG/other: load to GPU texture, bypass bpy.data.images
    if name in _png_cache:
        return _png_cache[name]
    if not os.path.isfile(path):
        return None
    import gpu
    img = bpy.data.images.load(path)
    try:
        img.colorspace_settings.name = 'Non-Color'
        w, h = img.size
        pixels = list(img.pixels)
    finally:
        bpy.data.images.remove(img)
    buf = gpu.types.Buffer('FLOAT', len(pixels), pixels)
    tex = gpu.types.GPUTexture((w, h), format='RGBA32F', data=buf)
    ui_img = UIImage(tex, w, h)
    _png_cache[name] = ui_img
    return ui_img


class Label(Widget):
    """Text display with automatic ellipsis truncation."""

    def __init__(self, text: str = "", **kwargs):
        super().__init__(**kwargs)
        self.text = text

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        w, _ = Renderer.measure_text(self.text, self.style.font_size,
                                     font_weight=self.style.font_weight)
        return w

    def _measure_content_height(self) -> float:
        from .renderer import Renderer
        # Use reference text "Og" for stable height (covers ascenders + descenders)
        _, h = Renderer.measure_text("Og", self.style.font_size,
                                     font_weight=self.style.font_weight)
        return max(h, self.style.font_size * ui_scale())

    def _truncate_with_ellipsis(self, text, max_width, font_size, font_weight):
        """Truncate text to fit within max_width, appending '...' if needed."""
        from .renderer import Renderer
        tw, _ = Renderer.measure_text(text, font_size, font_weight=font_weight)
        if tw <= max_width:
            return text
        ellipsis = "..."
        ew, _ = Renderer.measure_text(ellipsis, font_size, font_weight=font_weight)
        if max_width <= ew:
            return ellipsis
        # Binary search for the longest prefix that fits
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            cw, _ = Renderer.measure_text(text[:mid] + ellipsis, font_size, font_weight=font_weight)
            if cw <= max_width:
                lo = mid
            else:
                hi = mid - 1
        return text[:lo] + ellipsis if lo > 0 else ellipsis

    def _draw_content(self, renderer, style: Style):
        from .renderer import Renderer
        cr = self.content_rect
        display_text = self._truncate_with_ellipsis(
            self.text, cr.width, style.font_size, style.font_weight)
        tw, th = Renderer.measure_text(display_text, style.font_size,
                                       font_weight=style.font_weight)
        # Horizontal alignment
        x = cr.x
        if style.alignment == Alignment.CENTER:
            x = cr.x + (cr.width - tw) / 2
        elif style.alignment == Alignment.END:
            x = cr.right - tw
        # Use a stable reference height for vertical centering (avoids jitter
        # when text changes between strings with different ascenders/descenders)
        _, ref_h = Renderer.measure_text("Og", style.font_size,
                                         font_weight=style.font_weight)
        y = cr.y + (cr.height - ref_h) / 2
        renderer.draw_text(
            display_text, x, y,
            size=style.font_size,
            color=style.font_color,
            font_weight=style.font_weight,
            ref_height=ref_h,
        )


class Button(Widget):
    """Clickable button with text label."""

    def __init__(self, text: str = "", icon_image=None, icon_path: str = None,
                 icon_size: float = 16, icon_gap: float = 6, **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self._icon_image = icon_image
        self._icon_path = icon_path
        self._icon_loaded = icon_image is not None
        self._icon_size = icon_size
        self._icon_gap = icon_gap
        s = self.style
        if s.background_color is None:
            s.background_color = (0.3, 0.3, 0.35, 1.0)
        if s.padding is None:
            s.padding = EdgeInsets(8, 20, 8, 20)
        if s.border_radius == 0:
            s.border_radius = 8
        if s.font_weight == 'regular':
            s.font_weight = 'medium'
        if s.hover_style is None:
            s.hover_style = {'background_color': (0.38, 0.38, 0.42, 1.0)}
        if s.active_style is None:
            s.active_style = {'background_color': (0.25, 0.25, 0.30, 1.0)}

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        sc = ui_scale()
        w, _ = Renderer.measure_text(self.text, self.style.font_size,
                                     font_weight=self.style.font_weight)
        if self._icon_image:
            w += self._icon_size * sc + self._icon_gap * sc
        return w

    def _measure_content_height(self) -> float:
        from .renderer import Renderer
        sc = ui_scale()
        _, h = Renderer.measure_text(self.text, self.style.font_size,
                                     font_weight=self.style.font_weight)
        return max(h, self.style.font_size * sc,
                   self._icon_size * sc if self._icon_image else 0)

    def _draw_content(self, renderer, style: Style):
        from .renderer import Renderer
        from .core import Rect as _Rect
        if not self._icon_loaded and self._icon_path:
            self._icon_loaded = True
            self._icon_image = load_ui_image(self._icon_path)
        cr = self.content_rect
        renderer.push_clip(cr)
        sc = ui_scale()
        tw, th = Renderer.measure_text(self.text, style.font_size,
                                       font_weight=style.font_weight)
        icon_sz = self._icon_size * sc
        icon_gap = self._icon_gap * sc
        total_w = tw
        if self._icon_image:
            total_w += icon_sz + icon_gap
        x = cr.x + (cr.width - total_w) / 2
        if self._icon_image:
            iy = cr.y + (cr.height - icon_sz) / 2
            renderer.draw_image(self._icon_image, _Rect(x, iy, icon_sz, icon_sz))
            x += icon_sz + icon_gap
        y = cr.y + (cr.height - th) / 2
        renderer.draw_text(self.text, x, y, size=style.font_size, color=style.font_color,
                           font_weight=style.font_weight)
        renderer.pop_clip()


class Separator(Widget):
    """Thin line separator � fills available cross-axis width.

    Can render a solid color line or an image (PNG) stretched to fill width.
    """

    def __init__(self, thickness: float = 1.0,
                 color: Color = (0.5, 0.5, 0.5, 0.5),
                 image_path: Optional[str] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.sep_color = color
        self._image_path = image_path
        self._image = None
        self._image_loaded = False
        self.style.height = thickness
        self.style.width_policy = SizePolicy.FILL

    @staticmethod
    def _load_image(path: str):
        return load_ui_image(path)

    def _measure_content_height(self) -> float:
        return self.style.height or 1.0

    def _draw_content(self, renderer, style: Style):
        if not self._image_loaded and self._image_path:
            self._image_loaded = True
            self._image = self._load_image(self._image_path)
            if self._image and self.style.height <= 1.0:
                self.style.height = self._image.size[1]
        if self._image:
            renderer.draw_image(self._image, self.rect)
        else:
            renderer.draw_rect(self.rect, self.sep_color)


class ColorSwatch(Widget):
    """Colored square � for palette display."""

    def __init__(self, color: Color = (1, 1, 1, 1), size: float = 24, **kwargs):
        super().__init__(**kwargs)
        self.swatch_color = color
        if self.style.width is None:
            self.style.width = size
        if self.style.height is None:
            self.style.height = size
        if self.style.border_radius == 0:
            self.style.border_radius = 3

    def _draw_background(self, renderer, style: Style):
        pass

    def _draw_content(self, renderer, style: Style):
        sc = ui_scale()
        hovered = self.state in (WidgetState.HOVERED, WidgetState.PRESSED)
        bc = (0.9, 0.9, 0.9, 0.8) if hovered else (0.3, 0.3, 0.3, 0.4)
        bw = (2.0 if hovered else 1.0) * sc
        renderer.draw_rounded_rect(
            self.rect, self.swatch_color, style.border_radius * sc,
            border_color=bc, border_width=bw,
        )


# -- Native UILayout Widgets ---------------------------------


class Section(Widget):
    """Collapsible box section � renders as box() with optional expand/collapse.

    In native mode: draws a box with a collapsible header row.
    In GPU mode: draws a header bar with expand/collapse arrow + children.
    The 'expanded' state controls whether children are drawn.
    """

    def __init__(self, title: str = "", expanded: bool = True,
                 icon: str = "", **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.expanded = expanded
        self.section_icon = icon
        self.style.use_box = True

    def toggle(self):
        self.expanded = not self.expanded

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        arrow = "?" if self.expanded else "?"
        renderer.draw_text(arrow, cr.x, cr.y, size=12,
                           color=(0.6, 0.6, 0.65, 1.0))
        renderer.draw_text(self.title, cr.x + 16 * sc, cr.y, size=style.font_size,
                           color=style.font_color)

    def _draw_children(self, renderer):
        if not self.expanded:
            return
        super()._draw_children(renderer)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        # Click on header area (first ~24dp) toggles expand
        if y < self.rect.y + 24 * ui_scale():
            self.toggle()
            return True
        return super().handle_mouse_press(x, y)

    def measure_height(self) -> float:
        sc = ui_scale()
        header_h = max(24.0, self.style.font_size + 10) * sc
        if not self.expanded:
            return header_h
        children_h = sum(c.measure_height() for c in self.children if c.visible)
        gaps = max(0, len([c for c in self.children if c.visible]) - 1) * self.style.gap * sc
        pad = (self.style.padding.vertical * sc) if self.style.padding else 0
        return header_h + children_h + gaps + pad


class IconButton(Widget):
    """Button that shows only a Blender icon � emboss=False for clean look.

    Uses built-in Blender icons (e.g., 'ADD', 'REMOVE', 'X', 'FILE_REFRESH').
    """

    def __init__(self, icon: str = "NONE", text: str = "",
                 on_click: Optional[Callable] = None, **kwargs):
        if 'style' not in kwargs:
            kwargs['style'] = Style(emboss=False)
        elif not hasattr(kwargs['style'], 'emboss') or kwargs['style'].emboss:
            kwargs['style'].emboss = False
        super().__init__(on_click=on_click, **kwargs)
        self.text = text
        self.style.icon = icon


class Header(Widget):
    """Section header with title and optional right-side action buttons.

    Renders as a row with left-aligned label and right-aligned children.
    """

    def __init__(self, title: str = "", icon: str = "", **kwargs):
        super().__init__(**kwargs)
        self.title = title
        self.header_icon = icon

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        w, _ = Renderer.measure_text(self.title, self.style.font_size)
        return w

    def _measure_content_height(self) -> float:
        return max(self.style.font_size + 4, 20.0) * ui_scale()

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        renderer.draw_text(self.title, cr.x, cr.y, size=style.font_size,
                           color=style.font_color)


class Toggle(Widget):
    """Boolean toggle / checkbox widget.

    In native mode: renders as a prop() boolean or a checkmark icon button.
    In GPU mode: renders a checkbox indicator with label.
    """

    def __init__(self, label: str = "", checked: bool = False,
                 on_change: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.label = label
        self.checked = checked
        self.on_change = on_change
        s = self.style
        if s.height is None:
            s.height = 22

    def toggle(self):
        self.checked = not self.checked
        if self.on_change:
            self.on_change(self)

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        w, _ = Renderer.measure_text(self.label, self.style.font_size)
        return w + 22 * ui_scale()  # checkbox + gap

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        # Checkbox box
        box_size = 14 * sc
        box_y = cr.y + (cr.height - box_size) / 2
        box_rect = Rect(cr.x, box_y, box_size, box_size)
        if self.checked:
            renderer.draw_rounded_rect(
                box_rect, (0.33, 0.55, 0.95, 1.0), 3 * sc,
                border_color=(0.33, 0.55, 0.95, 0.8), border_width=1 * sc)
            renderer.draw_text("?", cr.x + 2 * sc, box_y + 1 * sc, size=11,
                               color=(1, 1, 1, 1))
        else:
            renderer.draw_rounded_rect(
                box_rect, (0.2, 0.2, 0.24, 1.0), 3 * sc,
                border_color=(0.4, 0.4, 0.44, 0.6), border_width=1 * sc)
        # Label
        renderer.draw_text(self.label, cr.x + 20 * sc, cr.y + 2 * sc,
                           size=style.font_size, color=style.font_color)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        self.toggle()
        self.state = WidgetState.PRESSED
        return True


class ToggleSwitch(Widget):
    """iOS/Material-style sliding toggle switch.

    Renders a pill-shaped track with a sliding circular thumb.
    Animates smoothly between states using the Tween system.

    Usage::

        ToggleSwitch(checked=True,
                     active_color=(0.784, 1.0, 0.0, 1.0),
                     on_change=lambda w: print(w.checked))
    """

    def __init__(self, checked: bool = False,
                 active_color: Optional[Color] = None,
                 inactive_color: Optional[Color] = None,
                 thumb_color: Optional[Color] = None,
                 on_change: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.checked = checked
        self.active_color = active_color or (0.784, 1.0, 0.0, 1.0)
        self.inactive_color = inactive_color or (0.30, 0.30, 0.34, 1.0)
        self.thumb_color = thumb_color or (1.0, 1.0, 1.0, 1.0)
        self.on_change = on_change

        # Animation state: 0.0 = off, 1.0 = on
        self._thumb_t = 1.0 if checked else 0.0
        self._track_color = self.active_color if checked else self.inactive_color

        s = self.style
        if s.width is None:
            s.width = 40
        if s.height is None:
            s.height = 22

    def toggle(self):
        self.checked = not self.checked
        from .animation import Tween, ease_out_cubic
        target_t = 1.0 if self.checked else 0.0
        Tween(self, '_thumb_t', self._thumb_t, target_t,
              duration=0.2, ease=ease_out_cubic)
        target_color = self.active_color if self.checked else self.inactive_color
        Tween(self, '_track_color', self._track_color, target_color,
              duration=0.2, ease=ease_out_cubic, is_color=True)
        if self.on_change:
            self.on_change(self)

    def _measure_content_width(self) -> float:
        return self.style.width or 40

    def _measure_content_height(self) -> float:
        return self.style.height or 22

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        w = cr.width
        h = cr.height
        radius = h / 2

        # Track
        track_rect = Rect(cr.x, cr.y, w, h)
        renderer.draw_rounded_rect(track_rect, self._track_color, radius)

        # Thumb � interpolate position based on _thumb_t
        thumb_r = (h - 4 * sc) / 2
        thumb_cy = cr.y + h / 2
        off_cx = cr.x + thumb_r + 3 * sc
        on_cx = cr.x + w - thumb_r - 3 * sc
        thumb_cx = off_cx + (on_cx - off_cx) * self._thumb_t

        thumb_rect = Rect(thumb_cx - thumb_r, thumb_cy - thumb_r,
                          thumb_r * 2, thumb_r * 2)
        renderer.draw_rounded_rect(thumb_rect, self.thumb_color, thumb_r)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        self.toggle()
        self.state = WidgetState.PRESSED
        return True


class RadioGroup(Widget):
    """Horizontal row of radio buttons � only one can be selected at a time.

    Usage::

        RadioGroup(
            options=["Linear", "Ease", "Cubic"],
            selected="Linear",
            active_color=(0.784, 1.0, 0.0, 1.0),
            on_change=lambda w: print(w.selected),
        )
    """

    def __init__(self, options: Optional[list] = None,
                 selected: Optional[str] = None,
                 active_color: Optional[Color] = None,
                 inactive_color: Optional[Color] = None,
                 gap: float = 16.0,
                 on_change: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.options = options or []
        self.selected = selected or (self.options[0] if self.options else None)
        self.active_color = active_color or (0.784, 1.0, 0.0, 1.0)
        self.inactive_color = inactive_color or (0.35, 0.35, 0.39, 1.0)
        self.gap = gap
        self.on_change = on_change

        # Per-option fill factor stored as _rf_<index> attributes for Tween compat
        for i, opt in enumerate(self.options):
            setattr(self, f'_rf_{i}', 1.0 if opt == self.selected else 0.0)

        s = self.style
        if s.height is None:
            s.height = 22

    def _get_fill(self, idx: int) -> float:
        return getattr(self, f'_rf_{idx}', 0.0)

    def select(self, option: str):
        if option == self.selected or option not in self.options:
            return
        from .animation import Tween, ease_out_cubic
        old_idx = self.options.index(self.selected) if self.selected else -1
        new_idx = self.options.index(option)
        # Animate old out
        if old_idx >= 0:
            Tween(self, f'_rf_{old_idx}', self._get_fill(old_idx), 0.0,
                  duration=0.15, ease=ease_out_cubic)
        # Animate new in
        Tween(self, f'_rf_{new_idx}', self._get_fill(new_idx), 1.0,
              duration=0.15, ease=ease_out_cubic)
        self.selected = option
        if self.on_change:
            self.on_change(self)

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        sc = ui_scale()
        total = 0.0
        outer = 16 * sc
        for i, opt in enumerate(self.options):
            tw, _ = Renderer.measure_text(opt, self.style.font_size)
            total += outer + 6 * sc + tw
            if i < len(self.options) - 1:
                total += self.gap * sc
        return total

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        outer_d = 16 * sc
        outer_r = outer_d / 2
        inner_r = 4.5 * sc
        cx = cr.x
        cy = cr.y + cr.height / 2

        for i, opt in enumerate(self.options):
            # Outer ring
            ring_rect = Rect(cx, cy - outer_r, outer_d, outer_d)
            is_sel = opt == self.selected
            ring_color = self.active_color if is_sel else self.inactive_color
            renderer.draw_rounded_rect(
                ring_rect, (0, 0, 0, 0), outer_r,
                border_color=ring_color, border_width=1.5 * sc)

            # Inner filled dot (animated)
            fill_t = self._get_fill(i)
            if fill_t > 0.01:
                r = inner_r * fill_t
                dot_rect = Rect(cx + outer_r - r, cy - r, r * 2, r * 2)
                renderer.draw_rounded_rect(dot_rect, self.active_color, r)

            # Label
            text_x = cx + outer_d + 6 * sc
            tw, _ = renderer.measure_text(opt, style.font_size)
            text_y = cr.y + (cr.height - style.font_size * sc) / 2
            renderer.draw_text(opt, text_x, text_y,
                               size=style.font_size, color=style.font_color)
            cx += outer_d + 6 * sc + tw + self.gap * sc

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        from .renderer import Renderer
        sc = ui_scale()
        cr = self.content_rect
        outer_d = 16 * sc
        cx = cr.x
        for opt in self.options:
            tw, _ = Renderer.measure_text(opt, self.style.font_size)
            item_w = outer_d + 6 * sc + tw
            if x < cx + item_w + self.gap * sc / 2:
                self.select(opt)
                return True
            cx += item_w + self.gap * sc
        return True


class SegmentedControl(Widget):
    """Horizontal segmented pill control � like iOS UISegmentedControl.

    Equal-width segments inside a rounded container, selected segment
    highlighted with an animated sliding indicator.

    Usage::

        SegmentedControl(
            options=["512", "1K", "2K", "4K"],
            selected="1K",
            active_color=(0.784, 1.0, 0.0, 1.0),
            on_change=lambda w: print(w.selected),
        )
    """

    def __init__(self, options: Optional[list] = None,
                 selected: Optional[str] = None,
                 active_color: Optional[Color] = None,
                 active_text_color: Optional[Color] = None,
                 inactive_color: Optional[Color] = None,
                 inactive_text_color: Optional[Color] = None,
                 divider_color: Optional[Color] = None,
                 icons: Optional[list] = None,
                 icon_size: int = 14,
                 on_change: Optional[Callable] = None, **kwargs):
        kw_style = kwargs.get('style') or Style()
        if kw_style.height is None:
            kw_style.height = 26
        if kw_style.border_radius is None or kw_style.border_radius == 0:
            kw_style.border_radius = 5
        kwargs['style'] = kw_style
        super().__init__(**kwargs)
        self.options = options or []
        self.selected = selected or (self.options[0] if self.options else None)
        self.active_color = active_color or (0.784, 1.0, 0.0, 1.0)
        self.active_text_color = active_text_color or (0.137, 0.153, 0.102, 1.0)
        self.inactive_color = inactive_color or (0.302, 0.302, 0.341, 1.0)
        self.inactive_text_color = inactive_text_color or (1.0, 1.0, 1.0, 1.0)
        self.divider_color = divider_color or (0.381, 0.381, 0.426, 1.0)
        self.icons = icons  # list of SVG file paths, one per option
        self.icon_size = icon_size
        self.on_change = on_change
        # Animated selection position (index as float for sliding)
        sel_idx = self.options.index(self.selected) if self.selected in self.options else 0
        self._sel_pos = float(sel_idx)

    def select(self, option: str):
        if option == self.selected or option not in self.options:
            return
        from .animation import Tween, ease_out_cubic
        new_idx = self.options.index(option)
        Tween(self, '_sel_pos', self._sel_pos, float(new_idx),
              duration=0.18, ease=ease_out_cubic)
        self.selected = option
        if self.on_change:
            self.on_change(self)

    def deselect(self):
        """Clear the selection � no segment is highlighted."""
        self.selected = None
        self._sel_pos = -1.0

    def _measure_content_width(self) -> float:
        # Default: 30dp per segment
        sc = ui_scale()
        return max(len(self.options) * 30, 60) * sc

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        n = len(self.options)
        if n == 0:
            return
        sc = ui_scale()
        seg_w = cr.width / n
        h = cr.height
        radius = style.border_radius * sc if style.border_radius else 5 * sc

        # Draw inactive background (full pill)
        renderer.draw_rounded_rect(
            Rect(cr.x, cr.y, cr.width, h),
            self.inactive_color, radius)

        # Draw selected segment highlight (animated position)
        if self.selected is not None and self._sel_pos >= 0:
            sel_x = cr.x + self._sel_pos * seg_w
            # Compute corner radius for the selected segment
            sel_rect = Rect(sel_x, cr.y, seg_w, h)
            renderer.draw_rounded_rect(sel_rect, self.active_color, radius)

        # Draw divider lines between unselected segments
        divider_h = h * 0.69  # ~18px of 26px
        divider_y = cr.y + (h - divider_h) / 2
        for i in range(1, n):
            # Skip dividers adjacent to the selected segment
            sel_i = round(self._sel_pos)
            if i == sel_i or i == sel_i + 1:
                continue
            dx = cr.x + i * seg_w - 0.5
            renderer.draw_rect(
                Rect(dx, divider_y, 1, divider_h),
                self.divider_color)

        # Draw text labels or icons
        font_size = style.font_size or 12
        for i, opt in enumerate(self.options):
            # Interpolate color based on proximity to selection
            dist = abs(i - self._sel_pos)
            if dist < 1.0:
                t = 1.0 - dist
                color = tuple(
                    self.active_text_color[c] * t + self.inactive_text_color[c] * (1 - t)
                    for c in range(4))
            else:
                color = self.inactive_text_color

            if self.icons and i < len(self.icons):
                # Draw icon � use discrete color (active/inactive) to keep cache small
                is_active = round(self._sel_pos) == i
                icon_color = self.active_text_color if is_active else self.inactive_text_color
                icon_entry = self.icons[i]
                if isinstance(icon_entry, tuple):
                    icon_path, icon_rot = icon_entry
                else:
                    icon_path, icon_rot = icon_entry, 0
                icon_img = load_ui_image(icon_path, svg_size=self.icon_size * 2,
                                         svg_color=icon_color, svg_rotation=icon_rot)
                if icon_img:
                    isz = self.icon_size * sc
                    ix = cr.x + i * seg_w + (seg_w - isz) / 2
                    iy = cr.y + (h - isz) / 2
                    renderer.draw_image(icon_img, Rect(ix, iy, isz, isz))
            else:
                # Draw text
                tw, th = renderer.measure_text(opt, font_size, font_weight='semibold')
                tx = cr.x + i * seg_w + (seg_w - tw) / 2
                ty = cr.y + (h - font_size * sc) / 2
                renderer.draw_text(opt, tx, ty, size=font_size,
                                   color=color, font_weight='semibold')

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        cr = self.content_rect
        n = len(self.options)
        if n == 0:
            return True
        seg_w = cr.width / n
        idx = int((x - cr.x) / seg_w)
        idx = max(0, min(idx, n - 1))
        self.select(self.options[idx])
        return True


class PropertyRow(Widget):
    """A row showing label + value, like Blender's property panel rows.

    In native mode: renders as row with label text and prop/operator.
    In GPU mode: renders label on left, value on right.
    """

    def __init__(self, label: str = "", value: str = "",
                 icon: str = "", icon_value: int = 0, **kwargs):
        super().__init__(**kwargs)
        self.label = label
        self.value = value
        self.style.icon = icon
        self.style.icon_value = icon_value

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        lw, _ = Renderer.measure_text(self.label, self.style.font_size)
        vw, _ = Renderer.measure_text(self.value, self.style.font_size)
        return lw + vw + 8 * ui_scale()

    def _measure_content_height(self) -> float:
        return max(self.style.font_size + 4, 20.0) * ui_scale()

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        renderer.draw_text(self.label, cr.x, cr.y, size=style.font_size,
                           color=style.font_color)
        if self.value:
            from .renderer import Renderer
            vw, _ = Renderer.measure_text(self.value, style.font_size)
            renderer.draw_text(self.value, cr.right - vw, cr.y,
                               size=style.font_size,
                               color=(0.6, 0.6, 0.65, 1.0))


class ImagePreview(Widget):
    """Large image preview using template_icon().

    Supply a preview icon_id (from bpy.utils.previews or image.preview.icon_id).
    """

    def __init__(self, icon_id: int = 0, scale: float = 5.0, **kwargs):
        super().__init__(**kwargs)
        self.preview_icon_id = icon_id
        self.preview_scale = scale


# -- Scroll Container -----------------------------------------


class ScrollBox(Widget):
    """Scrollable container that clips children and supports mouse wheel.

    Set a fixed height, and children that overflow vertically will be
    accessible via scrolling. Clips children to its bounds.

    Usage::

        ScrollBox(style=Style(height=200, clip_children=True), children=[
            Column(children=[...])
        ])
    """

    def __init__(self, scroll_speed: float = 20.0,
                 on_scroll: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.scroll_offset: float = 0.0
        self.scroll_speed = scroll_speed
        self.on_scroll = on_scroll
        self._sb_dragging: bool = False
        self._sb_drag_offset: float = 0.0
        # Ensure clipping is on
        self.style.clip_children = True

    @property
    def _content_height(self) -> float:
        """Total height of all children."""
        if not self.children:
            return 0
        visible = [c for c in self.children if c.visible]
        sc = ui_scale()
        return sum(c.measure_height() for c in visible) + \
            max(0, len(visible) - 1) * self.style.gap * sc

    def _measure_content_width(self) -> float:
        visible = [c for c in self.children if c.visible]
        return max((c.measure_width() for c in visible), default=0)

    def _measure_content_height(self) -> float:
        return self._content_height

    @property
    def _max_scroll(self) -> float:
        overflow = self._content_height - self.rect.height
        return max(0, overflow)

    def scroll_by(self, delta: float):
        """Scroll by delta pixels. Positive = down."""
        old = self.scroll_offset
        self.scroll_offset = max(0, min(self._max_scroll,
                                        self.scroll_offset + delta))
        if self.scroll_offset != old and self.on_scroll:
            self.on_scroll(self)

    def handle_scroll(self, delta: float, x: float, y: float) -> bool:
        """Handle mouse wheel. Returns True if consumed."""
        if not self.rect.contains(x, y):
            return False
        self.scroll_by(delta * self.scroll_speed * ui_scale())
        return True  # Always consume when mouse is over scrollable area

    def _layout_children(self):
        """Layout children in a vertical stack, offset by scroll."""
        visible = [c for c in self.children if c.visible]
        if not visible:
            return
        cr = self.content_rect
        sc = ui_scale()
        gap = self.style.gap * sc
        scrollbar_reserve = 8 * sc if self._max_scroll > 0 else 0
        child_w = max(0, cr.width - scrollbar_reserve)
        y = cr.y - self.scroll_offset
        for child in visible:
            h = child.measure_height()
            child.layout(Rect(cr.x, y, child_w, h))
            y += h + gap

    def draw(self, renderer):
        """Override to draw scrollbar after children (on top)."""
        if not self.visible:
            return
        import copy
        eff = self.style.get_effective(self.state)
        if self._transitions:
            eff = copy.copy(eff)
            self._apply_transitions(eff)
        self._draw_background(renderer, eff)
        # Re-position children for current scroll offset every frame
        self._layout_children()
        self._draw_children(renderer)
        self._draw_scrollbar(renderer)

    def _draw_scrollbar(self, renderer):
        max_scroll = self._max_scroll
        if max_scroll <= 0:
            return
        sc = ui_scale()
        track_h = self.rect.height
        thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
        thumb_y = self.rect.y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
        thumb_x = self.rect.right - 4 * sc
        thumb_rect = Rect(thumb_x, thumb_y, 3 * sc, thumb_h)
        renderer.draw_rounded_rect(
            thumb_rect, (1, 1, 1, 0.2), 1.5 * sc)

    def _scrollbar_geometry(self):
        """Return (track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w) or None."""
        max_scroll = self._max_scroll
        if max_scroll <= 0:
            return None
        sc = ui_scale()
        track_y = self.rect.y
        track_h = self.rect.height
        if track_h <= 0:
            return None
        thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
        thumb_y = track_y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
        thumb_x = self.rect.right - 4 * sc
        thumb_w = 3 * sc
        return track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        # Check scrollbar thumb drag
        sb = self._scrollbar_geometry()
        if sb is not None:
            track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w = sb
            hit_margin = 4 * ui_scale()
            if (thumb_x - hit_margin <= x <= thumb_x + thumb_w + hit_margin
                    and thumb_y <= y <= thumb_y + thumb_h):
                self._sb_dragging = True
                self._sb_drag_offset = y - thumb_y
                return True
        return super().handle_mouse_press(x, y)

    def handle_mouse_release(self, x: float, y: float) -> bool:
        if self._sb_dragging:
            self._sb_dragging = False
            return True
        return super().handle_mouse_release(x, y)

    def propagate_mouse_move(self, x: float, y: float):
        if self._sb_dragging:
            sb = self._scrollbar_geometry()
            if sb is not None:
                track_y, track_h, _thumb_y, thumb_h, _thumb_x, _thumb_w = sb
                max_scroll = self._max_scroll
                new_thumb_y = y - self._sb_drag_offset
                ratio = ((new_thumb_y - track_y) / (track_h - thumb_h)
                         if track_h > thumb_h else 0)
                ratio = max(0.0, min(1.0, ratio))
                old = self.scroll_offset
                self.scroll_offset = ratio * max_scroll
                if self.scroll_offset != old and self.on_scroll:
                    self.on_scroll(self)
            return
        super().propagate_mouse_move(x, y)


# -- Text Input -----------------------------------------------


class TextInput(Widget):
    """Editable text input field with cursor, selection, and clipboard.

    Handles keyboard events when focused. Must be used with a modal
    operator that forwards key events via handle_key_event().

    Usage::

        inp = TextInput(placeholder="Type here...",
                        on_change=lambda w: print(w.text))
    """

    _focused_instance: 'TextInput | None' = None

    def __init__(self, text: str = "", placeholder: str = "",
                 on_change: Optional[Callable] = None,
                 on_submit: Optional[Callable] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self.placeholder = placeholder
        self.on_change = on_change
        self.on_submit = on_submit
        self.cursor_pos: int = len(text)
        self.selection_start: Optional[int] = None
        self.focused: bool = False
        self._cursor_visible: bool = True
        self._cursor_blink_time: float = 0.0
        self._blink_rate: float = 0.53
        self._mouse_dragging: bool = False

        s = self.style
        if s.background_color is None:
            s.background_color = (0.122, 0.114, 0.102, 1.0)  # #1F1D1A
        if s.padding is None:
            s.padding = EdgeInsets(5, 20, 5, 8)
        if s.border_radius == 0:
            s.border_radius = 8
        if s.height is None:
            s.height = 34
        if s.font_weight == 'regular':
            s.font_weight = 'semibold'
        if s.font_size == 14.0:
            s.font_size = 17
        if s.border_color is None:
            s.border_color = (0.227, 0.227, 0.251, 1.0)  # #3A3A40
            s.border_width = 1
        if s.inner_shadow_color is None:
            s.inner_shadow_color = (0.0, 0.0, 0.0, 0.25)
            s.inner_shadow_blur = 10.7

    def focus(self):
        # Blur the previously focused TextInput (if any)
        prev = TextInput._focused_instance
        if prev is not None and prev is not self:
            prev.blur()
        TextInput._focused_instance = self
        self.focused = True
        self._cursor_blink_time = time.time()
        self._cursor_visible = True

    def blur(self):
        if TextInput._focused_instance is self:
            TextInput._focused_instance = None
        self.focused = False
        self.selection_start = None

    def _notify_change(self):
        if self.on_change:
            self.on_change(self)

    def _get_selected_range(self):
        if self.selection_start is None:
            return None, None
        return min(self.cursor_pos, self.selection_start), \
            max(self.cursor_pos, self.selection_start)

    def _delete_selection(self):
        s, e = self._get_selected_range()
        if s is None:
            return False
        self.text = self.text[:s] + self.text[e:]
        self.cursor_pos = s
        self.selection_start = None
        return True

    def insert_text(self, chars: str):
        self._delete_selection()
        self.text = self.text[:self.cursor_pos] + chars + self.text[self.cursor_pos:]
        self.cursor_pos += len(chars)
        self._notify_change()

    def handle_key_event(self, key: str, shift: bool = False,
                         ctrl: bool = False, ascii_char: str = "") -> bool:
        """Process a keyboard event. Returns True if consumed."""
        if not self.focused:
            return False

        if key == 'BACK_SPACE':
            if not self._delete_selection():
                if self.cursor_pos > 0:
                    self.text = self.text[:self.cursor_pos - 1] + self.text[self.cursor_pos:]
                    self.cursor_pos -= 1
            self._notify_change()
            return True

        if key == 'DEL':
            if not self._delete_selection():
                if self.cursor_pos < len(self.text):
                    self.text = self.text[:self.cursor_pos] + self.text[self.cursor_pos + 1:]
            self._notify_change()
            return True

        if key == 'LEFT_ARROW':
            if shift:
                if self.selection_start is None:
                    self.selection_start = self.cursor_pos
            else:
                if self.selection_start is not None:
                    self.cursor_pos = min(self.cursor_pos, self.selection_start)
                    self.selection_start = None
                    return True
            if self.cursor_pos > 0:
                self.cursor_pos -= 1
            if not shift:
                self.selection_start = None
            return True

        if key == 'RIGHT_ARROW':
            if shift:
                if self.selection_start is None:
                    self.selection_start = self.cursor_pos
            else:
                if self.selection_start is not None:
                    self.cursor_pos = max(self.cursor_pos, self.selection_start)
                    self.selection_start = None
                    return True
            if self.cursor_pos < len(self.text):
                self.cursor_pos += 1
            if not shift:
                self.selection_start = None
            return True

        if key == 'HOME':
            if shift and self.selection_start is None:
                self.selection_start = self.cursor_pos
            self.cursor_pos = 0
            if not shift:
                self.selection_start = None
            return True

        if key == 'END':
            if shift and self.selection_start is None:
                self.selection_start = self.cursor_pos
            self.cursor_pos = len(self.text)
            if not shift:
                self.selection_start = None
            return True

        if ctrl and key == 'A':
            self.selection_start = 0
            self.cursor_pos = len(self.text)
            return True

        if ctrl and key == 'C':
            s, e = self._get_selected_range()
            if s is not None:
                return True  # caller should set clipboard
            return False

        if ctrl and key == 'X':
            s, e = self._get_selected_range()
            if s is not None:
                self._delete_selection()
                self._notify_change()
                return True
            return False

        if ctrl and key == 'V':
            return True  # caller should call insert_text with clipboard

        if key == 'RET':
            if self.on_submit:
                self.on_submit(self)
            return True

        if key == 'ESC':
            self.blur()
            return True

        if ascii_char and not ctrl and not (key in ('RET', 'ESC')):
            self.insert_text(ascii_char)
            return True

        return False

    def get_selection_text(self) -> str:
        s, e = self._get_selected_range()
        if s is not None:
            return self.text[s:e]
        return ""

    def _measure_content_width(self) -> float:
        from .renderer import Renderer
        display = self.text or self.placeholder
        w, _ = Renderer.measure_text(display, self.style.font_size)
        return max(w, 60)

    def _measure_content_height(self) -> float:
        return self.style.font_size * ui_scale()

    def _draw_background(self, renderer, style: Style):
        import copy
        if self.focused:
            style = copy.copy(style)
            style.border_color = (0.784, 1.0, 0.0, 0.8)
            style.border_width = max(style.border_width, 1.5)
        super()._draw_background(renderer, style)

    def _draw_content(self, renderer, style: Style):
        from .renderer import Renderer
        cr = self.content_rect
        display = self.text or self.placeholder
        fc = style.font_color if self.text else (
            0.50, 0.50, 0.50, 1.0
        )

        _, th = Renderer.measure_text(display, style.font_size,
                                      font_weight=style.font_weight)
        text_y = cr.y + (cr.height - th) / 2

        # Selection highlight
        if self.focused and self.selection_start is not None:
            s, e = self._get_selected_range()
            before_w, _ = Renderer.measure_text(self.text[:s], style.font_size,
                                                font_weight=style.font_weight)
            sel_w, _ = Renderer.measure_text(self.text[s:e], style.font_size,
                                             font_weight=style.font_weight)
            sel_rect = Rect(cr.x + before_w, cr.y, sel_w, cr.height)
            renderer.draw_rect(sel_rect, (0.3, 0.5, 0.8, 0.3))

        renderer.draw_text(display, cr.x, text_y, size=style.font_size,
                           color=fc, clip_rect=self.rect,
                           font_weight=style.font_weight)

        # Cursor
        if self.focused:
            now = time.time()
            if now - self._cursor_blink_time > self._blink_rate:
                self._cursor_visible = not self._cursor_visible
                self._cursor_blink_time = now
            if self._cursor_visible:
                text_before = self.text[:self.cursor_pos]
                cw, _ = Renderer.measure_text(text_before, style.font_size,
                                              font_weight=style.font_weight)
                cursor_rect = Rect(cr.x + cw, cr.y, 2 * ui_scale(), cr.height)
                renderer.draw_rect(cursor_rect, style.font_color)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible:
            return False
        if self.rect.contains(x, y):
            self.focus()
            # Place cursor near click position
            from .renderer import Renderer
            rel_x = x - self.content_rect.x
            best_pos = 0
            best_dist = abs(rel_x)
            for i in range(1, len(self.text) + 1):
                w, _ = Renderer.measure_text(self.text[:i], self.style.font_size)
                d = abs(rel_x - w)
                if d < best_dist:
                    best_dist = d
                    best_pos = i
            self.cursor_pos = best_pos
            self.selection_start = best_pos
            self._mouse_dragging = True
            self.state = WidgetState.PRESSED
            return True
        elif self.focused:
            self.blur()
        return False

    def handle_mouse_release(self, x: float, y: float) -> bool:
        if self._mouse_dragging:
            self._mouse_dragging = False
            inside = self.rect.contains(x, y)
            self.state = WidgetState.HOVERED if inside else WidgetState.NORMAL
            self._animate_state_change()
            # Clear selection if nothing was actually selected
            if self.selection_start == self.cursor_pos:
                self.selection_start = None
            return True
        return super().handle_mouse_release(x, y)

    def propagate_mouse_move(self, x: float, y: float):
        if self._mouse_dragging and self.focused:
            from .renderer import Renderer
            rel_x = x - self.content_rect.x
            best_pos = 0
            best_dist = abs(rel_x)
            for i in range(1, len(self.text) + 1):
                w, _ = Renderer.measure_text(self.text[:i], self.style.font_size)
                d = abs(rel_x - w)
                if d < best_dist:
                    best_dist = d
                    best_pos = i
            self.cursor_pos = best_pos
            return
        super().propagate_mouse_move(x, y)


# -- Slider ---------------------------------------------------


class Slider(Widget):
    """Modern draggable slider with rounded track and circular thumb.

    Supports float range with optional step snapping.
    Handles click-to-set and drag interaction.

    Usage::

        Slider(value=0.5, min_val=0, max_val=1,
               active_color=(0.784, 1.0, 0.0, 1.0),
               on_change=lambda w: print(w.value))
    """

    def __init__(self, value: float = 0.0, min_val: float = 0.0,
                 max_val: float = 1.0, step: float = 0.0,
                 label: str = "", suffix: str = "",
                 precision: int = 2,
                 active_color: Optional[Color] = None,
                 track_color: Optional[Color] = None,
                 thumb_color: Optional[Color] = None,
                 track_height: float = 6,
                 thumb_radius: float = 9,
                 on_change: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.value = max(min_val, min(max_val, value))
        self.min_val = min_val
        self.max_val = max_val
        self.step = step
        self.label = label
        self.suffix = suffix
        self.precision = precision
        self.active_color = active_color or (0.784, 1.0, 0.0, 1.0)
        self.track_color = track_color or (0.25, 0.25, 0.28, 1.0)
        self.thumb_color = thumb_color or (1.0, 1.0, 1.0, 1.0)
        self.track_height = track_height
        self.thumb_radius = thumb_radius
        self.on_change = on_change
        self._dragging = False
        self._bub_dims = None  # cached (bub_w, bub_h, tw_ref, th_ref)

        s = self.style
        if s.padding is None:
            s.padding = EdgeInsets(0, 0, 0, 0)
        if s.height is None:
            s.height = max(24, int(thumb_radius * 2 + 4))

    @property
    def _normalized(self) -> float:
        rng = self.max_val - self.min_val
        if rng == 0:
            return 0.0
        return (self.value - self.min_val) / rng

    def _set_from_x(self, x: float):
        """Set value from an x coordinate within the slider rect."""
        cr = self.content_rect
        pad = self.thumb_radius * ui_scale()
        usable = cr.width - pad * 2
        t = max(0.0, min(1.0, (x - cr.x - pad) / max(1, usable)))
        raw = self.min_val + t * (self.max_val - self.min_val)
        if self.step > 0:
            raw = round(raw / self.step) * self.step
        old = self.value
        self.value = max(self.min_val, min(self.max_val, raw))
        if self.value != old and self.on_change:
            self.on_change(self)

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        th = self.track_height * sc
        tr = th / 2  # track corner radius
        pad = self.thumb_radius * sc
        usable = cr.width - pad * 2

        track_y = cr.y + (cr.height - th) / 2
        norm = self._normalized
        thumb_cx = cr.x + pad + usable * norm

        # Inactive track (full width)
        full_track = Rect(cr.x + pad, track_y, usable, th)
        renderer.draw_rounded_rect(full_track, self.track_color, tr)

        # Active track (filled portion)
        fill_w = usable * norm
        if fill_w > 0:
            fill_track = Rect(cr.x + pad, track_y, fill_w, th)
            renderer.draw_rounded_rect(fill_track, self.active_color, tr)

        # Thumb circle
        thumb_r = self.thumb_radius * sc
        thumb_cy = cr.y + cr.height / 2
        thumb_rect = Rect(thumb_cx - thumb_r,
                          thumb_cy - thumb_r,
                          thumb_r * 2,
                          thumb_r * 2)
        renderer.draw_rounded_rect(thumb_rect, self.thumb_color, thumb_r)

        # Value tooltip bubble (shown while dragging)
        if self._dragging:
            display = f"{self.value:.{self.precision}f}{self.suffix}"
            from .renderer import Renderer
            fs = style.font_size or 12
            # Cache bubble dimensions once for stability
            if self._bub_dims is None:
                ref = f"{0:.{self.precision}f}{self.suffix}"
                max_digits = len(f"{int(self.max_val)}")
                ref = "0" * max_digits + ref[1:]
                tw_ref, th_ref = Renderer.measure_text(ref, fs)
                bub_pad_x = 10 * sc
                bub_pad_y = 5 * sc
                bub_w = max(tw_ref + bub_pad_x * 2, 36 * sc)
                bub_h = th_ref + bub_pad_y * 2
                self._bub_dims = (bub_w, bub_h, tw_ref, th_ref)
            bub_w, bub_h, tw_ref, th_ref = self._bub_dims
            bub_x = thumb_cx - bub_w / 2
            arrow_h = 5 * sc
            bub_y = thumb_cy - thumb_r - arrow_h - bub_h - 2 * sc
            bub_rect = Rect(bub_x, bub_y, bub_w, bub_h)
            renderer.draw_rounded_rect(bub_rect, self.active_color, 6 * sc)
            # Arrow triangle pointing down
            renderer.draw_triangle(
                thumb_cx - 5 * sc, bub_y + bub_h,
                thumb_cx + 5 * sc, bub_y + bub_h,
                thumb_cx, bub_y + bub_h + arrow_h,
                self.active_color)
            # Value text centered in bubble (use ref dims for stable position)
            text_x = bub_x + (bub_w - tw_ref) / 2
            text_y = bub_y + (bub_h - th_ref) / 2
            renderer.draw_text(display, text_x, text_y,
                               size=fs,
                               color=(0.0, 0.0, 0.0, 1.0),
                               font_weight='regular')

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible:
            return False
        if self.rect.contains(x, y):
            self._dragging = True
            self._set_from_x(x)
            self.state = WidgetState.PRESSED
            return True
        return False

    def handle_mouse_release(self, x: float, y: float) -> bool:
        if self._dragging:
            self._dragging = False
            self._bub_dims = None
            self.state = WidgetState.HOVERED if self.rect.contains(x, y) else WidgetState.NORMAL
            return True
        return False

    def propagate_mouse_move(self, x: float, y: float):
        super().propagate_mouse_move(x, y)
        if self._dragging:
            self._set_from_x(x)


# -- Dropdown -------------------------------------------------


class Dropdown(Widget):
    """Dropdown selector. Shows current value and expands to a list on click.

    The dropdown "opens" by drawing the options list over other content.
    Since we don't have z-ordering, the open list is drawn in-place below the trigger.

    Usage::

        Dropdown(options=["Red", "Green", "Blue"], selected=0,
                 on_change=lambda w: print(w.options[w.selected]))
    """

    def __init__(self, options: Optional[List[str]] = None,
                 selected: int = 0,
                 placeholder: str = "Select...",
                 on_change: Optional[Callable] = None,
                 highlight_color: Optional[Color] = None,
                 columns: int = 1,
                 column_width: Optional[float] = None,
                 max_visible_rows: int = 0,
                 **kwargs):
        super().__init__(**kwargs)
        self.options = options or []
        self.selected = selected
        self.placeholder = placeholder
        self.on_change = on_change
        self.highlight_color = highlight_color or (0.33, 0.55, 0.95, 0.3)
        self.columns = max(1, columns)
        self.column_width = column_width
        self.max_visible_rows = max_visible_rows
        self.open = False
        self._hover_index = -1
        self._scroll_row = 0

        s = self.style
        if s.background_color is None:
            s.background_color = (0.102, 0.102, 0.102, 1.0)  # #1A1A1A
        if s.padding is None:
            s.padding = EdgeInsets(5, 20, 5, 8)
        if s.border_radius == 0:
            s.border_radius = 8
        if s.height is None:
            s.height = 34
        if s.font_weight == 'regular':
            s.font_weight = 'semibold'
        if s.font_size == 14.0:
            s.font_size = 17
        if s.border_color is None:
            s.border_color = (0.106, 0.106, 0.106, 1.0)  # #1B1B1B
            s.border_width = 1.5
        if s.hover_style is None:
            s.hover_style = {'background_color': (0.16, 0.16, 0.18, 1.0)}

    @property
    def selected_text(self) -> str:
        if 0 <= self.selected < len(self.options):
            return self.options[self.selected]
        return self.placeholder

    def _option_height(self) -> float:
        return max(20.0, (self.style.font_size or 12) + 6) * ui_scale()

    def _grid_rows(self) -> int:
        """Number of rows when using multi-column layout."""
        import math
        return math.ceil(len(self.options) / self.columns)

    def _dropdown_width(self) -> float:
        """Total width of the dropdown list."""
        if self.columns <= 1:
            return self.rect.width
        sc = ui_scale()
        if self.column_width:
            return self.column_width * self.columns * sc
        # Auto-calculate from longest option text
        from .renderer import Renderer
        fs = self.style.font_size or 12
        fw = self.style.font_weight
        max_w = 0.0
        for opt in self.options:
            w, _ = Renderer.measure_text(opt, fs, font_weight=fw)
            if w > max_w:
                max_w = w
        self._auto_col_w = max_w + 20 * sc  # 8dp left pad + 12dp right margin
        return self._auto_col_w * self.columns

    def _dropdown_x(self) -> float:
        """X origin of the dropdown list (anchored right for multi-col)."""
        if self.columns <= 1:
            return self.rect.x
        # Anchor right edge to trigger's right edge, clamp to viewport
        return max(0.0, self.rect.right - self._dropdown_width())

    def _dropdown_height(self) -> float:
        return self._visible_rows() * self._option_height()

    def _visible_rows(self) -> int:
        """Number of rows visible (capped by max_visible_rows)."""
        total = self._grid_rows()
        if self.max_visible_rows > 0:
            return min(total, self.max_visible_rows)
        return total

    def measure_height(self) -> float:
        # Don't inflate height when open � dropdown list is drawn as overlay
        return super().measure_height()

    def _draw_content(self, renderer, style: Style):
        from .renderer import Renderer
        cr = self.content_rect
        sc = ui_scale()
        fs = style.font_size or 12
        fw = style.font_weight

        # Current value � vertically centered
        display = self.selected_text
        _, th = Renderer.measure_text(display, fs, font_weight=fw)
        text_y = cr.y + (cr.height - th) / 2
        renderer.draw_text(display, cr.x, text_y, size=fs,
                           color=style.font_color, font_weight=fw)

        # Down arrow indicator � drawn as geometric triangle, vertically centered
        tri_size = fs * 0.55 * sc
        tri_x = cr.right - tri_size - 2 * sc
        tri_cy = cr.y + cr.height / 2
        if self.open:
            # Up arrow
            renderer.draw_triangle(
                tri_x, tri_cy + tri_size * 0.3,
                tri_x + tri_size, tri_cy + tri_size * 0.3,
                tri_x + tri_size / 2, tri_cy - tri_size * 0.3,
                color=(0.6, 0.6, 0.65, 1.0),
            )
        else:
            # Down arrow
            renderer.draw_triangle(
                tri_x, tri_cy - tri_size * 0.3,
                tri_x + tri_size, tri_cy - tri_size * 0.3,
                tri_x + tri_size / 2, tri_cy + tri_size * 0.3,
                color=(0.6, 0.6, 0.65, 1.0),
            )

    def _draw_children(self, renderer):
        if not self.open:
            return
        # Schedule overlay to draw on top of everything
        sc = ui_scale()
        dd_x = self._dropdown_x()
        r_y = self.rect.y
        trigger_h = (self.style.height or 26) * sc
        opts = list(self.options)
        sel = self.selected
        hover = self._hover_index
        opt_h = self._option_height()
        n_cols = self.columns
        vis_rows = self._visible_rows()
        total_rows = self._grid_rows()
        total_w = self._dropdown_width()
        total_h = vis_rows * opt_h
        hi_color = self.highlight_color
        hi_sel = (hi_color[0], hi_color[1], hi_color[2], hi_color[3] * 0.5)
        dd_fs = self.style.font_size or 12
        dd_fw = self.style.font_weight
        dd_fc = self.style.font_color or (0.9, 0.9, 0.92, 1.0)
        col_w = total_w / n_cols
        scroll_row = self._scroll_row
        can_scroll = total_rows > vis_rows

        def _draw_dropdown_overlay(rdr):
            list_y = r_y + trigger_h + 2 * sc
            list_rect = Rect(dd_x, list_y, total_w, total_h)
            rdr.draw_rounded_rect(
                list_rect, (0.18, 0.18, 0.22, 0.98), 4 * sc,
                border_color=(0.35, 0.35, 0.40, 0.5), border_width=1 * sc,
            )
            # Draw only visible rows
            for vr in range(vis_rows):
                data_row = vr + scroll_row
                for vc in range(n_cols):
                    idx = data_row * n_cols + vc
                    if idx >= len(opts):
                        break
                    opt = opts[idx]
                    ox = dd_x + vc * col_w
                    oy = list_y + vr * opt_h
                    opt_rect = Rect(ox + 1 * sc, oy, col_w - 2 * sc, opt_h)
                    if idx == hover:
                        rdr.draw_rounded_rect(opt_rect, hi_color, 3 * sc)
                    elif idx == sel:
                        rdr.draw_rounded_rect(opt_rect, hi_sel, 3 * sc)
                    rdr.draw_text(opt, ox + 8 * sc, oy + (opt_h - dd_fs * sc) / 2,
                                  size=dd_fs, color=dd_fc, font_weight=dd_fw)
            # Scrollbar indicator
            if can_scroll:
                sb_w = 3 * sc
                sb_x = dd_x + total_w - sb_w - 2 * sc
                track_h = total_h - 4 * sc
                thumb_h = max(12.0 * sc, track_h * vis_rows / total_rows)
                max_scroll = total_rows - vis_rows
                thumb_y = list_y + 2 * sc + (track_h - thumb_h) * (scroll_row / max_scroll) if max_scroll > 0 else list_y + 2 * sc
                rdr.draw_rounded_rect(
                    Rect(sb_x, thumb_y, sb_w, thumb_h),
                    (0.5, 0.5, 0.55, 0.4), 2 * sc,
                )

        renderer.add_overlay(_draw_dropdown_overlay)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible:
            return False

        sc = ui_scale()
        # Click on trigger area
        trigger_rect = Rect(self.rect.x, self.rect.y, self.rect.width,
                            (self.style.height or 26) * sc)
        if trigger_rect.contains(x, y):
            self.open = not self.open
            if self.open:
                self._scroll_row = 0
            self.state = WidgetState.PRESSED
            return True

        # Click on opened option list
        if self.open:
            r = self.rect
            dd_x = self._dropdown_x()
            opt_h = self._option_height()
            list_y = r.y + (self.style.height or 26) * sc + 2 * sc
            total_w = self._dropdown_width()
            list_rect = Rect(dd_x, list_y, total_w, self._dropdown_height())
            if list_rect.contains(x, y):
                col_w = total_w / self.columns
                c = int((x - dd_x) / col_w)
                vis_row = int((y - list_y) / opt_h)
                data_row = vis_row + self._scroll_row
                idx = data_row * self.columns + c
                if 0 <= idx < len(self.options):
                    old = self.selected
                    self.selected = idx
                    self.open = False
                    if self.selected != old and self.on_change:
                        self.on_change(self)
                return True
            # Click outside � close
            self.open = False

        return False

    def propagate_mouse_move(self, x: float, y: float):
        super().propagate_mouse_move(x, y)
        if self.open:
            sc = ui_scale()
            r = self.rect
            dd_x = self._dropdown_x()
            opt_h = self._option_height()
            list_y = r.y + (self.style.height or 26) * sc + 2 * sc
            total_w = self._dropdown_width()
            if dd_x <= x < dd_x + total_w and list_y <= y < list_y + self._dropdown_height():
                col_w = total_w / self.columns
                c = int((x - dd_x) / col_w)
                vis_row = int((y - list_y) / opt_h)
                data_row = vis_row + self._scroll_row
                idx = data_row * self.columns + c
                self._hover_index = idx if 0 <= idx < len(self.options) else -1
            else:
                self._hover_index = -1

    def hit_test(self, x, y):
        if not self.visible:
            return None
        if self.rect.contains(x, y):
            return self
        # If open, the dropdown list extends below (and may be wider for multi-col)
        if self.open:
            sc = ui_scale()
            r = self.rect
            dd_x = self._dropdown_x()
            list_y = r.y + (self.style.height or 26) * sc + 2 * sc
            total_w = self._dropdown_width()
            list_rect = Rect(dd_x, list_y, total_w, self._dropdown_height())
            if list_rect.contains(x, y):
                return self
        return None

    def handle_scroll(self, delta: float, x: float, y: float) -> bool:
        if not self.open:
            return False
        sc = ui_scale()
        r = self.rect
        dd_x = self._dropdown_x()
        list_y = r.y + (self.style.height or 26) * sc + 2 * sc
        total_w = self._dropdown_width()
        list_rect = Rect(dd_x, list_y, total_w, self._dropdown_height())
        if not list_rect.contains(x, y):
            return False
        max_scroll = max(0, self._grid_rows() - self._visible_rows())
        self._scroll_row = max(0, min(max_scroll, self._scroll_row + int(delta)))
        return True


# -- ColorPicker ----------------------------------------------


class ColorPicker(Widget):
    """HSV color picker with saturation/value square and hue strip.

    Displays a SV gradient square (for saturation and value) with a
    vertical hue strip beside it. Click/drag to pick colors.

    Usage::

        ColorPicker(color=(1.0, 0.0, 0.0, 1.0),
                    on_change=lambda w: print(w.color))
    """

    def __init__(self, color: Color = (1.0, 0.0, 0.0, 1.0),
                 on_change: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.color = color
        self.on_change = on_change
        r, g, b = color[0], color[1], color[2]
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        self._hue = h
        self._sat = s
        self._val = v
        self._dragging_sv = False
        self._dragging_hue = False
        self._hue_strip_width = 16
        self._gap = 6

        s = self.style
        if s.width is None:
            s.width = 180
        if s.height is None:
            s.height = 160
        if s.border_radius == 0:
            s.border_radius = 6
        if s.padding is None:
            s.padding = EdgeInsets.all(6)

    def _update_color(self):
        r, g, b = colorsys.hsv_to_rgb(self._hue, self._sat, self._val)
        self.color = (r, g, b, self.color[3])
        if self.on_change:
            self.on_change(self)

    def _sv_rect(self) -> Rect:
        """The saturation/value square area."""
        cr = self.content_rect
        sc = ui_scale()
        sw = cr.width - self._hue_strip_width * sc - self._gap * sc
        return Rect(cr.x, cr.y, sw, cr.height)

    def _hue_rect(self) -> Rect:
        """The vertical hue strip area."""
        cr = self.content_rect
        sc = ui_scale()
        hw = self._hue_strip_width * sc
        hx = cr.right - hw
        return Rect(hx, cr.y, hw, cr.height)

    def _draw_content(self, renderer, style: Style):
        sv = self._sv_rect()
        hr = self._hue_rect()

        # -- SV Square: draw as gradient strips --
        # Vertical strips from left (S=0) to right (S=1)
        # Each strip is a vertical gradient from V=1 (top) to V=0 (bottom)
        strips = max(8, int(sv.width / 4))
        strip_w = sv.width / strips
        for i in range(strips):
            s = i / max(1, strips - 1)
            # Top color: HSV(hue, s, 1.0 )
            r1, g1, b1 = colorsys.hsv_to_rgb(self._hue, s, 1.0)
            # Bottom color: HSV(hue, s, 0.0)
            r2, g2, b2 = colorsys.hsv_to_rgb(self._hue, s, 0.0)
            strip_rect = Rect(sv.x + i * strip_w, sv.y, strip_w + 1, sv.height)
            renderer.draw_rounded_rect(
                strip_rect, (r1, g1, b1, 1.0), 0,
                color2=(r2, g2, b2, 1.0), gradient_angle=180.0,
            )

        # SV cursor (crosshair)
        cx = sv.x + self._sat * sv.width
        cy = sv.y + (1.0 - self._val) * sv.height
        sc = ui_scale()
        cursor_size = 8 * sc
        # Outer circle (dark for contrast)
        renderer.draw_rounded_rect(
            Rect(cx - cursor_size / 2, cy - cursor_size / 2,
                 cursor_size, cursor_size),
            (0, 0, 0, 0), cursor_size / 2,
            border_color=(0, 0, 0, 0.7), border_width=2 * sc,
        )
        # Inner circle (white)
        inner = cursor_size - 3 * sc
        renderer.draw_rounded_rect(
            Rect(cx - inner / 2, cy - inner / 2, inner, inner),
            (0, 0, 0, 0), inner / 2,
            border_color=(1, 1, 1, 0.9), border_width=1.5 * sc,
        )

        # -- Hue Strip: vertical rainbow --
        hue_steps = max(6, int(hr.height / 6))
        step_h = hr.height / hue_steps
        for i in range(hue_steps):
            h1 = i / hue_steps
            h2 = (i + 1) / hue_steps
            r1, g1, b1 = colorsys.hsv_to_rgb(h1, 1.0, 1.0)
            r2, g2, b2 = colorsys.hsv_to_rgb(h2, 1.0, 1.0)
            seg = Rect(hr.x, hr.y + i * step_h, hr.width, step_h + 1)
            renderer.draw_rounded_rect(
                seg, (r1, g1, b1, 1.0), 0,
                color2=(r2, g2, b2, 1.0), gradient_angle=180.0,
            )

        # Hue indicator
        hy = hr.y + self._hue * hr.height
        renderer.draw_rounded_rect(
            Rect(hr.x - 1 * sc, hy - 2 * sc, hr.width + 2 * sc, 4 * sc),
            (0, 0, 0, 0), 2 * sc,
            border_color=(1, 1, 1, 0.9), border_width=1.5 * sc,
        )

        # -- Color preview (small swatch at bottom-left) --
        preview_sz = 16 * sc
        preview = Rect(sv.x, sv.bottom - preview_sz, preview_sz, preview_sz)
        renderer.draw_rounded_rect(
            preview, self.color, 3 * sc,
            border_color=(0.5, 0.5, 0.5, 0.4), border_width=1 * sc,
        )

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False

        sv = self._sv_rect()
        hr = self._hue_rect()

        if sv.contains(x, y):
            self._dragging_sv = True
            self._sat = max(0, min(1, (x - sv.x) / max(1, sv.width)))
            self._val = max(0, min(1, 1.0 - (y - sv.y) / max(1, sv.height)))
            self._update_color()
            self.state = WidgetState.PRESSED
            return True

        if hr.contains(x, y):
            self._dragging_hue = True
            self._hue = max(0, min(1, (y - hr.y) / max(1, hr.height)))
            self._update_color()
            self.state = WidgetState.PRESSED
            return True

        return True

    def handle_mouse_release(self, x: float, y: float) -> bool:
        if self._dragging_sv or self._dragging_hue:
            self._dragging_sv = False
            self._dragging_hue = False
            self.state = WidgetState.HOVERED if self.rect.contains(x, y) else WidgetState.NORMAL
            return True
        return False

    def propagate_mouse_move(self, x: float, y: float):
        super().propagate_mouse_move(x, y)
        if self._dragging_sv:
            sv = self._sv_rect()
            self._sat = max(0, min(1, (x - sv.x) / max(1, sv.width)))
            self._val = max(0, min(1, 1.0 - (y - sv.y) / max(1, sv.height)))
            self._update_color()
        elif self._dragging_hue:
            hr = self._hue_rect()
            self._hue = max(0, min(1, (y - hr.y) / max(1, hr.height)))
            self._update_color()


# -- Context Menu ---------------------------------------------


class ContextMenu(Widget):
    """Right-click context menu with items, separators, and sub-menus.

    Renders as an overlay for z-ordering. Items can have labels, icons,
    and callbacks. Separators divide groups of items.

    Usage::

        menu = ContextMenu(items=[
            {"label": "Copy", "callback": copy_fn},
            {"label": "---"},  # separator
            {"label": "Paste", "callback": paste_fn},
            {"label": "Delete", "callback": delete_fn, "color": (0.85, 0.3, 0.3, 1)},
        ])
        menu.show(x, y)
    """

    def __init__(self, items: Optional[List[dict]] = None,
                 on_dismiss: Optional[Callable] = None, **kwargs):
        super().__init__(**kwargs)
        self.items = items or []
        self.on_dismiss = on_dismiss
        self.open = False
        self._menu_x: float = 0
        self._menu_y: float = 0
        self._hover_index: int = -1
        self._item_height: float = 26.0
        self._separator_height: float = 8.0
        self._menu_width: float = 160.0
        self._padding: float = 4.0

    def show(self, x: float, y: float):
        """Open the context menu at the given position."""
        self.open = True
        self._menu_x = x
        self._menu_y = y
        self._hover_index = -1
        # Compute menu width from longest label
        from .renderer import Renderer
        sc = ui_scale()
        max_w = 100.0 * sc
        for item in self.items:
            label = item.get("label", "")
            if label and label != "---":
                tw, _ = Renderer.measure_text(label, 12)
                max_w = max(max_w, tw + 24 * sc)
        self._menu_width = max_w + self._padding * sc * 2

    def dismiss(self):
        """Close the context menu."""
        self.open = False
        self._hover_index = -1
        if self.on_dismiss:
            self.on_dismiss(self)

    def _menu_height(self) -> float:
        sc = ui_scale()
        h = self._padding * sc * 2
        for item in self.items:
            if item.get("label") == "---":
                h += self._separator_height * sc
            else:
                h += self._item_height * sc
        return h

    def _menu_rect(self):
        return Rect(self._menu_x, self._menu_y,
                    self._menu_width, self._menu_height())

    def _draw_children(self, renderer):
        if not self.open:
            return
        _sc = ui_scale()
        mx, my = self._menu_x, self._menu_y
        w = self._menu_width
        items = list(self.items)
        hover = self._hover_index
        pad = self._padding
        item_h = self._item_height
        sep_h = self._separator_height
        total_h = self._menu_height()

        def _draw_menu_overlay(rdr):
            menu_rect = Rect(mx, my, w, total_h)
            # Shadow
            rdr.draw_shadow(menu_rect, (0, 0, 0, 0.35), 8.0 * _sc, (0, 2 * _sc), radius=6 * _sc)
            # Background
            rdr.draw_rounded_rect(
                menu_rect, (0.18, 0.18, 0.22, 0.98), 6 * _sc,
                border_color=(0.35, 0.35, 0.40, 0.5), border_width=1 * _sc,
            )
            # Items
            cy = my + pad * _sc
            for i, item in enumerate(items):
                label = item.get("label", "")
                if label == "---":
                    # Separator
                    sep_y = cy + sep_h * _sc / 2
                    rdr.draw_rect(
                        Rect(mx + 8 * _sc, sep_y, w - 16 * _sc, 1 * _sc),
                        (0.35, 0.35, 0.40, 0.3))
                    cy += sep_h * _sc
                else:
                    opt_rect = Rect(mx + 2 * _sc, cy, w - 4 * _sc, item_h * _sc)
                    if i == hover:
                        rdr.draw_rounded_rect(
                            opt_rect, (0.33, 0.55, 0.95, 0.25), 4 * _sc)
                    color = item.get("color", (0.90, 0.90, 0.92, 1.0))
                    rdr.draw_text(label, mx + 12 * _sc, cy + 5 * _sc, size=12, color=color)
                    cy += item_h * _sc

        renderer.add_overlay(_draw_menu_overlay)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.open:
            return False
        mr = self._menu_rect()
        if not mr.contains(x, y):
            self.dismiss()
            return True
        # Find which item was clicked
        sc = ui_scale()
        cy = self._menu_y + self._padding * sc
        for i, item in enumerate(self.items):
            label = item.get("label", "")
            if label == "---":
                cy += self._separator_height * sc
                continue
            if cy <= y < cy + self._item_height * sc:
                callback = item.get("callback")
                if callback:
                    callback()
                self.dismiss()
                return True
            cy += self._item_height * sc
        return True

    def propagate_mouse_move(self, x: float, y: float):
        if not self.open:
            return
        mr = self._menu_rect()
        if not mr.contains(x, y):
            self._hover_index = -1
            return
        sc = ui_scale()
        cy = self._menu_y + self._padding * sc
        for i, item in enumerate(self.items):
            label = item.get("label", "")
            if label == "---":
                cy += self._separator_height * sc
                continue
            if cy <= y < cy + self._item_height * sc:
                self._hover_index = i
                return
            cy += self._item_height * sc
        self._hover_index = -1

    def hit_test(self, x, y):
        if self.open:
            mr = self._menu_rect()
            if mr.contains(x, y):
                return self
        return None


# -- Image Widget ---------------------------------------------


class ImageWidget(Widget):
    """Display a Blender image (bpy.types.Image) using GPU texture rendering.

    Usage::

        import bpy
        img = bpy.data.images.load("/path/to/image.png")
        ImageWidget(image=img, style=Style(width=200, height=150, border_radius=6))
    """

    def __init__(self, image=None, fit: str = 'cover',
                 opacity: float = 1.0, **kwargs):
        super().__init__(**kwargs)
        self.image = image  # bpy.types.Image
        self.fit = fit  # 'cover', 'contain', 'fill'
        self.image_opacity = opacity

    def _measure_content_width(self) -> float:
        if self.image:
            return self.image.size[0]
        return 0

    def _measure_content_height(self) -> float:
        if self.image:
            return self.image.size[1]
        return 0

    def _draw_content(self, renderer, style):
        if not self.image:
            return
        renderer.draw_image(self.image, self.content_rect,
                            opacity=self.image_opacity,
                            border_radius=style.border_radius)


# -- ListView -------------------------------------------------


class ListView(Widget):
    """Scrollable list with selectable items.

    Each item is a dict with at minimum a 'label' key. Supports single
    and multi-select modes.

    Usage::

        ListView(items=[
            {"label": "Item 1", "icon": "FILE"},
            {"label": "Item 2"},
        ], on_select=lambda w, idx: print(idx))
    """

    def __init__(self, items: Optional[List[dict]] = None,
                 selected: int = -1,
                 multi_select: bool = False,
                 item_height: float = 28.0,
                 on_select: Optional[Callable] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.items = items or []
        self.selected = selected
        self.selected_indices: List[int] = [selected] if selected >= 0 else []
        self.multi_select = multi_select
        self.item_height = item_height
        self.on_select = on_select
        self.scroll_offset: float = 0.0
        self._hover_index: int = -1

        s = self.style
        if s.background_color is None:
            s.background_color = (0.15, 0.15, 0.18, 1.0)
        if s.border_radius == 0:
            s.border_radius = 5
        if s.border_color is None:
            s.border_color = (0.30, 0.30, 0.34, 0.5)
            s.border_width = 1
        s.clip_children = True

    @property
    def _content_height(self) -> float:
        return len(self.items) * self.item_height * ui_scale()

    @property
    def _max_scroll(self) -> float:
        return max(0, self._content_height - self.rect.height)

    def handle_scroll(self, delta: float, x: float, y: float) -> bool:
        if not self.rect.contains(x, y):
            return False
        old = self.scroll_offset
        self.scroll_offset = max(0, min(self._max_scroll,
                                        self.scroll_offset + delta * 20))
        return True  # Always consume to prevent viewport zoom

    def _draw_content(self, renderer, style):
        cr = self.content_rect
        sc = ui_scale()
        ih = self.item_height * sc
        renderer.push_clip(self.rect)
        for i, item in enumerate(self.items):
            iy = cr.y + i * ih - self.scroll_offset
            if iy + ih < cr.y or iy > cr.bottom:
                continue  # Off screen
            item_rect = Rect(cr.x + 2 * sc, iy, cr.width - 4 * sc, ih)

            # Selection / hover highlight
            is_selected = i in self.selected_indices
            if is_selected:
                renderer.draw_rounded_rect(
                    item_rect, (0.33, 0.55, 0.95, 0.25), 4 * sc)
            elif i == self._hover_index:
                renderer.draw_rounded_rect(
                    item_rect, (0.33, 0.55, 0.95, 0.12), 4 * sc)

            # Label
            label = item.get("label", "")
            color = (0.95, 0.95, 0.97, 1.0) if is_selected else (0.85, 0.85, 0.88, 1.0)
            renderer.draw_text(label, cr.x + 10 * sc, iy + 6 * sc, size=12, color=color)

        # Scrollbar thumb
        max_scroll = self._max_scroll
        if max_scroll > 0:
            track_h = self.rect.height
            thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
            thumb_y = self.rect.y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
            thumb_rect = Rect(self.rect.right - 4 * sc, thumb_y, 3 * sc, thumb_h)
            renderer.draw_rounded_rect(thumb_rect, (1, 1, 1, 0.15), 1.5 * sc)
        renderer.pop_clip()

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        cr = self.content_rect
        ih = self.item_height * ui_scale()
        idx = int((y - cr.y + self.scroll_offset) / ih)
        if 0 <= idx < len(self.items):
            if self.multi_select:
                if idx in self.selected_indices:
                    self.selected_indices.remove(idx)
                else:
                    self.selected_indices.append(idx)
            else:
                self.selected = idx
                self.selected_indices = [idx]
            if self.on_select:
                self.on_select(self, idx)
        self.state = WidgetState.PRESSED
        return True

    def propagate_mouse_move(self, x: float, y: float):
        super().propagate_mouse_move(x, y)
        if self.rect.contains(x, y):
            cr = self.content_rect
            ih = self.item_height * ui_scale()
            idx = int((y - cr.y + self.scroll_offset) / ih)
            self._hover_index = idx if 0 <= idx < len(self.items) else -1
        else:
            self._hover_index = -1


# -- DataList -------------------------------------------------


class DataList(Widget):
    """Scrollable list container with icon + name items.

    Supports Blender data collections (materials, shape keys, vertex groups,
    images, etc.) and custom item lists. Renders icons from bpy.types.Image
    objects, file paths, or built-in Blender icon names.

    Usage with custom items::

        DataList(items=[
            {"name": "Base Color", "icon": "MATERIAL"},
            {"name": "Glossy", "icon": "/path/to/icon.png"},
        ], on_select=lambda w, idx: print(idx))

    Usage with Blender data::

        DataList.from_collection(bpy.context.object.data.materials,
                                 icon="MATERIAL",
                                 on_select=my_callback)
    """

    # Default Blender icon names for known data types
    _TYPE_ICONS = {
        'Material':     'MATERIAL',
        'Image':        'IMAGE_DATA',
        'ShapeKey':     'SHAPEKEY_DATA',
        'VertexGroup':  'GROUP_VERTEX',
        'Modifier':     'MODIFIER',
        'Constraint':   'CONSTRAINT',
        'ParticleSystem': 'PARTICLES',
        'Object':       'OBJECT_DATA',
        'Mesh':         'MESH_DATA',
        'Armature':     'ARMATURE_DATA',
        'Action':       'ACTION',
        'NodeTree':     'NODETREE',
        'Collection':   'OUTLINER_COLLECTION',
        'Scene':        'SCENE_DATA',
        'World':        'WORLD_DATA',
        'Texture':      'TEXTURE_DATA',
        'Camera':       'CAMERA_DATA',
        'Light':        'LIGHT_DATA',
    }

    def __init__(self, items: Optional[List[dict]] = None,
                 selected: int = -1,
                 item_height: float = 30.0,
                 icon_size: float = 18.0,
                 active_color: Optional[Color] = None,
                 hover_color: Optional[Color] = None,
                 on_select: Optional[Callable] = None,
                 on_double_click: Optional[Callable] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.items: List[dict] = items or []
        self.selected = selected
        self.item_height = item_height
        self.icon_size = icon_size
        self.active_color = active_color or (0.784, 1.0, 0.0, 1.0)
        self.hover_color = hover_color or (1.0, 1.0, 1.0, 0.06)
        self.on_select = on_select
        self.on_double_click = on_double_click
        self.scroll_offset: float = 0.0
        self._scroll_target: float = 0.0
        self._hover_index: int = -1
        self._last_click_time: float = 0.0
        self._last_click_index: int = -1
        self._icon_cache: dict = {}
        self._sb_dragging: bool = False
        self._sb_drag_offset: float = 0.0  # mouse Y offset from thumb top

        s = self.style
        if s.background_color is None:
            s.background_color = (0.13, 0.13, 0.15, 1.0)
        if s.border_radius == 0:
            s.border_radius = 6
        if s.border_color is None:
            s.border_color = (0.25, 0.25, 0.28, 0.5)
            s.border_width = 1
        if s.font_weight == 'regular':
            s.font_weight = 'medium'
        s.clip_children = True

    @classmethod
    def from_collection(cls, collection, icon: str = None,
                        name_attr: str = 'name', **kwargs) -> 'DataList':
        """Create a DataList from a Blender data collection.

        Args:
            collection: A Blender collection (e.g. obj.data.materials)
            icon: Override icon � file path, or None to use Blender preview
            name_attr: Attribute name to use as item label
        """
        items = []
        for item in collection:
            if item is None:
                continue
            entry = {'name': getattr(item, name_attr, str(item)),
                     'data': item}
            if icon:
                entry['icon'] = icon
            else:
                # Use the Blender data object itself so _get_icon_image
                # can extract its native preview
                entry['icon'] = item
            items.append(entry)
        return cls(items=items, **kwargs)

    def set_items(self, items: List[dict]):
        """Replace the items list and reset selection."""
        self.items = items
        self.selected = -1
        self.scroll_offset = 0.0
        self._scroll_target = 0.0
        self._hover_index = -1

    def _get_icon_image(self, icon_value):
        """Resolve an icon value to a bpy.types.Image or None.

        icon_value can be:
          - None ? no icon
          - bpy.types.Image ? use directly
          - Blender data object with .preview ? extract preview
          - str ending with .png/.svg/.jpg ? load from file
          - str (Blender icon name) ? not yet support as image
        """
        if icon_value is None:
            return None
        import bpy
        # Already a UIImage or bpy image
        if isinstance(icon_value, UIImage):
            return icon_value
        if isinstance(icon_value, bpy.types.Image):
            return icon_value
        # Blender data object with preview (materials, textures, etc.)
        if hasattr(icon_value, 'preview') and icon_value.preview is not None:
            return self._preview_to_image(icon_value)
        if not isinstance(icon_value, str):
            return None
        # Cache lookup
        if icon_value in self._icon_cache:
            return self._icon_cache[icon_value]
        # File path
        if icon_value.lower().endswith(('.png', '.jpg', '.svg')):
            img = load_ui_image(icon_value)
            self._icon_cache[icon_value] = img
            return img
        # Blender built-in icon name (e.g. 'MATERIAL_DATA', 'MESH_CUBE')
        try:
            import importlib
            mod = importlib.import_module(f"{__package__}.blender_icons")
            get_blender_icon = mod.get_blender_icon
        except ImportError:
            get_blender_icon = None
        img = (get_blender_icon(icon_value, size=self.icon_size)
               if get_blender_icon is not None else None)
        if img is not None:
            self._icon_cache[icon_value] = img
            return img
        self._icon_cache[icon_value] = None
        return None

    def _preview_to_image(self, data_obj):
        """Extract a Blender data object's preview into a bpy.data.image."""
        import bpy
        obj_name = getattr(data_obj, 'name', str(id(data_obj)))
        name = f"bgui_preview_{type(data_obj).__name__}_{obj_name}"
        if name in self._icon_cache:
            return self._icon_cache[name]
        # Force preview generation
        if hasattr(data_obj, 'preview_ensure'):
            data_obj.preview_ensure()
        preview = getattr(data_obj, 'preview', None)
        if preview is None:
            self._icon_cache[name] = None
            return None
        # Try icon pixels first (32x32), then image pixels
        w, h = preview.icon_size
        if w == 0 or h == 0:
            self._icon_cache[name] = None
            return None
        try:
            pixels = list(preview.icon_pixels_float)
        except Exception:
            self._icon_cache[name] = None
            return None
        if not pixels or len(pixels) < w * h * 4:
            self._icon_cache[name] = None
            return None
        import gpu
        buf = gpu.types.Buffer('FLOAT', len(pixels), pixels)
        tex = gpu.types.GPUTexture((w, h), format='RGBA32F', data=buf)
        ui_img = UIImage(tex, w, h)
        self._icon_cache[name] = ui_img
        return ui_img

    @property
    def _content_height(self) -> float:
        return len(self.items) * self.item_height * ui_scale()

    _pad_v = 6  # vertical padding top/bottom (design pixels)

    @property
    def _max_scroll(self) -> float:
        sc = ui_scale()
        cr = self.content_rect if hasattr(self, 'rect') and self.rect else None
        h = cr.height if cr else (self.style.height or 200) * sc
        return max(0, self._content_height - (h - self._pad_v * sc * 2))

    def scroll_to_index(self, index: int):
        """Scroll so that the item at *index* is visible."""
        if index < 0 or index >= len(self.items):
            return
        sc = ui_scale()
        cr = self.content_rect if hasattr(self, 'rect') and self.rect else None
        view_h = (cr.height if cr else (self.style.height or 200) * sc) - self._pad_v * sc * 2
        ih = self.item_height * sc
        item_top = index * ih
        item_bottom = item_top + ih
        target = self._scroll_target
        if item_top < target:
            target = item_top
        elif item_bottom > target + view_h:
            target = item_bottom - view_h
        target = max(0.0, min(self._max_scroll, target))
        self._animate_scroll(target)

    def _animate_scroll(self, target: float):
        """Smoothly animate scroll_offset to *target*."""
        from .animation import Tween, ease_out_cubic
        target = max(0.0, min(self._max_scroll, target))
        self._scroll_target = target
        if abs(self.scroll_offset - target) < 0.5:
            self.scroll_offset = target
            return
        Tween(self, 'scroll_offset', self.scroll_offset, target,
              duration=0.3, ease=ease_out_cubic)

    def handle_scroll(self, delta: float, x: float, y: float) -> bool:
        if not self.rect.contains(x, y):
            return False
        target = self._scroll_target + delta * 40
        target = max(0.0, min(self._max_scroll, target))
        self._animate_scroll(target)
        return True

    def _scrollbar_geometry(self):
        """Return (track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w) or None."""
        max_scroll = self._max_scroll
        if max_scroll <= 0:
            return None
        sc = ui_scale()
        cr = self.content_rect
        pad_v = self._pad_v * sc
        pad_r = 8 * sc
        track_y = cr.y + pad_v
        track_h = cr.height - pad_v * 2
        if track_h <= 0:
            return None
        thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
        thumb_y = track_y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
        thumb_x = cr.right - pad_r - 3 * sc
        thumb_w = 3 * sc
        return track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w

    def _draw_content(self, renderer, style: Style):
        cr = self.content_rect
        sc = ui_scale()
        pad_v = self._pad_v * sc
        clip_rect = Rect(cr.x, cr.y + pad_v, cr.width, cr.height - pad_v * 2)
        renderer.push_clip(clip_rect)

        pad_l = 8 * sc
        pad_r = 8 * sc
        max_scroll = self._max_scroll
        has_scrollbar = max_scroll > 0
        sb_gap = 10 * sc if has_scrollbar else 0
        sb_w = 3 * sc if has_scrollbar else 0
        ih = self.item_height * sc
        icon_sz = self.icon_size * sc

        from .renderer import Renderer
        _, ref_h = Renderer.measure_text("Og", style.font_size,
                                         font_weight=style.font_weight or 'regular')

        for i, item in enumerate(self.items):
            iy = cr.y + pad_v + i * ih - self.scroll_offset
            if iy + ih < clip_rect.y or iy > clip_rect.bottom:
                continue

            item_rect = Rect(cr.x + pad_l, iy + 1 * sc, cr.width - pad_l - sb_gap - sb_w - pad_r, ih - 2 * sc)
            is_selected = (i == self.selected)

            # Highlight
            if is_selected:
                sel_color = (*self.active_color[:3], 0.2)
                renderer.draw_rounded_rect(item_rect, sel_color, 4 * sc)
                # Left accent bar
                bar_rect = Rect(cr.x + pad_l, iy + 4 * sc, 3 * sc, ih - 8 * sc)
                renderer.draw_rounded_rect(bar_rect, self.active_color, 1.5 * sc)
            elif i == self._hover_index:
                renderer.draw_rounded_rect(item_rect, self.hover_color, 4 * sc)

            # Icon (image or colored dot)
            icon_x = cr.x + pad_l + 8 * sc
            icon_value = item.get('icon')
            item_color = item.get('color')
            icon_img = self._get_icon_image(icon_value)
            icon_w = 0
            if icon_img:
                icon_y = iy + (ih - icon_sz) / 2
                icon_rect = Rect(icon_x, icon_y, icon_sz, icon_sz)
                renderer.draw_image(icon_img, icon_rect, border_radius=2 * sc)
                icon_w = icon_sz + 8 * sc
            elif item_color:
                dot_size = icon_sz * 0.7
                dot_y = iy + (ih - dot_size) / 2
                dot_rect = Rect(icon_x, dot_y, dot_size, dot_size)
                renderer.draw_rounded_rect(dot_rect, item_color, dot_size / 2)
                icon_w = dot_size + 8 * sc

            # Name
            name = item.get('name', '')
            name_x = icon_x + icon_w
            font_color = (1.0, 1.0, 1.0, 1.0) if is_selected else (0.85, 0.85, 0.88, 1.0)
            name_y = iy + (ih - ref_h) / 2
            renderer.draw_text(name, name_x, name_y,
                               size=style.font_size,
                               color=font_color,
                               font_weight=style.font_weight or 'regular',
                               ref_height=ref_h)

        # Scrollbar thumb
        max_scroll = self._max_scroll
        if max_scroll > 0:
            track_y = cr.y + pad_v
            track_h = cr.height - pad_v * 2
            thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
            thumb_y = track_y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
            thumb_rect = Rect(cr.right - pad_r - 3 * sc, thumb_y, 3 * sc, thumb_h)
            renderer.draw_rounded_rect(thumb_rect, (1, 1, 1, 0.15), 1.5 * sc)

        renderer.pop_clip()

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False

        # Scrollbar thumb drag start
        sb = self._scrollbar_geometry()
        if sb is not None:
            track_y, track_h, thumb_y, thumb_h, thumb_x, thumb_w = sb
            # Wider hit area for easier grabbing (8px around the 3px thumb)
            hit_margin = 4
            if (thumb_x - hit_margin <= x <= thumb_x + thumb_w + hit_margin and
                    thumb_y <= y <= thumb_y + thumb_h):
                self._sb_dragging = True
                self._sb_drag_offset = y - thumb_y
                self.state = WidgetState.PRESSED
                return True

        cr = self.content_rect
        sc = ui_scale()
        ih = self.item_height * sc
        idx = int((y - cr.y - self._pad_v * sc + self.scroll_offset) / ih)
        if 0 <= idx < len(self.items):
            now = time.perf_counter()
            # Double click detection
            if (idx == self._last_click_index and
                    now - self._last_click_time < 0.4):
                if self.on_double_click:
                    self.on_double_click(self, idx)
            self._last_click_time = now
            self._last_click_index = idx
            self.selected = idx
            if self.on_select:
                self.on_select(self, idx)
        self.state = WidgetState.PRESSED
        return True

    def handle_mouse_release(self, x: float, y: float) -> bool:
        if self._sb_dragging:
            self._sb_dragging = False
            self.state = WidgetState.NORMAL
            return True
        return super().handle_mouse_release(x, y)

    def propagate_mouse_move(self, x: float, y: float):
        # Scrollbar drag � update scroll offset based on mouse Y
        if self._sb_dragging:
            sb = self._scrollbar_geometry()
            if sb is not None:
                track_y, track_h, _thumb_y, thumb_h, _thumb_x, _thumb_w = sb
                max_scroll = self._max_scroll
                new_thumb_y = y - self._sb_drag_offset
                ratio = (new_thumb_y - track_y) / (track_h - thumb_h) if track_h > thumb_h else 0
                ratio = max(0.0, min(1.0, ratio))
                self.scroll_offset = ratio * max_scroll
            return

        super().propagate_mouse_move(x, y)
        if self.rect.contains(x, y):
            cr = self.content_rect
            sc = ui_scale()
            ih = self.item_height * sc
            idx = int((y - cr.y - self._pad_v * sc + self.scroll_offset) / ih)
            self._hover_index = idx if 0 <= idx < len(self.items) else -1
        else:
            self._hover_index = -1


# -- TreeView -------------------------------------------------


class TreeNode:
    """Data node for TreeView. Each node has a label, optional children, and state."""
    __slots__ = ('label', 'children', 'expanded', 'data', 'depth')

    def __init__(self, label: str, children: Optional[List['TreeNode']] = None,
                 expanded: bool = False, data=None):
        self.label = label
        self.children = children or []
        self.expanded = expanded
        self.data = data
        self.depth = 0

    def flatten(self, depth: int = 0) -> List['TreeNode']:
        """Return a flat list of visible nodes with depth info."""
        self.depth = depth
        result = [self]
        if self.expanded:
            for child in self.children:
                result.extend(child.flatten(depth + 1))
        return result


class TreeView(Widget):
    """Collapsible hierarchical tree with selection.

    Usage::

        TreeView(root_nodes=[
            TreeNode("Materials", children=[
                TreeNode("Diffuse"), TreeNode("Glossy"),
            ], expanded=True),
            TreeNode("Textures"),
        ], on_select=lambda w, node: print(node.label))
    """

    def __init__(self, root_nodes: Optional[List[TreeNode]] = None,
                 item_height: float = 26.0,
                 indent: float = 18.0,
                 on_select: Optional[Callable] = None,
                 **kwargs):
        super().__init__(**kwargs)
        self.root_nodes = root_nodes or []
        self.item_height = item_height
        self.indent = indent
        self.on_select = on_select
        self.selected_node: Optional[TreeNode] = None
        self.scroll_offset: float = 0.0
        self._hover_node: Optional[TreeNode] = None
        self._flat_nodes: List[TreeNode] = []

        s = self.style
        if s.background_color is None:
            s.background_color = (0.15, 0.15, 0.18, 1.0)
        if s.border_radius == 0:
            s.border_radius = 5
        if s.border_color is None:
            s.border_color = (0.30, 0.30, 0.34, 0.5)
            s.border_width = 1
        s.clip_children = True

    def _rebuild_flat(self):
        self._flat_nodes = []
        for root in self.root_nodes:
            self._flat_nodes.extend(root.flatten(0))

    @property
    def _content_height(self) -> float:
        return len(self._flat_nodes) * self.item_height * ui_scale()

    @property
    def _max_scroll(self) -> float:
        return max(0, self._content_height - self.rect.height)

    def handle_scroll(self, delta: float, x: float, y: float) -> bool:
        if not self.rect.contains(x, y):
            return False
        old = self.scroll_offset
        self.scroll_offset = max(0, min(self._max_scroll,
                                        self.scroll_offset + delta * 20))
        return True  # Always consume to prevent viewport zoom

    def _draw_content(self, renderer, style):
        self._rebuild_flat()
        cr = self.content_rect
        sc = ui_scale()
        ih = self.item_height * sc
        ind = self.indent * sc
        renderer.push_clip(self.rect)

        for i, node in enumerate(self._flat_nodes):
            iy = cr.y + i * ih - self.scroll_offset
            if iy + ih < cr.y or iy > cr.bottom:
                continue

            x_offset = cr.x + node.depth * ind
            item_rect = Rect(x_offset, iy, cr.width - node.depth * ind - 4 * sc,
                             ih)

            # Selection / hover
            is_selected = node is self.selected_node
            is_hovered = node is self._hover_node
            if is_selected:
                renderer.draw_rounded_rect(
                    Rect(cr.x + 2 * sc, iy, cr.width - 4 * sc, ih),
                    (0.33, 0.55, 0.95, 0.25), 4 * sc)
            elif is_hovered:
                renderer.draw_rounded_rect(
                    Rect(cr.x + 2 * sc, iy, cr.width - 4 * sc, ih),
                    (0.33, 0.55, 0.95, 0.10), 4 * sc)

            # Expand/collapse arrow
            if node.children:
                arrow = "?" if node.expanded else "?"
                renderer.draw_text(arrow, x_offset + 2 * sc, iy + 5 * sc, size=11,
                                   color=(0.6, 0.6, 0.65, 1.0))

            # Label
            label_x = x_offset + (14 * sc if node.children else 4 * sc)
            color = (0.95, 0.95, 0.97, 1.0) if is_selected else (0.85, 0.85, 0.88, 1.0)
            renderer.draw_text(node.label, label_x, iy + 5 * sc, size=12, color=color)

        # Scrollbar
        max_scroll = self._max_scroll
        if max_scroll > 0:
            track_h = self.rect.height
            thumb_h = max(20 * sc, track_h * (track_h / (track_h + max_scroll)))
            thumb_y = self.rect.y + (self.scroll_offset / max_scroll) * (track_h - thumb_h)
            renderer.draw_rounded_rect(
                Rect(self.rect.right - 4 * sc, thumb_y, 3 * sc, thumb_h),
                (1, 1, 1, 0.15), 1.5 * sc)
        renderer.pop_clip()

    def _node_at(self, y: float) -> Optional[TreeNode]:
        """Get the node at a given y position."""
        cr = self.content_rect
        ih = self.item_height * ui_scale()
        idx = int((y - cr.y + self.scroll_offset) / ih)
        if 0 <= idx < len(self._flat_nodes):
            return self._flat_nodes[idx]
        return None

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        node = self._node_at(y)
        if node:
            sc = ui_scale()
            # Check if click is on the expand arrow area
            cr = self.content_rect
            x_offset = cr.x + node.depth * self.indent * sc
            if node.children and x <= x_offset + 14 * sc:
                node.expanded = not node.expanded
                self._rebuild_flat()
            else:
                self.selected_node = node
                if self.on_select:
                    self.on_select(self, node)
        self.state = WidgetState.PRESSED
        return True

    def propagate_mouse_move(self, x: float, y: float):
        super().propagate_mouse_move(x, y)
        if self.rect.contains(x, y):
            self._hover_node = self._node_at(y)
        else:
            self._hover_node = None
