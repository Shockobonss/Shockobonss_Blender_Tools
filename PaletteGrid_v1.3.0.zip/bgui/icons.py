# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""BGUI Icon System � PNG loader + dynamic color icon generation.

Provides:
- load_icons_from_directory(): Load custom PNG icons from an addon's icons/ folder
- color_icon(): Generate flat-color swatch icons on the fly
- gradient_icon(): Generate horizontal gradient icons
- get_icon(): Retrieve icon_id by name
"""
from __future__ import annotations
import os
from typing import Dict, Optional, Tuple
import bpy
import bpy.utils.previews

Color = Tuple[float, float, float, float]

# -- Internal State -------------------------------------------

_preview_collections: Dict[str, bpy.utils.previews.ImagePreviewCollection] = {}


def _get_collection(namespace: str = "bgui_main") -> bpy.utils.previews.ImagePreviewCollection:
    if namespace not in _preview_collections:
        _preview_collections[namespace] = bpy.utils.previews.new()
    return _preview_collections[namespace]


# -- PNG Icon Loading -----------------------------------------

def load_icons_from_directory(directory: str, namespace: str = "bgui_main"):
    """Load all PNG/JPG icons from a directory into the preview collection.

    Icons become available via get_icon(stem_name).
    Example: icons/palette.png ? get_icon("palette")
    """
    pcoll = _get_collection(namespace)
    if not os.path.isdir(directory):
        return

    extensions = {'.png', '.jpg', '.jpeg'}
    for filename in os.listdir(directory):
        stem, ext = os.path.splitext(filename)
        if ext.lower() not in extensions:
            continue
        if stem in pcoll:
            continue
        filepath = os.path.join(directory, filename)
        pcoll.load(stem, filepath, 'IMAGE')


def get_icon(name: str, namespace: str = "bgui_main") -> int:
    """Get icon_id by name. Returns 0 if not found."""
    pcoll = _preview_collections.get(namespace)
    if pcoll and name in pcoll:
        return pcoll[name].icon_id
    return 0


# -- Dynamic Color Icons -------------------------------------

_color_cache: Dict[Tuple[int, ...], str] = {}  # quantized_color ? icon_name


def color_icon(color: Color, size: int = 32, namespace: str = "bgui_colors") -> int:
    """Generate a flat-color swatch icon and return its icon_id.

    Colors are quantized to avoid unbounded cache growth.
    """
    pcoll = _get_collection(namespace)
    key = (round(color[0] * 255), round(color[1] * 255),
           round(color[2] * 255), round(color[3] * 255))

    if key in _color_cache:
        name = _color_cache[key]
        return pcoll[name].icon_id

    name = f"bgui_c_{key[0]}_{key[1]}_{key[2]}_{key[3]}"
    preview = pcoll.new(name)
    preview.icon_size = [size, size]
    pixel = [color[0], color[1], color[2], color[3]]
    preview.icon_pixels_float = pixel * (size * size)

    _color_cache[key] = name
    return preview.icon_id


def gradient_icon(color_left: Color, color_right: Color,
                  size: int = 32, namespace: str = "bgui_colors") -> int:
    """Generate a horizontal gradient icon and return its icon_id."""
    pcoll = _get_collection(namespace)

    kl = tuple(round(c * 255) for c in color_left)
    kr = tuple(round(c * 255) for c in color_right)
    key = (kl, kr)

    name = f"bgui_g_{kl[0]}_{kl[1]}_{kl[2]}_{kr[0]}_{kr[1]}_{kr[2]}"
    if name in pcoll:
        return pcoll[name].icon_id

    preview = pcoll.new(name)
    preview.icon_size = [size, size]

    pixels = []
    for _y in range(size):
        for x in range(size):
            t = x / max(1, size - 1)
            r = color_left[0] + (color_right[0] - color_left[0]) * t
            g = color_left[1] + (color_right[1] - color_left[1]) * t
            b = color_left[2] + (color_right[2] - color_left[2]) * t
            a = color_left[3] + (color_right[3] - color_left[3]) * t
            pixels.extend([r, g, b, a])

    preview.icon_pixels_float = pixels
    return preview.icon_id


# -- Cleanup --------------------------------------------------

def cleanup():
    """Remove all preview collections and clear caches."""
    global _color_cache
    for pcoll in list(_preview_collections.values()):
        try:
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass
    _preview_collections.clear()
    _color_cache.clear()
