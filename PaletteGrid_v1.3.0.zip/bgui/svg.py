# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Minimal SVG rasteriser � pure-Python + NumPy.

Supports the subset of SVG commonly used for icons:
  <path d="...">   M,L,H,V,C,S,Q,T,A,Z (absolute & relative)
  <rect>, <circle>, <ellipse>
  fill color (solid), viewBox scaling, even-odd / nonzero fill rules.

Usage::

    from .svg import rasterize_svg
    pixels = rasterize_svg("/path/to/icon.svg", width=64, height=64)
    # pixels is a flat list of floats [r,g,b,a, r,g,b,a, ...] suitable
    # for bpy.data.images[...].pixels = pixels
"""

from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from typing import List, Tuple, Optional

import numpy as np

# --- Types --------------------------------------------------

Point = Tuple[float, float]
Color = Tuple[float, float, float, float]  # RGBA 0-1


# --- SVG Colour Parsing ------------------------------------

_NAMED_COLORS = {
    'black': (0, 0, 0), 'white': (255, 255, 255),
    'red': (255, 0, 0), 'green': (0, 128, 0), 'blue': (0, 0, 255),
    'none': None,
}


def _parse_color(s: Optional[str], opacity: float = 1.0) -> Optional[Color]:
    """Parse an SVG colour string into RGBA (0-1)."""
    if not s or s.lower() == 'none':
        return None
    s = s.strip().lower()
    if s in _NAMED_COLORS:
        c = _NAMED_COLORS[s]
        if c is None:
            return None
        return (c[0] / 255, c[1] / 255, c[2] / 255, opacity)
    if s.startswith('#'):
        h = s[1:]
        if len(h) == 3:
            h = ''.join(c * 2 for c in h)
        if len(h) == 6:
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return (r / 255, g / 255, b / 255, opacity)
    m = re.match(r'rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', s)
    if m:
        return (int(m[1]) / 255, int(m[2]) / 255, int(m[3]) / 255, opacity)
    return None


# --- SVG Path Parser ---------------------------------------

_CMD_RE = re.compile(r'([MmLlHhVvCcSsQqTtAaZz])')
_NUM_RE = re.compile(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?')


def _tokenize_path(d: str) -> list:
    """Split an SVG path d-attribute into (command, [numbers]) tokens."""
    parts = _CMD_RE.split(d)
    tokens = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if len(part) == 1 and part.isalpha():
            tokens.append(part)
        else:
            tokens.extend(float(n) for n in _NUM_RE.findall(part))
    return tokens


def _parse_path(d: str) -> List[List[Point]]:
    """Parse an SVG path d-string into a list of sub-paths (polygon outlines).

    Curves are flattened to line segments.
    Returns list of sub-paths, each a list of (x, y) points.
    """
    tokens = _tokenize_path(d)
    subpaths: List[List[Point]] = []
    current: List[Point] = []
    cx, cy = 0.0, 0.0  # current point
    sx, sy = 0.0, 0.0  # sub-path start
    last_cp: Optional[Point] = None  # last control point for S/T
    i = 0

    def _next() -> float:
        nonlocal i
        i += 1
        return tokens[i - 1]

    while i < len(tokens):
        tok = tokens[i]
        if isinstance(tok, str):
            cmd = tok
            i += 1
        else:
            # Implicit repeat of last command
            if cmd in ('M', 'm'):
                cmd = 'L' if cmd == 'M' else 'l'

        if cmd == 'M':
            if current:
                subpaths.append(current)
            cx, cy = _next(), _next()
            sx, sy = cx, cy
            current = [(cx, cy)]
            last_cp = None
        elif cmd == 'm':
            if current:
                subpaths.append(current)
            cx += _next()
            cy += _next()
            sx, sy = cx, cy
            current = [(cx, cy)]
            last_cp = None

        elif cmd == 'L':
            cx, cy = _next(), _next()
            current.append((cx, cy))
            last_cp = None
        elif cmd == 'l':
            cx += _next()
            cy += _next()
            current.append((cx, cy))
            last_cp = None

        elif cmd == 'H':
            cx = _next()
            current.append((cx, cy))
            last_cp = None
        elif cmd == 'h':
            cx += _next()
            current.append((cx, cy))
            last_cp = None

        elif cmd == 'V':
            cy = _next()
            current.append((cx, cy))
            last_cp = None
        elif cmd == 'v':
            cy += _next()
            current.append((cx, cy))
            last_cp = None

        elif cmd == 'C':
            x1, y1 = _next(), _next()
            x2, y2 = _next(), _next()
            x3, y3 = _next(), _next()
            pts = _flatten_cubic(cx, cy, x1, y1, x2, y2, x3, y3)
            current.extend(pts[1:])
            last_cp = (x2, y2)
            cx, cy = x3, y3
        elif cmd == 'c':
            x1, y1 = cx + _next(), cy + _next()
            x2, y2 = cx + _next(), cy + _next()
            x3, y3 = cx + _next(), cy + _next()
            pts = _flatten_cubic(cx, cy, x1, y1, x2, y2, x3, y3)
            current.extend(pts[1:])
            last_cp = (x2, y2)
            cx, cy = x3, y3

        elif cmd == 'S':
            if last_cp:
                x1 = 2 * cx - last_cp[0]
                y1 = 2 * cy - last_cp[1]
            else:
                x1, y1 = cx, cy
            x2, y2 = _next(), _next()
            x3, y3 = _next(), _next()
            pts = _flatten_cubic(cx, cy, x1, y1, x2, y2, x3, y3)
            current.extend(pts[1:])
            last_cp = (x2, y2)
            cx, cy = x3, y3
        elif cmd == 's':
            if last_cp:
                x1 = 2 * cx - last_cp[0]
                y1 = 2 * cy - last_cp[1]
            else:
                x1, y1 = cx, cy
            x2, y2 = cx + _next(), cy + _next()
            x3, y3 = cx + _next(), cy + _next()
            pts = _flatten_cubic(cx, cy, x1, y1, x2, y2, x3, y3)
            current.extend(pts[1:])
            last_cp = (x2, y2)
            cx, cy = x3, y3

        elif cmd == 'Q':
            qx, qy = _next(), _next()
            x3, y3 = _next(), _next()
            pts = _flatten_quadratic(cx, cy, qx, qy, x3, y3)
            current.extend(pts[1:])
            last_cp = (qx, qy)
            cx, cy = x3, y3
        elif cmd == 'q':
            qx, qy = cx + _next(), cy + _next()
            x3, y3 = cx + _next(), cy + _next()
            pts = _flatten_quadratic(cx, cy, qx, qy, x3, y3)
            current.extend(pts[1:])
            last_cp = (qx, qy)
            cx, cy = x3, y3

        elif cmd == 'T':
            if last_cp:
                qx = 2 * cx - last_cp[0]
                qy = 2 * cy - last_cp[1]
            else:
                qx, qy = cx, cy
            x3, y3 = _next(), _next()
            pts = _flatten_quadratic(cx, cy, qx, qy, x3, y3)
            current.extend(pts[1:])
            last_cp = (qx, qy)
            cx, cy = x3, y3
        elif cmd == 't':
            if last_cp:
                qx = 2 * cx - last_cp[0]
                qy = 2 * cy - last_cp[1]
            else:
                qx, qy = cx, cy
            x3, y3 = cx + _next(), cy + _next()
            pts = _flatten_quadratic(cx, cy, qx, qy, x3, y3)
            current.extend(pts[1:])
            last_cp = (qx, qy)
            cx, cy = x3, y3

        elif cmd in ('A', 'a'):
            rx_a = _next()
            ry_a = _next()
            rotation = _next()
            large_arc = int(_next())
            sweep = int(_next())
            if cmd == 'A':
                ex, ey = _next(), _next()
            else:
                ex, ey = cx + _next(), cy + _next()
            pts = _flatten_arc(cx, cy, rx_a, ry_a, rotation, large_arc, sweep, ex, ey)
            current.extend(pts[1:])
            cx, cy = ex, ey
            last_cp = None

        elif cmd in ('Z', 'z'):
            if current:
                current.append((sx, sy))
                subpaths.append(current)
                current = []
            cx, cy = sx, sy
            last_cp = None

    if current:
        subpaths.append(current)
    return subpaths


# --- Curve Flattening --------------------------------------

def _flatten_cubic(x0, y0, x1, y1, x2, y2, x3, y3,
                   tol: float = 0.25) -> List[Point]:
    """Flatten a cubic B�zier curve into line segments."""
    result = [(x0, y0)]
    _subdivide_cubic(x0, y0, x1, y1, x2, y2, x3, y3, result, tol, 0)
    result.append((x3, y3))
    return result


def _subdivide_cubic(x0, y0, x1, y1, x2, y2, x3, y3,
                     out: list, tol: float, depth: int):
    if depth > 12:
        return
    # Flatness test: max deviation of control points from chord
    dx = x3 - x0
    dy = y3 - y0
    d = max(abs((x1 - x3) * dy - (y1 - y3) * dx),
            abs((x2 - x3) * dy - (y2 - y3) * dx))
    if d * d <= tol * tol * (dx * dx + dy * dy):
        return
    # De Casteljau subdivision at t=0.5
    mx01 = (x0 + x1) * 0.5
    my01 = (y0 + y1) * 0.5
    mx12 = (x1 + x2) * 0.5
    my12 = (y1 + y2) * 0.5
    mx23 = (x2 + x3) * 0.5
    my23 = (y2 + y3) * 0.5
    mxa = (mx01 + mx12) * 0.5
    mya = (my01 + my12) * 0.5
    mxb = (mx12 + mx23) * 0.5
    myb = (my12 + my23) * 0.5
    mxm = (mxa + mxb) * 0.5
    mym = (mya + myb) * 0.5
    _subdivide_cubic(x0, y0, mx01, my01, mxa, mya, mxm, mym, out, tol, depth + 1)
    out.append((mxm, mym))
    _subdivide_cubic(mxm, mym, mxb, myb, mx23, my23, x3, y3, out, tol, depth + 1)


def _flatten_quadratic(x0, y0, cx, cy, x1, y1,
                       tol: float = 0.25) -> List[Point]:
    """Flatten a quadratic B�zier curve into line segments."""
    # Convert to cubic: CP1 = P0 + 2/3*(CP-P0), CP2 = P1 + 2/3*(CP-P1)
    c1x = x0 + 2 / 3 * (cx - x0)
    c1y = y0 + 2 / 3 * (cy - y0)
    c2x = x1 + 2 / 3 * (cx - x1)
    c2y = y1 + 2 / 3 * (cy - y1)
    return _flatten_cubic(x0, y0, c1x, c1y, c2x, c2y, x1, y1, tol)


def _flatten_arc(cx, cy, rx, ry, rotation_deg, large_arc, sweep,
                 ex, ey, tol: float = 0.25) -> List[Point]:
    """Flatten an SVG arc command into line segments."""
    if rx == 0 or ry == 0:
        return [(cx, cy), (ex, ey)]

    rx, ry = abs(rx), abs(ry)
    phi = math.radians(rotation_deg)
    cos_phi = math.cos(phi)
    sin_phi = math.sin(phi)

    # Step 1: compute (x1', y1')
    dx2 = (cx - ex) / 2
    dy2 = (cy - ey) / 2
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    # Scale radii if needed
    lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if lam > 1:
        s = math.sqrt(lam)
        rx *= s
        ry *= s

    # Step 2: compute (cx', cy')
    num = max(0, rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p)
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    sq = math.sqrt(num / den) if den > 0 else 0
    if large_arc == sweep:
        sq = -sq
    cxp = sq * rx * y1p / ry
    cyp = -sq * ry * x1p / rx

    # Step 3: compute center
    cxo = cos_phi * cxp - sin_phi * cyp + (cx + ex) / 2
    cyo = sin_phi * cxp + cos_phi * cyp + (cy + ey) / 2

    # Step 4: compute angles
    def _angle(ux, uy, vx, vy):
        dot = ux * vx + uy * vy
        crs = ux * vy - uy * vx
        a = math.acos(max(-1, min(1, dot / (math.hypot(ux, uy) * math.hypot(vx, vy) + 1e-12))))
        return -a if crs < 0 else a

    theta1 = _angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dtheta = _angle((x1p - cxp) / rx, (y1p - cyp) / ry,
                    (-x1p - cxp) / rx, (-y1p - cyp) / ry)

    if sweep == 0 and dtheta > 0:
        dtheta -= 2 * math.pi
    elif sweep == 1 and dtheta < 0:
        dtheta += 2 * math.pi

    # Flatten arc into segments
    n = max(4, int(abs(dtheta) / (math.pi / 16)))
    pts = [(cx, cy)]
    for i in range(1, n + 1):
        t = theta1 + dtheta * i / n
        xr = rx * math.cos(t)
        yr = ry * math.sin(t)
        px = cos_phi * xr - sin_phi * yr + cxo
        py = sin_phi * xr + cos_phi * yr + cyo
        pts.append((px, py))
    return pts


# --- Scanline Rasteriser -----------------------------------

def _rasterize_subpaths(subpaths: List[List[Point]],
                        width: int, height: int,
                        fill_rule: str = 'evenodd',
                        ssaa: int = 2) -> np.ndarray:
    """Rasterise sub-paths into an alpha mask (height � width) float32.

    Uses supersampled scanline fill.
    """
    sw = width * ssaa
    sh = height * ssaa
    mask = np.zeros((sh, sw), dtype=np.float32)

    # Build edge list (scaled to supersampled grid)
    edges = []
    for path in subpaths:
        n = len(path)
        for i in range(n - 1):
            x0, y0 = path[i][0] * ssaa, path[i][1] * ssaa
            x1, y1 = path[i + 1][0] * ssaa, path[i + 1][1] * ssaa
            if y0 == y1:
                continue  # horizontal edge, skip
            if y0 > y1:
                x0, y0, x1, y1 = x1, y1, x0, y0
                direction = -1
            else:
                direction = 1
            edges.append((y0, y1, x0, (x1 - x0) / (y1 - y0), direction))

    # Scanline fill
    for sy in range(sh):
        y = sy + 0.5
        intersections = []
        for y_min, y_max, x_start, dx_dy, direction in edges:
            if y_min <= y < y_max:
                x_at_y = x_start + (y - y_min) * dx_dy
                intersections.append((x_at_y, direction))
        intersections.sort(key=lambda t: t[0])

        if fill_rule == 'evenodd':
            for j in range(0, len(intersections) - 1, 2):
                x_left = max(0, int(intersections[j][0]))
                x_right = min(sw, int(math.ceil(intersections[j + 1][0])))
                if x_left < x_right:
                    mask[sy, x_left:x_right] = 1.0
        else:  # nonzero
            winding = 0
            j = 0
            while j < len(intersections):
                x_start_fill = intersections[j][0]
                winding += intersections[j][1]
                j += 1
                while j < len(intersections) and winding != 0:
                    winding += intersections[j][1]
                    j += 1
                if j <= len(intersections):
                    x_end_fill = intersections[j - 1][0]
                    xl = max(0, int(x_start_fill))
                    xr = min(sw, int(math.ceil(x_end_fill)))
                    if xl < xr:
                        mask[sy, xl:xr] = 1.0

    # Downsample (box filter)
    mask = mask.reshape(height, ssaa, width, ssaa).mean(axis=(1, 3))
    return mask


# --- SVG Document Parser -----------------------------------

_SVG_NS = '{http://www.w3.org/2000/svg}'


def _strip_ns(tag: str) -> str:
    if tag.startswith('{'):
        return tag.split('}', 1)[1]
    return tag


def _parse_transform(transform: Optional[str]) -> Optional[Tuple]:
    """SVG transform parser � handles matrix, translate, and scale."""
    if not transform:
        return None
    # matrix(a, b, c, d, e, f)
    m = re.search(r'matrix\(\s*([^,\s]+)\s*[,\s]\s*([^,\s]+)\s*[,\s]\s*([^,\s]+)\s*[,\s]\s*([^,\s]+)\s*[,\s]\s*([^,\s]+)\s*[,\s]\s*([^)]+)\)', transform)
    if m:
        a, b, c, d, e, f = (float(m[i]) for i in range(1, 7))
        return ('matrix', a, b, c, d, e, f)
    # translate(tx, ty)
    m = re.search(r'translate\(\s*([^,\s]+)\s*[,\s]\s*([^)]+)\)', transform)
    if m:
        return ('translate', float(m[1]), float(m[2]))
    m = re.search(r'scale\(\s*([^,\s)]+)(?:\s*[,\s]\s*([^)]+))?\)', transform)
    if m:
        sx = float(m[1])
        sy = float(m[2]) if m[2] else sx
        return ('scale', sx, sy)
    return None


def _apply_transform(points, transform):
    """Apply a transform to a list of points."""
    if not transform:
        return points
    kind = transform[0]
    if kind == 'translate':
        tx, ty = transform[1], transform[2]
        return [(x + tx, y + ty) for x, y in points]
    if kind == 'scale':
        sx, sy = transform[1], transform[2]
        return [(x * sx, y * sy) for x, y in points]
    if kind == 'matrix':
        a, b, c, d, e, f = transform[1:]
        return [(a * x + c * y + e, b * x + d * y + f) for x, y in points]
    return points


class _Shape:
    __slots__ = ('subpaths', 'fill', 'fill_rule')

    def __init__(self, subpaths, fill, fill_rule='evenodd'):
        self.subpaths = subpaths
        self.fill = fill
        self.fill_rule = fill_rule


def _parse_svg_element(elem, parent_fill=None, parent_opacity=1.0,
                       parent_transform=None) -> List[_Shape]:
    """Recursively extract shapes from an SVG element tree."""
    shapes = []
    tag = _strip_ns(elem.tag)

    # Parse inline style attribute into a dict
    style_dict = {}
    style_attr = elem.get('style', '')
    if style_attr:
        for part in style_attr.split(';'):
            part = part.strip()
            if ':' in part:
                k, v = part.split(':', 1)
                style_dict[k.strip()] = v.strip()

    # Gather fill & opacity (style overrides attributes)
    fill_str = style_dict.get('fill', elem.get('fill', parent_fill))
    opacity = float(style_dict.get('opacity',
                    style_dict.get('fill-opacity',
                    elem.get('opacity', elem.get('fill-opacity', parent_opacity)))))
    fill_rule = style_dict.get('fill-rule',
                style_dict.get('clip-rule',
                elem.get('fill-rule', elem.get('clip-rule', 'evenodd'))))
    transform = _parse_transform(elem.get('transform'))

    # Determine fill color (skip gradient url() references)
    fill_color = None
    if fill_str and fill_str.lower().startswith('url('):
        fill_color = None  # gradient � can't rasterize, skip
    elif fill_str and fill_str.lower() != 'none':
        fill_color = _parse_color(fill_str, opacity)
    elif fill_str is None and parent_fill is None:
        # Default SVG fill is black
        fill_color = (0, 0, 0, opacity)

    if tag == 'path':
        d = elem.get('d', '')
        if d:
            subpaths = _parse_path(d)
            if transform:
                subpaths = [_apply_transform(sp, transform) for sp in subpaths]
            if parent_transform:
                subpaths = [_apply_transform(sp, parent_transform) for sp in subpaths]
            if fill_color:
                shapes.append(_Shape(subpaths, fill_color, fill_rule))

    elif tag == 'rect':
        x = float(elem.get('x', 0))
        y = float(elem.get('y', 0))
        w = float(elem.get('width', 0))
        h = float(elem.get('height', 0))
        if w > 0 and h > 0:
            rect_path = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
            subpaths = [rect_path]
            if transform:
                subpaths = [_apply_transform(sp, transform) for sp in subpaths]
            if parent_transform:
                subpaths = [_apply_transform(sp, parent_transform) for sp in subpaths]
            if fill_color:
                shapes.append(_Shape(subpaths, fill_color, fill_rule))

    elif tag in ('circle', 'ellipse'):
        cx_c = float(elem.get('cx', 0))
        cy_c = float(elem.get('cy', 0))
        if tag == 'circle':
            rx_c = ry_c = float(elem.get('r', 0))
        else:
            rx_c = float(elem.get('rx', 0))
            ry_c = float(elem.get('ry', 0))
        if rx_c > 0 and ry_c > 0:
            n = max(16, int(max(rx_c, ry_c) * 4))
            pts = []
            for i in range(n):
                a = 2 * math.pi * i / n
                pts.append((cx_c + rx_c * math.cos(a), cy_c + ry_c * math.sin(a)))
            pts.append(pts[0])
            subpaths = [pts]
            if transform:
                subpaths = [_apply_transform(sp, transform) for sp in subpaths]
            if parent_transform:
                subpaths = [_apply_transform(sp, parent_transform) for sp in subpaths]
            if fill_color:
                shapes.append(_Shape(subpaths, fill_color, fill_rule))

    # Recurse into children (g, svg, etc.)
    child_transform = transform or parent_transform
    for child in elem:
        shapes.extend(_parse_svg_element(
            child,
            parent_fill=fill_str,
            parent_opacity=opacity,
            parent_transform=child_transform,
        ))

    return shapes


# --- Public API ---------------------------------------------

def rasterize_svg(svg_path: str, width: int = 64, height: int = 64,
                  ssaa: int = 2, color=None, rotation: float = 0) -> list:
    """Rasterise an SVG file into an RGBA pixel list.

    Returns a flat list of floats [r,g,b,a, ...] of length width*height*4,
    compatible with ``bpy.data.images[...].pixels``.

    *color* � optional (r, g, b, a) tuple that overrides every shape's fill
    color, useful for tinting a single-color icon.
    *rotation* � degrees to rotate the SVG around its center (positive = CCW).
    """
    import math

    tree = ET.parse(svg_path)
    root = tree.getroot()

    # Determine viewBox
    vb = root.get('viewBox')
    if vb:
        parts = re.split(r'[\s,]+', vb.strip())
        vb_x, vb_y, vb_w, vb_h = (float(p) for p in parts[:4])
    else:
        vb_x, vb_y = 0, 0
        vb_w = float(root.get('width', width))
        vb_h = float(root.get('height', height))

    # Scale factor from viewBox to output pixels
    sx = width / vb_w
    sy = height / vb_h

    # Rotation setup
    rad = math.radians(rotation) if rotation else 0
    cos_a = math.cos(rad) if rad else 1.0
    sin_a = math.sin(rad) if rad else 0.0
    cx, cy = width / 2.0, height / 2.0

    # Extract shapes
    shapes = _parse_svg_element(root)

    # Create output image (RGBA float)
    img = np.zeros((height, width, 4), dtype=np.float32)

    for shape in shapes:
        # Transform sub-paths from SVG coords to pixel coords
        scaled = []
        for sp in shape.subpaths:
            pts = [((x - vb_x) * sx, (y - vb_y) * sy) for x, y in sp]
            if rad:
                pts = [(cx + (px - cx) * cos_a - (py - cy) * sin_a,
                        cy + (px - cx) * sin_a + (py - cy) * cos_a)
                       for px, py in pts]
            scaled.append(pts)

        # Rasterise alpha mask
        mask = _rasterize_subpaths(scaled, width, height,
                                   fill_rule=shape.fill_rule, ssaa=ssaa)

        # Composite shape (pre-multiplied alpha over)
        if color is not None:
            r, g, b, a = color
        else:
            r, g, b, a = shape.fill
        alpha = mask * a
        inv = 1.0 - alpha
        img[:, :, 0] = img[:, :, 0] * inv + r * alpha
        img[:, :, 1] = img[:, :, 1] * inv + g * alpha
        img[:, :, 2] = img[:, :, 2] * inv + b * alpha
        img[:, :, 3] = img[:, :, 3] * inv + alpha

    # Blender expects bottom-to-top row order
    img = img[::-1]
    return img.flatten().tolist()


def load_svg_as_image(svg_path: str, width: int = 64, height: int = 64,
                      ssaa: int = 2, color=None, rotation: float = 0):
    """Load an SVG file as a GPU texture (UIImage).

    Does NOT create bpy.data.images entries.
    *color* � optional (r, g, b, a) override for all fills.
    *rotation* � degrees to rotate the SVG around its center.
    Returns UIImage or None.
    """
    import gpu
    import os

    name = os.path.basename(svg_path)
    key = f".bgui_svg_{name}_{width}x{height}"
    if color is not None:
        cr, cg, cb = int(color[0]*255), int(color[1]*255), int(color[2]*255)
        key += f"_{cr:02x}{cg:02x}{cb:02x}"
    if rotation:
        key += f"_r{int(rotation)}"

    if key in _svg_cache:
        return _svg_cache[key]

    pixels = rasterize_svg(svg_path, width, height, ssaa, color=color, rotation=rotation)
    buf = gpu.types.Buffer('FLOAT', len(pixels), pixels)
    tex = gpu.types.GPUTexture((width, height), format='RGBA32F', data=buf)
    from .widgets import UIImage
    ui_img = UIImage(tex, width, height)
    _svg_cache[key] = ui_img
    return ui_img


_svg_cache: dict = {}  # key ? UIImage
