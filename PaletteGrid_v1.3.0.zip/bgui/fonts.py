# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""BGUI Font Manager � load custom fonts and map weights to blf font IDs."""
from __future__ import annotations
import os
from typing import Dict, Optional

import blf


# Font weight constants
LIGHT = 'light'
REGULAR = 'regular'
MEDIUM = 'medium'
SEMIBOLD = 'semibold'
BOLD = 'bold'

# Registry: weight -> blf font_id
_fonts: Dict[str, int] = {}
_font_paths: Dict[str, str] = {}  # weight -> file path
_default_weight: str = REGULAR


def load_family(font_dir: str, mapping: Dict[str, str]) -> None:
    """Load a font family from *font_dir*.

    *mapping* maps weight names to filenames::

        load_family("/path/to/fonts", {
            "regular": "MyFont-Regular.ttf",
            "bold":    "MyFont-Bold.ttf",
        })
    """
    for weight, filename in mapping.items():
        path = os.path.join(font_dir, filename)
        if not os.path.isfile(path):
            print(f"[BGUI fonts] WARNING: font not found: {path}")
            continue
        fid = blf.load(path)
        if fid == -1:
            print(f"[BGUI fonts] WARNING: blf.load failed for {path}")
            continue
        _fonts[weight] = fid
        _font_paths[weight] = path


def get(weight: str = REGULAR) -> int:
    """Return the blf font_id for *weight*, falling back to default then 0."""
    if weight in _fonts:
        return _fonts[weight]
    if _default_weight in _fonts:
        return _fonts[_default_weight]
    return 0  # Blender built-in


def set_default(weight: str) -> None:
    """Set the default font weight used when no weight is specified."""
    global _default_weight
    _default_weight = weight


def unload_all() -> None:
    """Unload all custom fonts (blf handles are invalidated on reload)."""
    for path in _font_paths.values():
        try:
            blf.unload(path)
        except Exception:
            pass
    _fonts.clear()
    _font_paths.clear()
