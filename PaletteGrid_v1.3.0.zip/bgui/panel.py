# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Blender integration � draw handler, modal input operator, UIPanel."""
from __future__ import annotations
from typing import Optional, Dict
import bpy
from .core import Widget, Rect
from .renderer import Renderer
from .widgets import Dropdown


def _find_open_dropdown(widget: Widget) -> Optional[Dropdown]:
    """Recursively find an open Dropdown in the widget tree."""
    if isinstance(widget, Dropdown) and widget.open:
        return widget
    for child in widget.children:
        found = _find_open_dropdown(child)
        if found:
            return found
    return None


def _handle_press_with_dropdown(root: Widget, x: float, y: float) -> bool:
    """Handle mouse press, giving priority to any open dropdown overlay."""
    # Blur the currently focused TextInput (if any).
    # If the click lands on a TextInput, it will re-focus itself.
    from .widgets import TextInput as _TI
    if _TI._focused_instance is not None:
        _TI._focused_instance.blur()
    # Blur any custom editing widgets (hex inputs, opacity fields, etc.)
    from .core import blur_all_editing
    blur_all_editing()

    dd = _find_open_dropdown(root)
    if dd:
        # Let the open dropdown handle the click first (includes its list area)
        if dd.handle_mouse_press(x, y):
            return True
        # Click was outside both trigger and list � close and consume
        dd.open = False
        return True
    return root.handle_mouse_press(x, y)


# Global panel registry
_active_panels: Dict[str, UIPanel] = {}

# Shutdown guard � set during unregister to prevent draw callbacks
# from accessing freed resources (GPU handles, class pointers).
_shutting_down = False

# Tracks which Blender area the modal is currently processing events for.
# Set at the start of modal(), cleared at the end.  Used by app/texture.py
# to scope focus_texture() to the active Image Editor area.
_current_event_area = None


def get_current_event_area():
    """Return the Blender area the modal is currently processing, or None."""
    return _current_event_area

_SPACE_CLS_MAP = {
    'VIEW_3D': 'SpaceView3D',
    'IMAGE_EDITOR': 'SpaceImageEditor',
    'NODE_EDITOR': 'SpaceNodeEditor',
    'PROPERTIES': 'SpaceProperties',
    'OUTLINER': 'SpaceOutliner',
    'PREFERENCES': 'SpacePreferences',
}


class UIPanel:
    """A GPU-rendered panel drawn in a Blender region."""

    def __init__(self, panel_id: str, space_type: str = 'VIEW_3D',
                 region_type: str = 'WINDOW',
                 position: tuple = (20, 20), fullscreen: bool = False):
        self.panel_id = panel_id
        self.space_type = space_type
        self.region_type = region_type
        self.position = position
        self.fullscreen = fullscreen
        self.root: Optional[Widget] = None
        self._draw_handler = None
        self._needs_layout = True
        self._registered = False
        self._last_region_w = 0
        self._last_region_h = 0

    def set_root(self, widget: Widget):
        self.root = widget
        self._needs_layout = True

    def register(self):
        if self._registered:
            return
        cls_name = _SPACE_CLS_MAP.get(self.space_type)
        space_cls = getattr(bpy.types, cls_name, None) if cls_name else None
        if not space_cls:
            print(f"[BGUI] Unknown space type: {self.space_type}")
            return
        self._draw_handler = space_cls.draw_handler_add(
            _draw_callback, (self,), self.region_type, 'POST_PIXEL')
        _active_panels[self.panel_id] = self
        self._registered = True

    def unregister(self):
        if not self._registered:
            return
        cls_name = _SPACE_CLS_MAP.get(self.space_type)
        space_cls = getattr(bpy.types, cls_name, None) if cls_name else None
        if space_cls and self._draw_handler:
            space_cls.draw_handler_remove(self._draw_handler, self.region_type)
        _active_panels.pop(self.panel_id, None)
        self._draw_handler = None
        self._registered = False

    def invalidate(self):
        self._needs_layout = True
        _tag_redraw(self.space_type)


def _draw_callback(panel: UIPanel):
    if _shutting_down or not panel.root:
        return
    try:
        region = bpy.context.region
        renderer = Renderer(region.height)
        if panel.fullscreen:
            rw, rh = region.width, region.height
            if rw != panel._last_region_w or rh != panel._last_region_h:
                panel.root.layout(Rect(0, 0, rw, rh))
                panel._last_region_w = rw
                panel._last_region_h = rh
        elif panel._needs_layout:
            x, y = panel.position
            w = panel.root.measure_width()
            h = panel.root.measure_height()
            panel.root.layout(Rect(x, y, w, h))
            panel._needs_layout = False
        panel.root.draw(renderer)
    except Exception:
        from .renderer import invalidate_shaders
        invalidate_shaders()


def _tag_redraw(space_type: str):
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == space_type:
                area.tag_redraw()


def _find_open_dropdown_scroll(widget, delta: float, mx: float, my: float) -> bool:
    """Priority pass: deliver scroll to open Dropdown overlays first."""
    from .widgets import Dropdown
    if not widget.visible:
        return False
    if isinstance(widget, Dropdown) and widget.open:
        if widget.handle_scroll(delta, mx, my):
            return True
    for child in widget.children:
        if _find_open_dropdown_scroll(child, delta, mx, my):
            return True
    return False


def _propagate_scroll(widget, delta: float, mx: float, my: float) -> bool:
    """Walk widget tree looking for scrollable widgets under cursor."""
    from .widgets import ScrollBox, ListView, DataList, TreeView
    # Priority: open dropdown overlays (drawn on top of everything)
    if _find_open_dropdown_scroll(widget, delta, mx, my):
        return True
    return _propagate_scroll_standard(widget, delta, mx, my)


def _propagate_scroll_standard(widget, delta: float, mx: float, my: float) -> bool:
    """Standard scroll propagation gated by rect containment."""
    from .widgets import ScrollBox, ListView, DataList, TreeView
    if not widget.visible or not widget.rect.contains(mx, my):
        return False
    for child in reversed(widget.children):
        if _propagate_scroll_standard(child, delta, mx, my):
            return True
    if isinstance(widget, (ScrollBox, ListView, DataList, TreeView)):
        return widget.handle_scroll(delta, mx, my)
    if hasattr(widget, 'handle_scroll'):
        return widget.handle_scroll(delta, mx, my)
    return False


def _propagate_key_event(widget, event) -> bool:
    """Walk widget tree looking for focused TextInput or widgets with handle_key_event."""
    from .widgets import TextInput
    if isinstance(widget, TextInput) and widget.focused:
        consumed = widget.handle_key_event(
            event.type,
            shift=event.shift,
            ctrl=event.ctrl,
            ascii_char=event.ascii,
        )
        if consumed:
            # Handle clipboard operations via Blender
            if event.ctrl and event.type == 'C':
                sel = widget.get_selection_text()
                if sel:
                    bpy.context.window_manager.clipboard = sel
            elif event.ctrl and event.type == 'X':
                sel = widget.get_selection_text()
                if sel:
                    bpy.context.window_manager.clipboard = sel
            elif event.ctrl and event.type == 'V':
                clip = bpy.context.window_manager.clipboard
                if clip:
                    widget.insert_text(clip)
        return consumed
    for child in widget.children:
        if _propagate_key_event(child, event):
            return True
    # Fallback: allow any non-TextInput widget with handle_key_event (e.g. builder root)
    if not isinstance(widget, TextInput) and hasattr(widget, 'handle_key_event'):
        return widget.handle_key_event(
            event.type, shift=event.shift, ctrl=event.ctrl, ascii_char=event.ascii)
    return False


def _propagate_right_click(widget, x: float, y: float) -> bool:
    """Walk widget tree looking for ContextMenu or widgets with on_right_click."""
    from .widgets import ContextMenu
    if not widget.visible or not widget.rect.contains(x, y):
        return False
    for child in reversed(widget.children):
        if _propagate_right_click(child, x, y):
            return True
    # Widget-level on_right_click callback
    cb = getattr(widget, 'on_right_click', None)
    if cb is not None:
        cb(x, y)
        return True
    # Show any ContextMenu that is a sibling (walk parent's children)
    if widget.parent:
        for sibling in widget.parent.children:
            if isinstance(sibling, ContextMenu) and not sibling.open:
                sibling.show(x, y)
                return True
    return False


def _dismiss_context_menus(widget) -> bool:
    """Walk widget tree and dismiss any open ContextMenus. Returns True if any were dismissed."""
    from .widgets import ContextMenu
    dismissed = False
    if isinstance(widget, ContextMenu) and widget.open:
        widget.dismiss()
        dismissed = True
    for child in widget.children:
        if _dismiss_context_menus(child):
            dismissed = True
    return dismissed


# -- Modal operator for mouse interaction --------------------

def _get_active_space_types() -> set:
    """Return the set of space types used by all registered panels/popups."""
    types = set()
    for p in _active_panels.values():
        types.add(p.space_type)
    for p in _sidebar_gpu_panels.values():
        types.add(p.space_type)
    for p in _modal_popups.values():
        types.add(p.space_type)
    return types


def _tag_redraw_all():
    """Tag redraw for all space types that have active panels."""
    for st in _get_active_space_types():
        _tag_redraw(st)


def _deferred_modal_start():
    """Timer callback to start the interaction modal in the correct context."""
    if _shutting_down:
        return None
    try:
        # Find any area that has registered panels
        target_types = _get_active_space_types() or {'VIEW_3D'}
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in target_types:
                    with bpy.context.temp_override(window=window, area=area):
                        bpy.ops.bgui.enable_interaction('INVOKE_DEFAULT')
                    return None
    except Exception as e:
        print(f"[BGUI] Modal start failed: {e}")
    return None


class BGUI_OT_enable_interaction(bpy.types.Operator):
    """Persistent modal that forwards mouse events to BGUI panels"""
    bl_idname = "bgui.enable_interaction"
    bl_label = "BGUI Interaction Handler"
    bl_options = {'INTERNAL'}

    def modal(self, context, event):
        if _shutting_down:
            return {'CANCELLED'}
        all_panels = (list(_active_panels.values())
                      + list(_sidebar_gpu_panels.values())
                      + list(_modal_popups.values()))
        if not all_panels:
            return {'CANCELLED'}

        # For sidebar/modal popups, find the UI region in the area that
        # actually contains the mouse cursor (not just the first match).
        global _current_event_area
        ui_region = None
        if _sidebar_gpu_panels or _modal_popups:
            target_types = set()
            for p in _sidebar_gpu_panels.values():
                target_types.add(p.space_type)
            for p in _modal_popups.values():
                target_types.add(p.space_type)
            _mx_abs = event.mouse_x
            _my_abs = event.mouse_y
            for area in context.screen.areas:
                if area.type in target_types:
                    if (area.x <= _mx_abs < area.x + area.width
                            and area.y <= _my_abs < area.y + area.height):
                        for reg in area.regions:
                            if reg.type == 'UI':
                                ui_region = reg
                                break
                        _current_event_area = area
                        break

            # Modal popups must dismiss on ESC / click-outside even when the
            # cursor is over a different editor (3D viewport, properties, etc).
            # If no area-under-cursor matched, fall back to any area that hosts
            # an active popup so events still reach the popup handler.
            if ui_region is None and _modal_popups:
                popup_types = {p.space_type for p in _modal_popups.values()}
                for area in context.screen.areas:
                    if area.type in popup_types:
                        for reg in area.regions:
                            if reg.type == 'UI':
                                ui_region = reg
                                break
                        if ui_region is not None:
                            _current_event_area = area
                            break

        consumed = False

        # Cache event properties once to avoid repeated RNA lookups
        # (unknown event type codes trigger a Blender warning per access)
        evt_type = event.type
        evt_value = event.value

        # -- Modal popups (highest priority � consume all events) --
        if _modal_popups and ui_region:
            local_x = event.mouse_x - ui_region.x
            local_y = event.mouse_y - ui_region.y
            mx = local_x
            my = ui_region.height - local_y

            for popup in list(_modal_popups.values()):
                root = popup.root
                if not root or not popup.visible:
                    continue

                if evt_type == 'MOUSEMOVE':
                    root.propagate_mouse_move(mx, my)
                    consumed = True

                elif evt_type in ('LEFTMOUSE', 'RIGHTMOUSE'):
                    if evt_value == 'PRESS':
                        # Click outside popup content ? dismiss
                        if root.rect and not root.rect.contains(mx, my):
                            if popup.on_dismiss:
                                popup.on_dismiss()
                            else:
                                popup.hide()
                        elif evt_type == 'LEFTMOUSE':
                            _handle_press_with_dropdown(root, mx, my)
                        consumed = True
                    elif evt_value == 'RELEASE':
                        if evt_type == 'LEFTMOUSE':
                            root.handle_mouse_release(mx, my)
                        consumed = True

                elif evt_type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
                    delta = -1 if evt_type == 'WHEELUPMOUSE' else 1
                    _propagate_scroll(root, delta, mx, my)
                    consumed = True  # block scrolling behind modal

                elif evt_value == 'PRESS':
                    # ESC closes popup when no widget handles it
                    if evt_type == 'ESC':
                        if not _propagate_key_event(root, event):
                            if popup.on_dismiss:
                                popup.on_dismiss()
                            else:
                                popup.hide()
                    else:
                        _propagate_key_event(root, event)
                    consumed = True  # Block all keys when popup visible

            if consumed:
                _tag_redraw_all()
                _current_event_area = None
                return {'RUNNING_MODAL'}

        # Process sidebar panels using absolute ? region-local conversion
        if ui_region and _sidebar_gpu_panels:
            # Convert absolute mouse coords to sidebar-local
            local_x = event.mouse_x - ui_region.x
            local_y = event.mouse_y - ui_region.y
            in_sidebar = (0 <= local_x < ui_region.width and
                          0 <= local_y < ui_region.height)

            if not in_sidebar:
                # Mouse left sidebar � clear tooltip state
                for panel in _sidebar_gpu_panels.values():
                    panel._last_mouse_x = None
                    panel._last_mouse_y = None

            if in_sidebar:
                mx = local_x
                my = ui_region.height - local_y  # flip Y to top-down

                # Re-layout for this region's dimensions.  The singleton
                # widget tree was laid out for whichever area drew last;
                # if this sidebar has different dimensions we must
                # re-layout so hit-test rects match the actual sidebar.
                from .core import ui_scale as _ui_sc, Rect as _Rect
                for panel in _sidebar_gpu_panels.values():
                    root = panel.root
                    if not root or not panel._tab_active:
                        continue
                    _sc = _ui_sc()
                    _pl = panel.pad_left
                    _pr = panel.pad_right
                    _ps = bpy.context.preferences.system.pixel_size
                    _ts = int(28 * _ps)
                    _w = ui_region.width - _pl - _pr - _ts
                    _nh = root.measure_height()
                    _mh = max(50 * _sc, ui_region.height - _pl * 2)
                    _h = min(_nh, _mh)
                    if _w != panel._last_width or _h != panel._last_height:
                        root.layout(_Rect(_pl, _pl, max(_w, 50 * _sc), _h))
                        panel._last_width = _w
                        panel._last_height = _h

                for panel in _sidebar_gpu_panels.values():
                    root = panel.root
                    if not root or not panel._tab_active:
                        continue

                    # Track mouse for tooltip rendering
                    panel._last_mouse_x = mx
                    panel._last_mouse_y = my

                    if evt_type == 'MOUSEMOVE':
                        root.propagate_mouse_move(mx, my)
                        if root.rect.contains(mx, my):
                            consumed = True

                    elif evt_type == 'LEFTMOUSE':
                        if evt_value == 'PRESS':
                            if root.hit_test(mx, my) or _find_open_dropdown(root):
                                _handle_press_with_dropdown(root, mx, my)
                                consumed = True
                        elif evt_value == 'RELEASE':
                            if root.handle_mouse_release(mx, my):
                                consumed = True

                    elif evt_type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
                        delta = -1 if evt_type == 'WHEELUPMOUSE' else 1
                        if _propagate_scroll(root, delta, mx, my):
                            consumed = True

                    elif evt_type == 'RIGHTMOUSE' and evt_value == 'PRESS':
                        _dismiss_context_menus(root)
                        if _propagate_right_click(root, mx, my):
                            consumed = True

        # Process sidebar panel keyboard events.
        # Focused TextInputs receive keys globally (typing shouldn't break
        # if the mouse drifts out of the sidebar).  All other key handlers
        # (e.g. strip copy/paste) only fire when the mouse is actually inside
        # the sidebar � otherwise Blender-wide shortcuts like Ctrl+C for
        # object duplication would be swallowed.
        if not consumed and _sidebar_gpu_panels:
            if evt_value == 'PRESS':
                from .widgets import TextInput as _TI
                _has_focused_text = _TI._focused_instance is not None
                _mouse_in_sidebar = False
                if not _has_focused_text and ui_region:
                    _lx = event.mouse_x - ui_region.x
                    _ly = event.mouse_y - ui_region.y
                    _mouse_in_sidebar = (0 <= _lx < ui_region.width
                                         and 0 <= _ly < ui_region.height)
                for panel in _sidebar_gpu_panels.values():
                    if panel.root and panel._tab_active:
                        if _has_focused_text or _mouse_in_sidebar:
                            if _propagate_key_event(panel.root, event):
                                consumed = True

        # Process regular (floating) panels
        if _active_panels:
            region = context.region
            if region is not None:
                mx = event.mouse_region_x
                my = region.height - event.mouse_region_y

                for panel in _active_panels.values():
                    root = panel.root
                    if not root:
                        continue

                    if evt_type == 'MOUSEMOVE':
                        root.propagate_mouse_move(mx, my)
                        if panel.fullscreen or root.rect.contains(mx, my):
                            consumed = True

                    elif evt_type == 'LEFTMOUSE':
                        if evt_value == 'PRESS':
                            if panel.fullscreen or root.hit_test(mx, my) or _find_open_dropdown(root):
                                _handle_press_with_dropdown(root, mx, my)
                                consumed = True
                        elif evt_value == 'RELEASE':
                            if root.handle_mouse_release(mx, my) or panel.fullscreen:
                                consumed = True

                    elif evt_type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
                        delta = -1 if evt_type == 'WHEELUPMOUSE' else 1
                        if _propagate_scroll(root, delta, mx, my):
                            consumed = True
                        elif panel.fullscreen:
                            consumed = True

                    elif evt_type == 'RIGHTMOUSE' and evt_value == 'PRESS':
                        _dismiss_context_menus(root)
                        if _propagate_right_click(root, mx, my):
                            consumed = True
                        elif panel.fullscreen:
                            consumed = True

                    elif evt_value == 'PRESS':
                        if _propagate_key_event(root, event):
                            consumed = True
                        elif panel.fullscreen:
                            consumed = True

        if consumed:
            _tag_redraw_all()
            _current_event_area = None
            return {'RUNNING_MODAL'}

        _current_event_area = None
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


def get_panel(panel_id: str) -> Optional[UIPanel]:
    return _active_panels.get(panel_id)


def cleanup_all():
    global _shutting_down
    _shutting_down = True
    for panel in list(_active_panels.values()):
        panel.unregister()
    # Also clean up sidebar GPU panels
    for panel in list(_sidebar_gpu_panels.values()):
        panel.unregister()
    _sidebar_gpu_panels.clear()
    # Clean up modal popups
    for popup in list(_modal_popups.values()):
        popup.destroy()
    _modal_popups.clear()
    # Reset animation state
    from .animation import reset as reset_anim
    reset_anim()


def _draw_tooltip(renderer, text: str, mx: float, my: float):
    """Draw a floating tooltip near the mouse position."""
    from .core import Rect, ui_scale
    sc = ui_scale()
    font_size = 11
    pad_h, pad_v = 8 * sc, 4 * sc
    tw, th = renderer.measure_text(text, font_size)
    tip_w = tw + pad_h * 2
    tip_h = th + pad_v * 2

    # Position: below and right of cursor, avoid going off-screen
    tx = mx + 12 * sc
    ty = my + 16 * sc
    # Clamp to visible area (rough estimate)
    if tx + tip_w > renderer.region_height * 2:  # wide enough
        tx = mx - tip_w - 4 * sc

    tip_rect = Rect(tx, ty, tip_w, tip_h)

    # Shadow
    renderer.draw_shadow(tip_rect, (0, 0, 0, 0.3), 6.0 * sc, (0, 2 * sc),
                         radius=3 * sc)
    # Background
    renderer.draw_rounded_rect(
        tip_rect, (0.10, 0.10, 0.12, 0.95), 3 * sc,
        border_color=(0.35, 0.35, 0.40, 0.6), border_width=1 * sc,
    )
    # Text
    renderer.draw_text(text, tx + pad_h, ty + pad_v, size=font_size,
                       color=(0.92, 0.92, 0.94, 1.0))


# -- ModalPopup � full-viewport modal overlay -----------------

_modal_popups: Dict[str, 'ModalPopup'] = {}


class ModalPopup:
    """A GPU-rendered modal popup drawn over the sidebar panel area.

    Displays a dim overlay covering the sidebar region and centers its
    root widget as a floating dialog card. Mouse events are consumed
    while the modal is visible.
    """

    def __init__(self, popup_id: str, dim_color=(0, 0, 0, 0.55),
                 space_type: str = 'VIEW_3D'):
        self.popup_id = popup_id
        self.root: Optional[Widget] = None
        self.dim_color = dim_color
        self.space_type = space_type
        self.on_dismiss = None  # callback for ESC / click-outside close
        self._draw_handler = None
        self._visible = False
        self._needs_layout = True
        self._anchor_top_y: Optional[float] = None  # top-anchored Y position
        self._drag_offset_x: float = 0.0
        self._drag_offset_y: float = 0.0
        self._last_pw: float = 0.0
        self._last_ph: float = 0.0

    def set_root(self, widget: Widget):
        self.root = widget

    @property
    def visible(self):
        return self._visible

    def show(self):
        if self._visible:
            return
        self._visible = True
        self._needs_layout = True
        self._anchor_top_y = None  # reset anchor on fresh show
        self._drag_offset_x = 0.0
        self._drag_offset_y = 0.0
        if self._draw_handler is None:
            cls_name = _SPACE_CLS_MAP.get(self.space_type, 'SpaceView3D')
            space_cls = getattr(bpy.types, cls_name)
            self._draw_handler = space_cls.draw_handler_add(
                ModalPopup._draw, (self,), 'UI', 'POST_PIXEL')
        _modal_popups[self.popup_id] = self
        _tag_redraw(self.space_type)

    def hide(self):
        if not self._visible:
            return
        self._visible = False
        if self._draw_handler:
            cls_name = _SPACE_CLS_MAP.get(self.space_type, 'SpaceView3D')
            space_cls = getattr(bpy.types, cls_name)
            space_cls.draw_handler_remove(self._draw_handler, 'UI')
            self._draw_handler = None
        _modal_popups.pop(self.popup_id, None)
        _tag_redraw(self.space_type)

    def destroy(self):
        self.hide()

    def invalidate(self):
        self._needs_layout = True
        _tag_redraw(self.space_type)

    @staticmethod
    def _draw(popup: 'ModalPopup'):
        if _shutting_down or not popup._visible or not popup.root:
            return
        region = bpy.context.region
        if region is None:
            return
        try:
            rw, rh = region.width, region.height
            renderer = Renderer(rh)
            from .core import (
                ui_scale as _sc,
                push_ui_scale_multiplier as _push_scale,
                pop_ui_scale_multiplier as _pop_scale,
                user_scale_factor_multiplier as _popup_user_scale_mult,
            )
            _s = _sc()
            margin = 16 * _s

            popup_scale_factor = 1.0
            try:
                addon_key = __package__.rsplit('.', 1)[0]
                prefs = bpy.context.preferences.addons[addon_key].preferences
                popup_scale_factor = getattr(prefs, 'popup_scale_factor', 1.0)
            except Exception:
                pass

            max_w = max(1.0, rw - margin)
            max_h = max(1.0, rh - margin)
            popup_pref_mult = _popup_user_scale_mult(popup_scale_factor)

            _push_scale(popup_pref_mult)
            try:
                base_pw = popup.root.measure_width()
                base_ph = popup.root.measure_height()
                fit_scale = 1.0
                if base_pw > 0 and base_ph > 0:
                    fit_scale = min(1.0, max_w / base_pw, max_h / base_ph)

                _push_scale(fit_scale)
                try:
                    pw = min(popup.root.measure_width(), max_w)
                    ph = min(popup.root.measure_height(), max_h)

                    size_changed = (pw != popup._last_pw or ph != popup._last_ph)
                    if popup._needs_layout or not popup.root.rect or size_changed:
                        px = max(0, (rw - pw) / 2)
                        if popup._anchor_top_y is None:
                            py = max(0, (rh - ph) / 2)
                            popup._anchor_top_y = py
                        else:
                            py = popup._anchor_top_y
                        px += popup._drag_offset_x
                        py += popup._drag_offset_y
                        # Clamp to region (popup can't escape sidebar bounds)
                        px = max(0, min(px, rw - pw))
                        py = max(0, min(py, rh - ph))
                        popup.root.layout(Rect(px, py, pw, ph))
                        popup._needs_layout = False
                        popup._last_pw = pw
                        popup._last_ph = ph

                    # Drop shadow behind popup card
                    r = popup.root.rect
                    if r:
                        fit_s = _sc()
                        renderer.draw_shadow(r, (0, 0, 0, 0.5), blur=24 * fit_s,
                                             offset=(0, 8 * fit_s), radius=12 * fit_s)

                    popup.root.draw(renderer)
                    renderer.flush_overlays()
                finally:
                    _pop_scale()
            finally:
                _pop_scale()
        except Exception:
            from .renderer import invalidate_shaders
            invalidate_shaders()


# -- SidebarGPUPanel � GPU rendering inside a native sidebar panel --

_sidebar_gpu_panels: Dict[str, 'SidebarGPUPanel'] = {}


def restart_interaction():
    """Reset modal state after file load so the interaction handler restarts."""
    global _shutting_down
    _shutting_down = False
    for panel in _sidebar_gpu_panels.values():
        panel._modal_started = False
        panel.invalidate()
    _tag_redraw_all()


class SidebarGPUPanel:
    """A GPU-rendered panel that lives in Blender's sidebar.

    Creates a native Panel (for scroll / collapse / sidebar integration)
    and renders custom GPU content inside its reserved area.

    Usage::

        panel = SidebarGPUPanel("my_panel", label="Colors", category="Tool",
                                space_type='IMAGE_EDITOR')
        panel.set_root(Column(children=[...]))
        panel.register()
    """

    def __init__(self, panel_id: str, label: str = "BGUI Panel",
                 category: str = 'BGUI', padding=8, height_fraction: float = 0.0,
                 space_type: str = 'VIEW_3D'):
        self.panel_id = panel_id
        self.label = label
        self.category = category
        self.height_fraction = height_fraction
        self.space_type = space_type
        # padding: int for symmetric, or (left, right) tuple
        if isinstance(padding, (list, tuple)):
            self.pad_left, self.pad_right = padding
        else:
            self.pad_left = self.pad_right = padding
        self.root: Optional[Widget] = None
        self._draw_handler = None
        self._spacer_class = None
        self._spacer_visible = False
        self._tab_active = False
        self._content_height = 100.0
        self._last_width = 0.0
        self._last_height = 0.0
        self._modal_started = False
        self._last_mouse_x: Optional[float] = None
        self._last_mouse_y: Optional[float] = None
        self._first_draw_pending = True

    def set_root(self, widget: Widget):
        self.root = widget
        if widget:
            self._content_height = widget.measure_height()
        self._first_draw_pending = True

    def register(self):
        if self._spacer_class is not None:
            return

        parent = self
        idname = f"BGUI_PT_gpu_{self.panel_id}"

        attrs = {
            'bl_idname': idname,
            'bl_label': parent.label,
            'bl_space_type': self.space_type,
            'bl_region_type': 'UI',
            'bl_category': parent.category,
            'draw': lambda self_bl, ctx: parent._on_spacer_draw(self_bl.layout, ctx),
        }

        panel_cls = type(idname, (bpy.types.Panel,), attrs)
        bpy.utils.register_class(panel_cls)
        self._spacer_class = panel_cls

        cls_name = _SPACE_CLS_MAP.get(self.space_type, 'SpaceView3D')
        space_cls = getattr(bpy.types, cls_name)
        self._draw_handler = space_cls.draw_handler_add(
            SidebarGPUPanel._on_gpu_draw, (parent,), 'UI', 'POST_PIXEL')

        _sidebar_gpu_panels[self.panel_id] = self

    def unregister(self):
        if self._draw_handler:
            cls_name = _SPACE_CLS_MAP.get(self.space_type, 'SpaceView3D')
            space_cls = getattr(bpy.types, cls_name)
            space_cls.draw_handler_remove(self._draw_handler, 'UI')
            self._draw_handler = None
        if self._spacer_class:
            try:
                bpy.utils.unregister_class(self._spacer_class)
            except RuntimeError:
                pass
            self._spacer_class = None
        _sidebar_gpu_panels.pop(self.panel_id, None)

    def invalidate(self):
        self._last_width = 0
        _tag_redraw(self.space_type)

    # -- Internal callbacks --

    def _on_spacer_draw(self, layout, context):
        """Called during layout phase � reserve minimal native panel space."""
        if _shutting_down:
            return
        self._spacer_visible = True
        self._tab_active = True
        if self.root:
            self._content_height = self.root.measure_height()
            # Minimal separator � GPU content draws over the native panel.
            layout.separator(factor=1.0)
        # Schedule modal start via timer (can't invoke operators during draw)
        if not self._modal_started:
            self._modal_started = True
            bpy.app.timers.register(_deferred_modal_start, first_interval=0.1)

    @staticmethod
    def _on_gpu_draw(panel: 'SidebarGPUPanel'):
        """POST_PIXEL handler � draw GPU content in the sidebar region."""
        if _shutting_down or not panel.root or not panel._spacer_visible:
            panel._tab_active = False
            return
        panel._spacer_visible = False

        region = bpy.context.region
        if region is None or region.width < 64:
            panel._tab_active = False
            return

        try:
            # Responsive layout � account for sidebar tab strip (~28px on right)
            from .core import ui_scale as _ui_scale
            sc = _ui_scale()
            pad_l = panel.pad_left
            pad_r = panel.pad_right
            pixel_size = bpy.context.preferences.system.pixel_size
            tab_strip = int(28 * pixel_size)
            w = region.width - pad_l - pad_r - tab_strip
            natural_h = panel.root.measure_height()
            max_h = max(50 * sc, region.height - pad_l * 2)
            h = min(natural_h, max_h)
            panel._content_height = natural_h
            needs_layout = (w != panel._last_width or h != panel._last_height
                            or panel._first_draw_pending)
            if needs_layout:
                panel.root.layout(Rect(pad_l, pad_l, max(w, 50 * sc), h))
                panel._last_width = w
                panel._last_height = h
                if panel._first_draw_pending:
                    panel._first_draw_pending = False
                    # Schedule a second layout pass so hit-test rects settle
                    panel.invalidate()

            renderer = Renderer(region.height)
            panel.root.draw(renderer)

            # Render tooltip overlay
            if panel._last_mouse_x is not None:
                tip_widget = panel.root.get_tooltip_widget(
                    panel._last_mouse_x, panel._last_mouse_y, delay=0.5)
                if tip_widget and tip_widget.tooltip:
                    _draw_tooltip(renderer, tip_widget.tooltip,
                                  panel._last_mouse_x, panel._last_mouse_y)

            renderer.flush_overlays()
        except Exception:
            from .renderer import invalidate_shaders
            invalidate_shaders()
