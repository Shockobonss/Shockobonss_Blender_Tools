# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""BGUI Theme System � design tokens, style presets, and Blender theme reading.

Provides:
- DesignTokens: centralized color/spacing/typography/radius constants
- StyleSheet: pre-built style presets (card, button, input, etc.)
- Theme: reads Blender's native theme colors
"""
from __future__ import annotations
from typing import Tuple

import bpy

Color = Tuple[float, float, float, float]


def _to_rgba(color, alpha: float = 1.0) -> Color:
    """Convert a Blender color (3 or 4 floats) to RGBA tuple."""
    if len(color) >= 4:
        return (color[0], color[1], color[2], color[3])
    return (color[0], color[1], color[2], alpha)


# -- Design Tokens --------------------------------------------

def _hex(h: str, alpha: float = 1.0) -> Color:
    """Convert '#RRGGBB' hex string to RGBA tuple (0-1 floats)."""
    h = h.lstrip('#')
    r, g, b = int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255
    return (r, g, b, alpha)


class _Colors:
    """Centralized color palette."""
    bg =             _hex('#29292E')
    surface =        _hex('#36363D')
    surface_light =  _hex('#42424D')
    surface_dark =   _hex('#212126')
    border =         _hex('#4D4D57', 0.6)
    border_light =   _hex('#595966', 0.5)

    text =           _hex('#DADADA')
    text_dim =       _hex('#8C8C99')
    text_muted =     _hex('#737380')

    accent =         _hex('#548CF2')
    accent_2 =       _hex('#9959EB')
    accent_hover =   _hex('#6699FF')
    accent_press =   _hex('#4073D9')

    error =          _hex('#D94D4D')
    error_hover =    _hex('#EB6161')
    success =        _hex('#4DBF66')
    warning =        _hex('#F2B31A')

    btn_bg =         _hex('#42424D')
    btn_hover =      _hex('#545461')
    btn_press =      _hex('#33333D')

    input_bg =       _hex('#1F1F24')
    overlay_bg =     _hex('#2E2E38', 0.98)

    tooltip_bg =     _hex('#1A1A1F', 0.95)
    tooltip_border = _hex('#595966', 0.6)

    transparent =    (0.0, 0.0, 0.0, 0.0)


class _Spacing:
    """Spacing scale (pixels)."""
    xxs = 1
    xs = 2
    sm = 4
    md = 8
    lg = 12
    xl = 16
    xxl = 24
    xxxl = 32


class _FontSize:
    """Typography scale."""
    xs = 12
    sm = 13
    md = 14
    lg = 17
    xl = 19
    xxl = 24
    xxxl = 34


class _Radius:
    """Border radius scale."""
    none = 0
    sm = 3
    md = 5
    lg = 8
    xl = 12
    pill = 999


class _Shadow:
    """Shadow presets as dicts (splat into Style kwargs)."""
    none = {'shadow_color': None, 'shadow_blur': 0.0, 'shadow_offset': (0, 0)}
    sm = {'shadow_color': (0, 0, 0, 0.15), 'shadow_blur': 3.0, 'shadow_offset': (0, 1)}
    md = {'shadow_color': (0, 0, 0, 0.25), 'shadow_blur': 6.0, 'shadow_offset': (0, 2)}
    lg = {'shadow_color': (0, 0, 0, 0.35), 'shadow_blur': 12.0, 'shadow_offset': (0, 4)}


class DesignTokens:
    """Centralized design tokens for consistent styling."""
    colors = _Colors
    spacing = _Spacing
    font = _FontSize
    radius = _Radius
    shadow = _Shadow


# Convenience alias
tokens = DesignTokens


# -- StyleSheet Presets ---------------------------------------

class StyleSheet:
    """Pre-built style presets. Import and use directly or compose with Style.merge().

    Usage::

        from bgui.theme import StyleSheet as SS
        btn = bgui.Button("Save", style=SS.button_primary())
        card = bgui.Column(style=SS.card(gap=8))
    """

    @staticmethod
    def card(**overrides):
        """Card container with background, border, subtle shadow."""
        from .core import Style, EdgeInsets
        base = dict(
            background_color=(0.18, 0.18, 0.20, 1.0),
            border_radius=_Radius.xl,
            padding=EdgeInsets.all(16),
            gap=8,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def panel(**overrides):
        """Root panel with dark background."""
        from .core import Style, EdgeInsets, SizePolicy
        base = dict(
            background_color=(0.098, 0.098, 0.11, 1.0),
            border_radius=_Radius.lg,
            border_color=_Colors.border,
            border_width=1,
            padding=EdgeInsets(14, 12, 14, 12),
            gap=0,
            width_policy=SizePolicy.FILL,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def button_primary(**overrides):
        """Primary accent button with shadow."""
        from .core import Style, EdgeInsets
        base = dict(
            background_color=(0.784, 1.0, 0.0, 1.0),
            border_radius=_Radius.lg,
            font_size=_FontSize.md,
            font_color=(0.098, 0.098, 0.11, 1.0),
            font_weight='semibold',
            padding=EdgeInsets(8, 20, 8, 20),
            hover_style={'background_color': (0.7, 0.9, 0.0, 1.0)},
            active_style={'background_color': (0.6, 0.8, 0.0, 1.0)},
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def button_secondary(**overrides):
        """Neutral secondary button."""
        from .core import Style, EdgeInsets
        base = dict(
            background_color=(0.3, 0.3, 0.35, 1.0),
            border_radius=_Radius.lg,
            font_size=_FontSize.md,
            font_color=(0.9, 0.9, 0.95, 1.0),
            font_weight='medium',
            padding=EdgeInsets(8, 20, 8, 20),
            hover_style={'background_color': (0.38, 0.38, 0.42, 1.0)},
            active_style={'background_color': (0.25, 0.25, 0.30, 1.0)},
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def button_danger(**overrides):
        """Destructive action button."""
        from .core import Style, EdgeInsets
        base = dict(
            background_color=_Colors.btn_bg,
            border_radius=_Radius.md,
            font_size=_FontSize.md,
            font_color=_Colors.error,
            padding=EdgeInsets(5, 10, 5, 10),
            hover_style={'background_color': (0.40, 0.22, 0.22, 1.0)},
            active_style={'background_color': _Colors.btn_press},
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def input_field(**overrides):
        """Text input field."""
        from .core import Style, EdgeInsets, SizePolicy
        base = dict(
            background_color=_hex('#1F1D1A'),
            border_color=_hex("#3A3A40"),
            border_width=1,
            border_radius=_Radius.lg,
            font_size=_FontSize.lg,
            font_color=_Colors.text,
            font_weight='semibold',
            padding=EdgeInsets(5, 20, 5, 8),
            height=34,
            width_policy=SizePolicy.FILL,
            inner_shadow_color=_hex('#000000', 0.25),
            inner_shadow_blur=10.7,
            inner_shadow_offset=(0.0, 0.0),
            inner_shadow_spread=0,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def label_dim(**overrides):
        """Dimmed label for section headers."""
        from .core import Style
        base = dict(
            font_size=_FontSize.sm,
            font_color=_Colors.text_dim,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def label_muted(**overrides):
        """Muted label for status text."""
        from .core import Style
        base = dict(
            font_size=_FontSize.xs,
            font_color=_Colors.text_muted,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def header_gradient(**overrides):
        """Gradient header bar."""
        from .core import Style, EdgeInsets, SizePolicy
        base = dict(
            background_color=_Colors.accent,
            background_color_2=_Colors.accent_2,
            gradient_angle=135.0,
            border_radius=_Radius.lg - 2,
            height=30,
            width_policy=SizePolicy.FILL,
            padding=EdgeInsets.symmetric(horizontal=10, vertical=5),
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def scroll_container(**overrides):
        """Scrollable container."""
        from .core import Style, EdgeInsets, SizePolicy
        base = dict(
            height=140,
            background_color=_Colors.surface_dark,
            border_radius=_Radius.md,
            border_color=(0.25, 0.25, 0.28, 0.4),
            border_width=1,
            padding=EdgeInsets.all(_Spacing.sm),
            width_policy=SizePolicy.FILL,
        )
        base.update(overrides)
        return Style(**base)

    @staticmethod
    def separator(**overrides):
        """Thin separator line."""
        return dict(color=(0.28, 0.28, 0.32, 0.3), **overrides)

    @staticmethod
    def tooltip(**overrides):
        """Tooltip popup style."""
        from .core import Style, EdgeInsets
        base = dict(
            background_color=_Colors.tooltip_bg,
            border_color=_Colors.tooltip_border,
            border_width=1,
            border_radius=_Radius.sm,
            padding=EdgeInsets(4, 8, 4, 8),
            font_size=_FontSize.sm,
            font_color=_Colors.text,
            **_Shadow.md,
        )
        base.update(overrides)
        return Style(**base)


# -- Blender Theme Reader ------------------------------------


class Theme:
    """Read-only snapshot of Blender's current theme colors.

    Usage::

        t = Theme()
        layout.box().label(text="Hello")
        # Use t.text for font color, t.panel_bg for background, etc.
    """

    def __init__(self):
        theme = bpy.context.preferences.themes[0]
        ui = theme.user_interface
        v3d = theme.view_3d
        space = v3d.space

        # -- Panel / Region colors ----------------------------
        self.panel_bg: Color = _to_rgba(space.back)
        self.header_bg: Color = _to_rgba(space.header)
        self.region_bg: Color = _to_rgba(space.panelcolors.back)

        # -- Text ---------------------------------------------
        self.text: Color = _to_rgba(ui.wcol_text.text_sel, 1.0)
        self.text_hi: Color = _to_rgba(space.header_text_hi)
        self.text_dim: Color = _to_rgba(space.header_text)

        # -- Widget colors ------------------------------------
        wcol_regular = ui.wcol_regular
        self.widget_inner: Color = _to_rgba(wcol_regular.inner)
        self.widget_inner_sel: Color = _to_rgba(wcol_regular.inner_sel)
        self.widget_outline: Color = _to_rgba(wcol_regular.outline)
        self.widget_text: Color = _to_rgba(wcol_regular.text)
        self.widget_text_sel: Color = _to_rgba(wcol_regular.text_sel)

        # -- Button/Tool colors -------------------------------
        wcol_tool = ui.wcol_tool
        self.button_inner: Color = _to_rgba(wcol_tool.inner)
        self.button_inner_sel: Color = _to_rgba(wcol_tool.inner_sel)
        self.button_text: Color = _to_rgba(wcol_tool.text)

        # -- Box colors ---------------------------------------
        wcol_box = ui.wcol_box
        self.box_inner: Color = _to_rgba(wcol_box.inner)
        self.box_outline: Color = _to_rgba(wcol_box.outline)

        # -- Accent / State -----------------------------------
        self.accent: Color = _to_rgba(space.object_active, 1.0)
        self.error: Color = (0.9, 0.2, 0.2, 1.0)
        self.warning: Color = (0.9, 0.7, 0.1, 1.0)
        self.success: Color = (0.2, 0.8, 0.2, 1.0)

        # -- Separator ----------------------------------------
        self.separator: Color = _to_rgba(space.grid)


# Cache a single Theme instance per draw cycle
_cached_theme: Theme | None = None


def get_theme() -> Theme:
    """Get the current Blender theme colors. Cached per session."""
    global _cached_theme
    if _cached_theme is None:
        _cached_theme = Theme()
    return _cached_theme


def invalidate_theme():
    """Clear the theme cache (call after theme changes)."""
    global _cached_theme
    _cached_theme = None
