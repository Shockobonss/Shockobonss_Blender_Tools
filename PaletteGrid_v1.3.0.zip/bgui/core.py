# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Core types for the BGUI framework."""
from __future__ import annotations
from typing import Optional, List, Callable, Tuple, Any, Dict
from enum import Enum, auto
import copy
import time

# Type alias
Color = Tuple[float, float, float, float]

# -- Blurrable widget registry ----------------------------
# Custom editable widgets register here when entering edit mode.
# _handle_press_with_dropdown calls blur_all_editing() on each mouse press.
_editing_widgets: set = set()


def register_editing(widget):
    """Register a widget that is currently in edit mode."""
    _editing_widgets.add(widget)


def unregister_editing(widget):
    """Unregister a widget that exited edit mode."""
    _editing_widgets.discard(widget)


def blur_all_editing():
    """Commit/cancel all editing widgets. Called before mouse press dispatch."""
    for w in list(_editing_widgets):
        if hasattr(w, 'blur'):
            w.blur()
    _editing_widgets.clear()


# -- DPI / HiDPI scaling ---------------------------------
_user_scale: float = 1.0
_ui_scale_multipliers: List[float] = []


def ui_scale() -> float:
    """Return the combined UI scale factor (system pixel_size � user pref).

    All spatial values in BGUI (padding, margin, gap, font sizes, etc.)
    are specified in *design pixels* and multiplied by this factor at
    layout and render time to produce physical pixels.
    """
    mult = 1.0
    for factor in _ui_scale_multipliers:
        mult *= factor
    try:
        import bpy
        return bpy.context.preferences.system.pixel_size * _user_scale * mult
    except Exception:
        return _user_scale * mult


def set_user_scale(value: float):
    """Set the user-controlled UI scale multiplier (default 1.0)."""
    global _user_scale
    _user_scale = max(0.25, min(value, 4.0))


def user_scale_factor_multiplier(factor: float) -> float:
    """Return a multiplier that attenuates only the addon user-scale component.

    `factor=1.0` keeps full user scaling.
    `factor=0.0` ignores the addon user scale and keeps only Blender DPI.
    """
    factor = max(0.0, min(factor, 1.0))
    if _user_scale <= 0:
        return 1.0
    adjusted_user_scale = 1.0 + (_user_scale - 1.0) * factor
    return adjusted_user_scale / _user_scale


def push_ui_scale_multiplier(value: float):
    """Temporarily multiply the effective UI scale for a subtree draw/layout pass."""
    _ui_scale_multipliers.append(max(0.01, value))


def pop_ui_scale_multiplier():
    """Pop the most recent temporary UI scale multiplier."""
    if _ui_scale_multipliers:
        _ui_scale_multipliers.pop()


def dp(value: float) -> float:
    """Convert a design-pixel value to physical pixels."""
    return value * ui_scale()


class SizePolicy(Enum):
    FIXED = auto()
    HUG = auto()
    FILL = auto()


class Alignment(Enum):
    START = auto()
    CENTER = auto()
    END = auto()
    STRETCH = auto()


class MainAxisAlignment(Enum):
    START = auto()
    CENTER = auto()
    END = auto()
    SPACE_BETWEEN = auto()
    SPACE_AROUND = auto()
    SPACE_EVENLY = auto()


class WidgetState(Enum):
    NORMAL = auto()
    HOVERED = auto()
    PRESSED = auto()
    DISABLED = auto()
    FOCUSED = auto()


class Rect:
    __slots__ = ('x', 'y', 'width', 'height')

    def __init__(self, x: float = 0, y: float = 0, width: float = 0, height: float = 0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def center_x(self) -> float:
        return self.x + self.width / 2

    @property
    def center_y(self) -> float:
        return self.y + self.height / 2

    def contains(self, px: float, py: float) -> bool:
        return self.x <= px < self.right and self.y <= py < self.bottom

    def inset(self, top: float = 0, right: float = 0,
              bottom: float = 0, left: float = 0) -> Rect:
        return Rect(
            self.x + left, self.y + top,
            max(0, self.width - left - right),
            max(0, self.height - top - bottom),
        )

    def __repr__(self):
        return f"Rect({self.x:.0f}, {self.y:.0f}, {self.width:.0f}, {self.height:.0f})"


class EdgeInsets:
    __slots__ = ('top', 'right', 'bottom', 'left')

    def __init__(self, top: float = 0, right: float = 0,
                 bottom: float = 0, left: float = 0):
        self.top = top
        self.right = right
        self.bottom = bottom
        self.left = left

    @classmethod
    def all(cls, value: float) -> EdgeInsets:
        return cls(value, value, value, value)

    @classmethod
    def symmetric(cls, horizontal: float = 0, vertical: float = 0) -> EdgeInsets:
        return cls(vertical, horizontal, vertical, horizontal)

    @property
    def horizontal(self) -> float:
        return self.left + self.right

    @property
    def vertical(self) -> float:
        return self.top + self.bottom


class Style:
    """Visual and layout style for a widget.

    Supports both GPU rendering properties AND native UILayout hints.
    """

    def __init__(self, **kwargs):
        # -- Sizing -------------------------------------------
        self.width: Optional[float] = kwargs.get('width')
        self.height: Optional[float] = kwargs.get('height')
        self.min_width: Optional[float] = kwargs.get('min_width')
        self.min_height: Optional[float] = kwargs.get('min_height')
        self.max_width: Optional[float] = kwargs.get('max_width')
        self.max_height: Optional[float] = kwargs.get('max_height')
        self.width_policy: SizePolicy = kwargs.get('width_policy', SizePolicy.HUG)
        self.height_policy: SizePolicy = kwargs.get('height_policy', SizePolicy.HUG)
        self.flex: float = kwargs.get('flex', 0.0)

        # -- Spacing ------------------------------------------
        self.padding: Optional[EdgeInsets] = kwargs.get('padding')
        self.margin: Optional[EdgeInsets] = kwargs.get('margin')
        self.gap: float = kwargs.get('gap', 0.0)

        # -- Background (GPU mode) ---------------------------
        self.background_color: Optional[Color] = kwargs.get('background_color')
        self.background_color_2: Optional[Color] = kwargs.get('background_color_2')
        self.background_color_3: Optional[Color] = kwargs.get('background_color_3')
        self.gradient_angle: float = kwargs.get('gradient_angle', 0.0)  # degrees

        # -- Border (GPU mode) --------------------------------
        self.border_color: Optional[Color] = kwargs.get('border_color')
        self.border_color_2: Optional[Color] = kwargs.get('border_color_2')
        self.border_gradient_angle: float = kwargs.get('border_gradient_angle', 0.0)
        self.border_width: float = kwargs.get('border_width', 0.0)
        self.border_radius: float = kwargs.get('border_radius', 0.0)
        # Per-corner radii (override border_radius when set).
        # Order: top-left, top-right, bottom-right, bottom-left (CSS order).
        self.border_radius_tl: Optional[float] = kwargs.get('border_radius_tl')
        self.border_radius_tr: Optional[float] = kwargs.get('border_radius_tr')
        self.border_radius_br: Optional[float] = kwargs.get('border_radius_br')
        self.border_radius_bl: Optional[float] = kwargs.get('border_radius_bl')

        # -- Text ---------------------------------------------
        self.font_size: float = kwargs.get('font_size', 14.0)
        self.font_color: Color = kwargs.get('font_color', (1.0, 1.0, 1.0, 1.0))
        self.font_weight: Optional[str] = kwargs.get('font_weight', 'regular')  # e.g. 'bold', 'light'

        # -- Box Shadow (GPU mode) ----------------------------
        self.shadow_color: Optional[Color] = kwargs.get('shadow_color')
        self.shadow_blur: float = kwargs.get('shadow_blur', 0.0)
        self.shadow_offset: Tuple[float, float] = kwargs.get('shadow_offset', (0.0, 0.0))

        # -- Inner Shadow (GPU mode) -------------------------
        # Matches Affinity Designer: Radius(blur), Offset, Intensity(spread), Colour+Opacity
        self.inner_shadow_color: Optional[Color] = kwargs.get('inner_shadow_color')
        self.inner_shadow_blur: float = kwargs.get('inner_shadow_blur', 0.0)        # Radius � size+softness
        self.inner_shadow_offset: Tuple[float, float] = kwargs.get('inner_shadow_offset', (0.0, 0.0))
        self.inner_shadow_spread: float = kwargs.get('inner_shadow_spread', 0.0)   # Intensity � choke

        # -- Overflow / Clipping ------------------------------
        self.clip_children: bool = kwargs.get('clip_children', False)
        self.passive: bool = kwargs.get('passive', False)

        # -- Layout -------------------------------------------
        self.alignment: Alignment = kwargs.get('alignment', Alignment.START)
        self.main_alignment: MainAxisAlignment = kwargs.get(
            'main_alignment', MainAxisAlignment.START)

        # -- Opacity ------------------------------------------
        self.opacity: float = kwargs.get('opacity', 1.0)

        # -- UILayout Hints (native mode) ---------------------
        self.scale_y: float = kwargs.get('scale_y', 1.0)
        self.emboss: bool = kwargs.get('emboss', True)
        self.alert: bool = kwargs.get('alert', False)
        self.enabled: bool = kwargs.get('enabled', True)
        self.icon: str = kwargs.get('icon', '')         # Blender icon name
        self.icon_value: int = kwargs.get('icon_value', 0)  # Custom icon id
        self.use_box: bool = kwargs.get('use_box', False)   # Wrap in box()
        self.align: bool = kwargs.get('align', True)        # align=True for columns/rows

        # -- State-dependent overrides ------------------------
        self.hover_style: Optional[Dict[str, Any]] = kwargs.get('hover_style')
        self.active_style: Optional[Dict[str, Any]] = kwargs.get('active_style')
        self.disabled_style: Optional[Dict[str, Any]] = kwargs.get('disabled_style')

    def get_effective(self, state: WidgetState) -> Style:
        overrides = None
        if state == WidgetState.HOVERED and self.hover_style:
            overrides = self.hover_style
        elif state == WidgetState.PRESSED and self.active_style:
            overrides = self.active_style
        elif state == WidgetState.DISABLED and self.disabled_style:
            overrides = self.disabled_style
        if not overrides:
            return self
        new = copy.copy(self)
        for key, value in overrides.items():
            if hasattr(new, key):
                setattr(new, key, value)
        return new

    @staticmethod
    def merge(*styles) -> Style:
        """Merge multiple styles. Later styles override earlier non-None values.

        Accepts Style objects or dicts::

            Style.merge(base_style, {'background_color': (1,0,0,1)}, override_style)
        """
        result = Style()
        for s in styles:
            if s is None:
                continue
            items = s.items() if isinstance(s, dict) else vars(s).items()
            for k, v in items:
                if v is not None and hasattr(result, k):
                    setattr(result, k, v)
        return result

    def get_radii(self) -> tuple:
        """Return per-corner radii as (tl, tr, br, bl).

        Falls back to self.border_radius when a corner is not explicitly set.
        """
        r = self.border_radius
        tl = self.border_radius_tl if self.border_radius_tl is not None else r
        tr = self.border_radius_tr if self.border_radius_tr is not None else r
        br = self.border_radius_br if self.border_radius_br is not None else r
        bl = self.border_radius_bl if self.border_radius_bl is not None else r
        return (tl, tr, br, bl)


class Widget:
    """Base class for all UI widgets."""

    def __init__(self, style: Optional[Style] = None,
                 children: Optional[List[Widget]] = None,
                 on_click: Optional[Callable] = None,
                 on_hover: Optional[Callable] = None,
                 on_hover_exit: Optional[Callable] = None,
                 visible: bool = True,
                 tooltip: Optional[str] = None,
                 widget_id: Optional[str] = None):
        self.style = style or Style()
        self.children: List[Widget] = []
        self.parent: Optional[Widget] = None
        self.rect = Rect()
        self.content_rect = Rect()
        self.state = WidgetState.NORMAL
        self.visible = visible
        self.tooltip = tooltip
        self.widget_id = widget_id

        self.on_click = on_click
        self.on_hover = on_hover
        self.on_hover_exit = on_hover_exit

        # Smooth transitions
        self._transitions: Dict[str, Tuple] = {}  # prop -> (start, end, t0, dur)

        # Tooltip hover tracking
        self._hover_start: float = 0.0

        if children:
            for child in children:
                self.add_child(child)

    def add_child(self, child: Widget) -> Widget:
        child.parent = self
        self.children.append(child)
        return child

    def remove_child(self, child: Widget):
        if child in self.children:
            child.parent = None
            self.children.remove(child)

    def clear_children(self):
        for child in self.children:
            child.parent = None
        self.children.clear()

    def find_by_id(self, wid: str) -> Optional[Widget]:
        if self.widget_id == wid:
            return self
        for child in self.children:
            found = child.find_by_id(wid)
            if found:
                return found
        return None

    # -- Measurement ------------------------------------------

    def measure_width(self) -> float:
        s = self.style
        sc = ui_scale()
        if s.width is not None:
            return s.width * sc
        content = self._measure_content_width()
        pad = (s.padding.horizontal * sc) if s.padding else 0
        w = content + pad
        if s.min_width is not None:
            w = max(w, s.min_width * sc)
        if s.max_width is not None:
            w = min(w, s.max_width * sc)
        return w

    def measure_height(self) -> float:
        s = self.style
        sc = ui_scale()
        if s.height is not None:
            return s.height * sc
        content = self._measure_content_height()
        pad = (s.padding.vertical * sc) if s.padding else 0
        h = content + pad
        if s.min_height is not None:
            h = max(h, s.min_height * sc)
        if s.max_height is not None:
            h = min(h, s.max_height * sc)
        return h

    def _measure_content_width(self) -> float:
        return 0.0

    def _measure_content_height(self) -> float:
        return 0.0

    # -- Layout -----------------------------------------------

    def layout(self, available: Rect):
        self.rect = self._compute_rect(available)
        pad = self.style.padding or EdgeInsets()
        sc = ui_scale()
        self.content_rect = self.rect.inset(
            pad.top * sc, pad.right * sc, pad.bottom * sc, pad.left * sc)
        self._layout_children()

    def _compute_rect(self, available: Rect) -> Rect:
        s = self.style
        sc = ui_scale()
        margin = s.margin or EdgeInsets()
        x = available.x + margin.left * sc
        y = available.y + margin.top * sc
        avail_w = available.width - margin.horizontal * sc
        avail_h = available.height - margin.vertical * sc

        if s.width is not None:
            w = s.width * sc
        elif s.width_policy == SizePolicy.FILL:
            w = avail_w
        else:
            w = self.measure_width()

        if s.height is not None:
            h = s.height * sc
        elif s.height_policy == SizePolicy.FILL:
            h = avail_h
        else:
            h = self.measure_height()

        if s.min_width is not None:
            w = max(w, s.min_width * sc)
        if s.max_width is not None:
            w = min(w, s.max_width * sc)
        if s.min_height is not None:
            h = max(h, s.min_height * sc)
        if s.max_height is not None:
            h = min(h, s.max_height * sc)

        return Rect(x, y, w, h)

    def _layout_children(self):
        pass

    # -- Drawing ----------------------------------------------

    def draw(self, renderer):
        if not self.visible:
            return
        eff = self.style.get_effective(self.state)
        # Apply smooth transitions
        if self._transitions:
            eff = copy.copy(eff)
            self._apply_transitions(eff)
        self._draw_background(renderer, eff)
        self._draw_content(renderer, eff)
        self._draw_children(renderer)

    def _draw_background(self, renderer, style: Style):
        sc = ui_scale()
        # Shadow (drawn before fill)
        if style.shadow_color and style.shadow_blur > 0:
            so = style.shadow_offset
            renderer.draw_shadow(
                self.rect, style.shadow_color,
                style.shadow_blur * sc,
                (so[0] * sc, so[1] * sc) if so else (0, 0),
                radius=style.border_radius * sc,
            )

        bg = style.background_color
        if not bg:
            return

        has_inner_shadow = (style.inner_shadow_color
                            and style.inner_shadow_blur > 0)

        radii = style.get_radii()
        scaled_radii = tuple(r * sc for r in radii)
        has_radius = any(r > 0 for r in radii)

        if has_radius:
            renderer.draw_rounded_rect(
                self.rect, bg, scaled_radii,
                border_color=style.border_color,
                border_width=style.border_width * sc,
                color2=style.background_color_2,
                gradient_angle=style.gradient_angle,
                border_color2=style.border_color_2,
                border_gradient_angle=style.border_gradient_angle,
                opacity=style.opacity,
                color3=style.background_color_3,
            )
        else:
            if style.background_color_2:
                renderer.draw_gradient_rect(
                    self.rect, bg, style.background_color_2)
            else:
                renderer.draw_rect(self.rect, bg)
            if style.border_color and style.border_width > 0:
                renderer.draw_rect_outline(self.rect, style.border_color,
                                           style.border_width * sc)

        # Inner shadow (drawn after fill+border, clips behind border)
        if has_inner_shadow:
            bw = (style.border_width * sc) if style.border_color else 0
            iso = style.inner_shadow_offset
            renderer.draw_inner_shadow(
                self.rect, style.inner_shadow_color,
                style.inner_shadow_blur * sc,
                (iso[0] * sc, iso[1] * sc) if iso else (0, 0),
                radius=style.border_radius * sc,
                spread=(style.inner_shadow_spread * sc
                        if style.inner_shadow_spread else 0),
                border_inset=bw,
            )

    def _draw_content(self, renderer, style: Style):
        pass

    def _draw_children(self, renderer):
        if self.style.clip_children:
            renderer.push_clip(self.rect)
        for child in self.children:
            child.draw(renderer)
        if self.style.clip_children:
            renderer.pop_clip()

    # -- Events -----------------------------------------------

    def hit_test(self, x: float, y: float) -> Optional[Widget]:
        if not self.visible or not self.rect.contains(x, y):
            return None
        for child in reversed(self.children):
            hit = child.hit_test(x, y)
            if hit:
                return hit
        return self

    def propagate_mouse_move(self, x: float, y: float):
        inside = self.rect.contains(x, y)
        if inside and self.state == WidgetState.NORMAL:
            self.state = WidgetState.HOVERED
            self._hover_start = time.monotonic()
            self._animate_state_change()
            if self.on_hover:
                self.on_hover(self)
        elif not inside and self.state == WidgetState.HOVERED:
            self.state = WidgetState.NORMAL
            self._hover_start = 0.0
            self._animate_state_change()
            if self.on_hover_exit:
                self.on_hover_exit(self)
        for child in self.children:
            child.propagate_mouse_move(x, y)

    def handle_mouse_press(self, x: float, y: float) -> bool:
        if not self.visible or not self.rect.contains(x, y):
            return False
        for child in reversed(self.children):
            if child.handle_mouse_press(x, y):
                return True
        self.state = WidgetState.PRESSED
        self._animate_state_change()
        return True

    def handle_mouse_release(self, x: float, y: float) -> bool:
        was_pressed = self.state == WidgetState.PRESSED
        if was_pressed:
            inside = self.rect.contains(x, y)
            self.state = WidgetState.HOVERED if inside else WidgetState.NORMAL
            self._animate_state_change()
            if inside and self.on_click:
                self.on_click(self)
            return True
        for child in self.children:
            if child.handle_mouse_release(x, y):
                return True
        return False

    # -- Smooth Transitions -----------------------------------

    def _transition_to(self, prop: str, end_value, duration: float = 0.12):
        """Start a smooth transition for a visual property."""
        from .animation import request_anim, release_anim, ease_out_cubic, lerp_color

        # Get current visual value (from active transition or base style)
        existing = self._transitions.get(prop)
        if existing is not None:
            start, end, t0, dur = existing
            elapsed = time.monotonic() - t0
            t = min(1.0, elapsed / max(0.001, dur))
            t = 1.0 - (1.0 - t) ** 3  # ease_out_cubic
            if isinstance(start, (tuple, list)):
                current = lerp_color(start, end, t)
            else:
                current = start + (end - start) * t
            release_anim()
        else:
            current = getattr(self.style, prop, None)

        if current is None or current == end_value:
            return

        self._transitions[prop] = (current, end_value, time.monotonic(), duration)
        request_anim()

    def _apply_transitions(self, eff: Style):
        """Apply active transition values to the effective style. Mutates eff."""
        from .animation import release_anim, ease_out_cubic, lerp_color, lerp_float

        now = time.monotonic()
        done = []
        for prop, (start, end, t0, dur) in self._transitions.items():
            elapsed = now - t0
            if elapsed >= dur:
                setattr(eff, prop, end)
                done.append(prop)
            else:
                t = 1.0 - (1.0 - elapsed / max(0.001, dur)) ** 3
                if isinstance(start, (tuple, list)):
                    setattr(eff, prop, lerp_color(start, end, t))
                else:
                    setattr(eff, prop, lerp_float(start, end, t))

        for prop in done:
            del self._transitions[prop]
            release_anim()

    def _animate_state_change(self):
        """Trigger smooth transitions when widget state changes."""
        target = self.style.get_effective(self.state)
        base = self.style

        # Animate background color
        if target.background_color and target.background_color != base.background_color:
            self._transition_to('background_color', target.background_color, 0.12)
        elif self.state == WidgetState.NORMAL and base.background_color and self._transitions.get('background_color'):
            self._transition_to('background_color', base.background_color, 0.15)

        # Animate border color
        if target.border_color and target.border_color != base.border_color:
            self._transition_to('border_color', target.border_color, 0.12)
        elif self.state == WidgetState.NORMAL and base.border_color and self._transitions.get('border_color'):
            self._transition_to('border_color', base.border_color, 0.15)

    # -- Tooltip ----------------------------------------------

    def get_tooltip_widget(self, x: float, y: float, delay: float = 0.5) -> Optional[Widget]:
        """Find the deepest widget under (x,y) that has a tooltip and has been hovered long enough."""
        if not self.visible or not self.rect.contains(x, y):
            return None
        for child in reversed(self.children):
            found = child.get_tooltip_widget(x, y, delay)
            if found:
                return found
        if self.tooltip and self._hover_start > 0:
            if time.monotonic() - self._hover_start >= delay:
                return self
        return None
