# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""BGUI � Blender GUI Framework.

Declarative UI framework for Blender addons using native UILayout.
Optional GPU rendering layer for custom visuals.
Zero external dependencies.
"""
import bpy

# -- Core types -----------------------------------------------
from .core import (
    Widget, Style, Rect, EdgeInsets, Color,
    SizePolicy, Alignment, MainAxisAlignment, WidgetState,
    ui_scale, set_user_scale, dp,
)

# -- Containers -----------------------------------------------
from .containers import Column, Row, Grid, Box, Spacer

# -- Widgets --------------------------------------------------
from .widgets import (
    Label, Button, Separator, ColorSwatch,
    Section, IconButton, Header, Toggle, ToggleSwitch, RadioGroup, SegmentedControl, PropertyRow, ImagePreview,
    ScrollBox, TextInput, Slider, Dropdown, ColorPicker,
    ContextMenu, ImageWidget, ListView, DataList, TreeView, TreeNode,
    load_ui_image, UIImage, _png_cache,
)

# -- Animation ------------------------------------------------
from .animation import (
    Tween, TweenManager,
    ease_out_cubic, ease_in_out_cubic, ease_out_quad, ease_out_back, ease_out_expo,
    lerp_float, lerp_color,
)

# -- Native UILayout rendering (optional) ---------------------
def _load_native_symbols():
    try:
        import importlib
        mod = importlib.import_module(f"{__package__}.native")
        return mod.NativePanel, mod.BGUI_OT_callback, mod.render, mod.cleanup_native, True
    except Exception:
        def _noop(*a, **kw):
            pass
        return None, None, _noop, _noop, False


NativePanel, BGUI_OT_callback, render, cleanup_native, _has_native = _load_native_symbols()

# -- Icon system ----------------------------------------------
from .icons import (
    load_icons_from_directory, get_icon, color_icon, gradient_icon,
    cleanup as cleanup_icons,
)


def get_blender_icon(*a, **kw):
    try:
        import importlib
        mod = importlib.import_module(f"{__package__}.blender_icons")
        return mod.get_blender_icon(*a, **kw)
    except Exception:
        return None

# -- Theme system ---------------------------------------------
from .theme import (
    Theme, get_theme, invalidate_theme,
    DesignTokens, tokens, StyleSheet,
)

# -- Font system ----------------------------------------------
from . import fonts

# -- GPU rendering (optional) --------------------------------
from .panel import UIPanel, ModalPopup, BGUI_OT_enable_interaction, get_panel, cleanup_all as cleanup_gpu
from .renderer import Renderer, invalidate_shaders

# -- Legacy sidebar (kept for backward compat) ---------------
try:
    from .sidebar import SidebarPanel, cleanup_sidebar
except ImportError:
    SidebarPanel = None
    def cleanup_sidebar(): pass
from .panel import SidebarGPUPanel

__all__ = [
    # Core
    'Widget', 'Style', 'Rect', 'EdgeInsets', 'Color',
    'SizePolicy', 'Alignment', 'MainAxisAlignment', 'WidgetState',
    # Containers
    'Column', 'Row', 'Grid', 'Box', 'Spacer',
    # Widgets
    'Label', 'Button', 'Separator', 'ColorSwatch',
    'Section', 'IconButton', 'Header', 'Toggle', 'ToggleSwitch', 'RadioGroup', 'SegmentedControl', 'PropertyRow', 'ImagePreview',
    'ScrollBox', 'TextInput', 'Slider', 'Dropdown', 'ColorPicker',
    'ContextMenu', 'ImageWidget', 'ListView', 'DataList', 'TreeView', 'TreeNode',
    # Animation
    'Tween', 'TweenManager',
    'ease_out_cubic', 'ease_in_out_cubic', 'ease_out_quad',
    'ease_out_back', 'ease_out_expo', 'lerp_float', 'lerp_color',
    # Native panels (primary)
    'NativePanel', 'render', 'cleanup_native',
    # Icons
    'load_icons_from_directory', 'get_icon', 'color_icon', 'gradient_icon',
    # Theme
    'Theme', 'get_theme', 'invalidate_theme',
    'DesignTokens', 'tokens', 'StyleSheet',
    # GPU (optional)
    'UIPanel', 'ModalPopup', 'get_panel', 'cleanup_gpu',
    'Renderer', 'invalidate_shaders',
    # Legacy
    'SidebarPanel', 'SidebarGPUPanel', 'cleanup_sidebar',
]

_classes = [c for c in [
    BGUI_OT_callback,
    BGUI_OT_enable_interaction,
] if c is not None]


def register():
    invalidate_shaders()
    # Reset shutdown flag so draw callbacks work again after re-enable
    from . import panel as _panel_mod
    _panel_mod._shutting_down = False
    for cls in _classes:
        bpy.utils.register_class(cls)
    # Defer legacy cleanup � bpy.data unavailable during register()
    if not bpy.app.timers.is_registered(_cleanup_legacy_images):
        bpy.app.timers.register(_cleanup_legacy_images, first_interval=0.5)


def _cleanup_legacy_images():
    """Remove any bpy.data.images created by old bgui versions (before GPU-only textures)."""
    import bpy
    try:
        prefixes = ('.bgui_svg_', 'bgui_svg_', '.bgui_preview_',
                    '.color_strips.png', '.hue_strip.png',
                    '.paintbrush_icon.png', '.plus_icon.png', '.import_icon.png',
                    '.TransparencySliderFillImageBackground.png',
                    'color_strips.png', 'hue_strip.png',
                    'paintbrush_icon.png', 'plus_icon.png', 'import_icon.png',
                    'TransparencySliderFillImageBackground.png')
        to_remove = [img for img in bpy.data.images
                     if any(img.name.startswith(p) or img.name == p for p in prefixes)]
        for img in to_remove:
            bpy.data.images.remove(img)
    except Exception:
        pass  # bpy.data may still be restricted


def unregister():
    # Cancel any pending timers first
    try:
        if bpy.app.timers.is_registered(_cleanup_legacy_images):
            bpy.app.timers.unregister(_cleanup_legacy_images)
    except Exception:
        pass
    cleanup_native()
    cleanup_gpu()
    cleanup_sidebar()
    cleanup_icons()
    # Clear GPU texture caches
    _png_cache.clear()
    from .svg import _svg_cache
    _svg_cache.clear()
    try:
        import importlib
        mod = importlib.import_module(f"{__package__}.blender_icons")
        mod.clear_cache()
    except Exception:
        pass
    invalidate_shaders()
    invalidate_theme()
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
