# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""GPU-based renderer for drawing UI primitives.

SDF-based rendering via gpu.shader.create_from_info() for high-quality:
- Anti-aliased rounded rectangles
- Linear gradients with arbitrary angle
- Box shadows with blur
- Borders

Falls back to tessellated rendering if custom shaders aren't available.
"""
from __future__ import annotations
from typing import Tuple, Optional, List
import math
import gpu
from gpu_extras.batch import batch_for_shader
import blf
from .core import Rect, Color, ui_scale
from . import fonts as _fonts

# -- Shader cache ---------------------------------------------

_flat_shader = None
_smooth_shader = None
_sdf_shader = None
_shadow_shader = None
_inner_shadow_shader = None
_tex_sdf_shader = None
_gradient_shader = None
_sdf_available = None  # None = untested, True/False after test


def _get_flat_shader():
    global _flat_shader
    if _flat_shader is None:
        _flat_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    return _flat_shader


def _get_smooth_shader():
    global _smooth_shader
    if _smooth_shader is None:
        _smooth_shader = gpu.shader.from_builtin('SMOOTH_COLOR')
    return _smooth_shader


def _try_create_sdf_shader():
    """Create SDF rounded-rect shader via create_from_info(). Returns shader or None."""
    global _sdf_available
    try:
        info = gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_in(1, 'VEC2', "uv")
        info.vertex_in(2, 'VEC4', "a_fill_color")
        info.vertex_in(3, 'VEC4', "a_fill_color_2")
        info.vertex_in(4, 'VEC4', "a_border_color")
        info.vertex_in(5, 'VEC4', "a_params")   # rect_w, rect_h, border_width, unused
        info.vertex_in(6, 'VEC2', "a_params2")  # gradient_angle, opacity
        info.vertex_in(7, 'VEC4', "a_fill_color_3")  # 3rd gradient stop (mid)
        info.vertex_in(8, 'VEC4', "a_border_color_2")  # border gradient end
        info.vertex_in(9, 'VEC2', "a_params3")  # border_gradient_angle, unused
        info.vertex_in(10, 'VEC4', "a_radii")   # per-corner: tl, tr, br, bl

        iface = gpu.types.GPUStageInterfaceInfo("bgui_sdf_iface")
        iface.smooth('VEC2', "v_uv")
        iface.flat('VEC4', "v_fill_color")
        iface.flat('VEC4', "v_fill_color_2")
        iface.flat('VEC4', "v_fill_color_3")
        iface.flat('VEC4', "v_border_color")
        iface.flat('VEC4', "v_border_color_2")
        iface.flat('VEC4', "v_params")
        iface.flat('VEC2', "v_params2")
        iface.flat('VEC2', "v_params3")
        iface.flat('VEC4', "v_radii")
        info.vertex_out(iface)

        info.fragment_out(0, 'VEC4', "fragColor")

        info.push_constant('MAT4', "ModelViewProjectionMatrix")

        info.vertex_source(
            "void main() {\n"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);\n"
            "  v_uv = uv;\n"
            "  v_fill_color = a_fill_color;\n"
            "  v_fill_color_2 = a_fill_color_2;\n"
            "  v_fill_color_3 = a_fill_color_3;\n"
            "  v_border_color = a_border_color;\n"
            "  v_border_color_2 = a_border_color_2;\n"
            "  v_params = a_params;\n"
            "  v_params2 = a_params2;\n"
            "  v_params3 = a_params3;\n"
            "  v_radii = a_radii;\n"
            "}\n"
        )

        info.fragment_source(
            # Per-corner SDF: picks the right radius based on which quadrant p is in.
            # Radii order: tl=.x, tr=.y, br=.z, bl=.w  (matches CSS top-left clockwise)
            # In widget-space: y=0 is top, y=height is bottom.
            # For SDF we work centered (p = pos - center), so:
            #   p.x < 0, p.y > 0 ? top-left
            #   p.x >= 0, p.y > 0 ? top-right
            #   p.x >= 0, p.y <= 0 ? bottom-right
            #   p.x < 0, p.y <= 0 ? bottom-left
            "float cornerSDF(vec2 p, vec2 halfSize, vec4 radii) {\n"
            "  float r = (p.x < 0.0)\n"
            "    ? ((p.y > 0.0) ? radii.x : radii.w)\n"
            "    : ((p.y > 0.0) ? radii.y : radii.z);\n"
            "  r = min(r, min(halfSize.x, halfSize.y));\n"
            "  vec2 d = abs(p) - halfSize + r;\n"
            "  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;\n"
            "}\n"
            "\n"
            "float gradientNoise(vec2 coord) {\n"
            "  return fract(52.9829189 * fract(dot(coord, vec2(0.06711056, 0.00583715))));\n"
            "}\n"
            "\n"
            "vec4 gradientWithDither(vec4 c1, vec4 c2, float angle, vec2 lp, vec2 center) {\n"
            "  float rad = radians(angle);\n"
            "  vec2 dir = vec2(cos(rad), sin(rad));\n"
            "  float proj = dot(lp - center, dir);\n"
            "  float maxP = abs(dot(center, abs(dir)));\n"
            "  float t = clamp((proj + maxP) / (2.0 * maxP), 0.0, 1.0);\n"
            "  vec4 col = mix(c1, c2, t);\n"
            "  float noise = gradientNoise(gl_FragCoord.xy);\n"
            "  float ds = 1.0 / 255.0;\n"
            "  col.rgb += vec3(noise * ds - ds * 0.5);\n"
            "  return col;\n"
            "}\n"
            "\n"
            "vec4 gradient3WithDither(vec4 c1, vec4 c2, vec4 c3, float angle, vec2 lp, vec2 center) {\n"
            "  float rad = radians(angle);\n"
            "  vec2 dir = vec2(cos(rad), sin(rad));\n"
            "  float proj = dot(lp - center, dir);\n"
            "  float maxP = abs(dot(center, abs(dir)));\n"
            "  float t = clamp((proj + maxP) / (2.0 * maxP), 0.0, 1.0);\n"
            "  float edge = abs(t * 2.0 - 1.0);\n"
            "  edge = pow(edge, 1.5);\n"
            "  vec4 edgeCol = mix(c1, c3, t);\n"
            "  vec4 col = mix(c2, edgeCol, edge);\n"
            "  float noise = gradientNoise(gl_FragCoord.xy);\n"
            "  float ds = 1.0 / 255.0;\n"
            "  col.rgb += vec3(noise * ds - ds * 0.5);\n"
            "  return col;\n"
            "}\n"
            "\n"
            "void main() {\n"
            "  vec2 rectSize = v_params.xy;\n"
            "  float borderWidth = v_params.z;\n"
            "  float gradAngle = v_params2.x;\n"
            "  float opacity = v_params2.y;\n"
            "\n"
            "  vec2 lp = v_uv * rectSize;\n"
            "  vec2 center = rectSize * 0.5;\n"
            "\n"
            "  // 4x MSAA � Rotated Grid Super-Sampling for smooth edges\n"
            "  float aa = 0.5;\n"
            "  vec2 p0 = lp + vec2(-0.125, -0.375) - center;\n"
            "  vec2 p1 = lp + vec2( 0.375, -0.125) - center;\n"
            "  vec2 p2 = lp + vec2(-0.375,  0.125) - center;\n"
            "  vec2 p3 = lp + vec2( 0.125,  0.375) - center;\n"
            "\n"
            "  float d0 = cornerSDF(p0, center, v_radii);\n"
            "  float d1 = cornerSDF(p1, center, v_radii);\n"
            "  float d2 = cornerSDF(p2, center, v_radii);\n"
            "  float d3 = cornerSDF(p3, center, v_radii);\n"
            "\n"
            "  float fillMask = (\n"
            "    (1.0 - smoothstep(-aa, aa, d0)) +\n"
            "    (1.0 - smoothstep(-aa, aa, d1)) +\n"
            "    (1.0 - smoothstep(-aa, aa, d2)) +\n"
            "    (1.0 - smoothstep(-aa, aa, d3))\n"
            "  ) * 0.25;\n"
            "\n"
            "  vec4 col = v_fill_color;\n"
            "  if (v_fill_color_3.a > 0.0) {\n"
            "    col = gradient3WithDither(v_fill_color, v_fill_color_2, v_fill_color_3, gradAngle, lp, center);\n"
            "  } else if (v_fill_color_2.a > 0.0) {\n"
            "    col = gradientWithDither(v_fill_color, v_fill_color_2, gradAngle, lp, center);\n"
            "  }\n"
            "\n"
            "  float borderMask = 0.0;\n"
            "  vec4 bCol = v_border_color;\n"
            "  if (v_border_color_2.a > 0.0) {\n"
            "    float bGradAngle = v_params3.x;\n"
            "    bCol = gradientWithDither(v_border_color, v_border_color_2, bGradAngle, lp, center);\n"
            "  }\n"
            "  if (borderWidth > 0.0 && v_border_color.a > 0.0) {\n"
            "    borderMask = (\n"
            "      (smoothstep(-aa, aa, d0 + borderWidth) - smoothstep(-aa, aa, d0)) +\n"
            "      (smoothstep(-aa, aa, d1 + borderWidth) - smoothstep(-aa, aa, d1)) +\n"
            "      (smoothstep(-aa, aa, d2 + borderWidth) - smoothstep(-aa, aa, d2)) +\n"
            "      (smoothstep(-aa, aa, d3 + borderWidth) - smoothstep(-aa, aa, d3))\n"
            "    ) * 0.25;\n"
            "  }\n"
            "\n"
            "  float adjustedFill = fillMask * (1.0 - borderMask);\n"
            "  vec4 result = col * adjustedFill + bCol * borderMask;\n"
            "  result.a = (col.a * adjustedFill + bCol.a * borderMask) * opacity;\n"
            "  if (result.a < 0.001) discard;\n"
            "  fragColor = result;\n"
            "}\n"
        )

        shader = gpu.shader.create_from_info(info)
        _sdf_available = True
        return shader
    except Exception as e:
        print(f"[BGUI] SDF shader creation failed: {e}, using tessellated fallback")
        _sdf_available = False
        return None


def _try_create_shadow_shader():
    """Create box-shadow shader. Returns shader or None."""
    try:
        info = gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_in(1, 'VEC2', "uv")

        iface = gpu.types.GPUStageInterfaceInfo("bgui_shadow_iface")
        iface.smooth('VEC2', "v_uv")
        info.vertex_out(iface)

        info.fragment_out(0, 'VEC4', "fragColor")

        info.push_constant('MAT4', "ModelViewProjectionMatrix")
        info.push_constant('VEC2', "u_rect_size")
        info.push_constant('VEC2', "u_shadow_offset")
        info.push_constant('FLOAT', "u_radius")
        info.push_constant('FLOAT', "u_blur")
        info.push_constant('VEC4', "u_shadow_color")
        info.push_constant('VEC2', "u_expand")  # how much bigger the quad is

        info.vertex_source(
            "void main() {\n"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);\n"
            "  v_uv = uv;\n"
            "}\n"
        )

        info.fragment_source(
            "float roundedRectSDF(vec2 p, vec2 b, float r) {\n"
            "  vec2 d = abs(p) - b + r;\n"
            "  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;\n"
            "}\n"
            "\n"
            "void main() {\n"
            "  vec2 totalSize = u_rect_size + u_expand * 2.0;\n"
            "  vec2 lp = v_uv * totalSize;\n"
            "  vec2 rectCenter = totalSize * 0.5 + u_shadow_offset;\n"
            "  float r = min(u_radius, min(u_rect_size.x, u_rect_size.y) * 0.5);\n"
            "  float dist = roundedRectSDF(lp - rectCenter, u_rect_size * 0.5, r);\n"
            "\n"
            "  float softness = max(u_blur * 0.5, 0.5);\n"
            "  float alpha = 1.0 - smoothstep(-softness, u_blur, dist);\n"
            "  alpha = clamp(alpha, 0.0, 1.0);\n"
            "\n"
            "  fragColor = vec4(u_shadow_color.rgb, u_shadow_color.a * alpha);\n"
            "  if (fragColor.a < 0.001) discard;\n"
            "}\n"
        )

        return gpu.shader.create_from_info(info)
    except Exception:
        return None


def _get_sdf_shader():
    global _sdf_shader
    if _sdf_shader is None and _sdf_available is not False:
        _sdf_shader = _try_create_sdf_shader()
    return _sdf_shader


def _get_shadow_shader():
    global _shadow_shader
    if _shadow_shader is None and _sdf_available is not False:
        _shadow_shader = _try_create_shadow_shader()
    return _shadow_shader


def _try_create_inner_shadow_shader():
    """Create inset box-shadow shader. Returns shader or None."""
    try:
        info = gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_in(1, 'VEC2', "uv")

        iface = gpu.types.GPUStageInterfaceInfo("bgui_ishadow_iface")
        iface.smooth('VEC2', "v_uv")
        info.vertex_out(iface)

        info.fragment_out(0, 'VEC4', "fragColor")

        info.push_constant('MAT4', "ModelViewProjectionMatrix")
        info.push_constant('VEC2', "u_rect_size")
        info.push_constant('VEC2', "u_shadow_offset")
        info.push_constant('FLOAT', "u_radius")
        info.push_constant('FLOAT', "u_blur")
        info.push_constant('VEC4', "u_shadow_color")
        info.push_constant('FLOAT', "u_spread")
        info.push_constant('FLOAT', "u_border_inset")

        info.vertex_source(
            "void main() {\n"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);\n"
            "  v_uv = uv;\n"
            "}\n"
        )

        # Affinity Designer-style inner shadow:
        # u_blur = Radius (Gaussian blur amount, controls size + softness)
        # u_spread = Intensity (choke � expands shadow before blur)
        # u_shadow_offset = Offset (directional shift)
        # u_shadow_color = Colour + Opacity
        # u_border_inset = border width (clips shadow behind the stroke)
        # Shadow SDF is computed from inner border contour so shadow
        # starts at full intensity at the visible edge.
        # Uses exponential decay (Gaussian approximation) instead of
        # smoothstep to give immediate gradient from the edge.
        info.fragment_source(
            "float roundedRectSDF(vec2 p, vec2 b, float r) {\n"
            "  vec2 d = abs(p) - b + r;\n"
            "  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;\n"
            "}\n"
            "\n"
            "void main() {\n"
            "  vec2 lp = v_uv * u_rect_size;\n"
            "  vec2 rectCenter = u_rect_size * 0.5;\n"
            "  float r = min(u_radius, min(u_rect_size.x, u_rect_size.y) * 0.5);\n"
            "\n"
            "  // Clip to inside the border\n"
            "  float inside = roundedRectSDF(lp - rectCenter, u_rect_size * 0.5, r);\n"
            "  if (inside > -u_border_inset) discard;\n"
            "\n"
            "  // Shadow SDF from inner border contour\n"
            "  float ir = max(r - u_border_inset, 0.0);\n"
            "  vec2 innerHalf = u_rect_size * 0.5 - u_border_inset;\n"
            "  float dist = roundedRectSDF(lp - rectCenter + u_shadow_offset, innerHalf, ir);\n"
            "  dist += u_spread;\n"
            "\n"
            "  // Gaussian-like exponential decay from the edge\n"
            "  // dist=0 at edge ? alpha=1, dist=-blur ? alpha�0.14\n"
            "  float blur = max(u_blur, 0.001);\n"
            "  float alpha = exp(2.0 * dist / blur);\n"
            "  alpha = clamp(alpha, 0.0, 1.0);\n"
            "\n"
            "  fragColor = vec4(u_shadow_color.rgb, u_shadow_color.a * alpha);\n"
            "  if (fragColor.a < 0.001) discard;\n"
            "}\n"
        )

        return gpu.shader.create_from_info(info)
    except Exception:
        return None


def _get_inner_shadow_shader():
    global _inner_shadow_shader
    if _inner_shadow_shader is None and _sdf_available is not False:
        _inner_shadow_shader = _try_create_inner_shadow_shader()
    return _inner_shadow_shader


def _try_create_tex_sdf_shader():
    """Create textured rounded-rect shader. Samples a texture and clips to
    a rounded rect via SDF. Returns shader or None."""
    try:
        info = gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_in(1, 'VEC2', "uv")       # texture sampling coords
        info.vertex_in(2, 'VEC2', "sdf_uv")   # 0?1 coords for SDF clipping

        iface = gpu.types.GPUStageInterfaceInfo("bgui_tex_sdf_iface")
        iface.smooth('VEC2', "v_uv")
        iface.smooth('VEC2', "v_sdf_uv")
        info.vertex_out(iface)

        info.fragment_out(0, 'VEC4', "fragColor")

        info.push_constant('MAT4', "ModelViewProjectionMatrix")
        info.push_constant('VEC2', "u_rect_size")
        info.push_constant('FLOAT', "u_radius")
        info.push_constant('FLOAT', "u_opacity")
        info.sampler(0, 'FLOAT_2D', "image")

        info.vertex_source(
            "void main() {\n"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);\n"
            "  v_uv = uv;\n"
            "  v_sdf_uv = sdf_uv;\n"
            "}\n"
        )

        info.fragment_source(
            "float roundedRectSDF(vec2 p, vec2 b, float r) {\n"
            "  vec2 d = abs(p) - b + r;\n"
            "  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;\n"
            "}\n"
            "\n"
            "void main() {\n"
            "  vec4 color = texture(image, v_uv);\n"
            "  vec2 halfSize = u_rect_size * 0.5;\n"
            "  vec2 p = v_sdf_uv * u_rect_size - halfSize;\n"
            "  float r = min(u_radius, min(halfSize.x, halfSize.y));\n"
            "  float dist = roundedRectSDF(p, halfSize, r);\n"
            "  float alpha = 1.0 - smoothstep(-1.0, 1.0, dist);\n"
            "  fragColor = vec4(color.rgb, color.a * alpha * u_opacity);\n"
            "  if (fragColor.a < 0.001) discard;\n"
            "}\n"
        )

        return gpu.shader.create_from_info(info)
    except Exception as e:
        print(f"[BGUI] Tex-SDF shader creation failed: {e}")
        return None


def _get_tex_sdf_shader():
    global _tex_sdf_shader
    if _tex_sdf_shader is None and _sdf_available is not False:
        _tex_sdf_shader = _try_create_tex_sdf_shader()
    return _tex_sdf_shader


# Maximum number of color stops for the multi-stop gradient shader.
_MAX_GRADIENT_STOPS = 16


def _try_create_gradient_shader():
    """Create a multi-stop linear gradient shader with SDF rounded-rect clipping.
    Supports up to _MAX_GRADIENT_STOPS color stops in a single draw call.
    Returns shader or None."""
    n = _MAX_GRADIENT_STOPS
    try:
        info = gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_in(1, 'VEC2', "uv")

        iface = gpu.types.GPUStageInterfaceInfo("bgui_grad_iface")
        iface.smooth('VEC2', "v_uv")
        info.vertex_out(iface)

        info.fragment_out(0, 'VEC4', "fragColor")

        info.push_constant('MAT4', "ModelViewProjectionMatrix")
        info.push_constant('VEC2', "u_rect_size")
        info.push_constant('VEC4', "u_radii")       # per-corner: tl, tr, br, bl
        info.push_constant('FLOAT', "u_angle")       # gradient angle in degrees
        info.push_constant('FLOAT', "u_opacity")
        info.push_constant('INT', "u_stop_count")
        info.push_constant('FLOAT', "u_border_width")
        info.push_constant('VEC4', "u_border_color")

        # Stop data passed as individual push constants
        for i in range(n):
            info.push_constant('FLOAT', f"u_pos_{i}")
        for i in range(n):
            info.push_constant('VEC4', f"u_col_{i}")

        info.vertex_source(
            "void main() {\n"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);\n"
            "  v_uv = uv;\n"
            "}\n"
        )

        # Build the fragment source with unrolled stop lookup
        frag_lines = [
            "float cornerSDF(vec2 p, vec2 halfSize, vec4 radii) {\n",
            "  float r = (p.x < 0.0)\n",
            "    ? ((p.y > 0.0) ? radii.x : radii.w)\n",
            "    : ((p.y > 0.0) ? radii.y : radii.z);\n",
            "  r = min(r, min(halfSize.x, halfSize.y));\n",
            "  vec2 d = abs(p) - halfSize + r;\n",
            "  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;\n",
            "}\n\n",
            "float gradientNoise(vec2 coord) {\n",
            "  return fract(52.9829189 * fract(dot(coord, vec2(0.06711056, 0.00583715))));\n",
            "}\n\n",
            # Unrolled index-to-value accessors (push constants aren't indexable)
            "float getPos(int i) {\n",
        ]
        for i in range(n):
            frag_lines.append(f"  if (i == {i}) return u_pos_{i};\n")
        frag_lines.append("  return 0.0;\n}\n\n")

        frag_lines.append("vec4 getCol(int i) {\n")
        for i in range(n):
            frag_lines.append(f"  if (i == {i}) return u_col_{i};\n")
        frag_lines.append("  return vec4(0.0);\n}\n\n")

        frag_lines += [
            "void main() {\n",
            "  vec2 halfSize = u_rect_size * 0.5;\n",
            "  vec2 lp = v_uv * u_rect_size;\n",
            "  vec2 center = halfSize;\n",
            "\n",
            "  // Gradient t value\n",
            "  float rad = radians(u_angle);\n",
            "  vec2 dir = vec2(cos(rad), sin(rad));\n",
            "  float proj = dot(lp - center, dir);\n",
            "  float maxP = abs(dot(center, abs(dir)));\n",
            "  float t = clamp((proj + maxP) / (2.0 * maxP), 0.0, 1.0);\n",
            "\n",
            "  // Multi-stop color lookup\n",
            "  vec4 col = getCol(0);\n",
            "  for (int i = 1; i < u_stop_count; i++) {\n",
            "    float p0 = getPos(i - 1);\n",
            "    float p1 = getPos(i);\n",
            "    if (t >= p0 && t <= p1) {\n",
            "      float seg_t = (t - p0) / max(p1 - p0, 0.0001);\n",
            "      col = mix(getCol(i - 1), getCol(i), seg_t);\n",
            "      break;\n",
            "    } else if (t > p1) {\n",
            "      col = getCol(i);\n",
            "    }\n",
            "  }\n",
            "\n",
            "  // Dithering\n",
            "  float noise = gradientNoise(gl_FragCoord.xy);\n",
            "  float ds = 1.0 / 255.0;\n",
            "  col.rgb += vec3(noise * ds - ds * 0.5);\n",
            "\n",
            "  // SDF rounded-rect clipping (4x MSAA)\n",
            "  float aa = 0.5;\n",
            "  vec2 p0s = lp + vec2(-0.125, -0.375) - center;\n",
            "  vec2 p1s = lp + vec2( 0.375, -0.125) - center;\n",
            "  vec2 p2s = lp + vec2(-0.375,  0.125) - center;\n",
            "  vec2 p3s = lp + vec2( 0.125,  0.375) - center;\n",
            "  float d0 = cornerSDF(p0s, center, u_radii);\n",
            "  float d1 = cornerSDF(p1s, center, u_radii);\n",
            "  float d2 = cornerSDF(p2s, center, u_radii);\n",
            "  float d3 = cornerSDF(p3s, center, u_radii);\n",
            "  float fillMask = (\n",
            "    (1.0 - smoothstep(-aa, aa, d0)) +\n",
            "    (1.0 - smoothstep(-aa, aa, d1)) +\n",
            "    (1.0 - smoothstep(-aa, aa, d2)) +\n",
            "    (1.0 - smoothstep(-aa, aa, d3))\n",
            "  ) * 0.25;\n",
            "\n",
            "  // Border\n",
            "  float borderMask = 0.0;\n",
            "  if (u_border_width > 0.0 && u_border_color.a > 0.0) {\n",
            "    borderMask = (\n",
            "      (smoothstep(-aa, aa, d0 + u_border_width) - smoothstep(-aa, aa, d0)) +\n",
            "      (smoothstep(-aa, aa, d1 + u_border_width) - smoothstep(-aa, aa, d1)) +\n",
            "      (smoothstep(-aa, aa, d2 + u_border_width) - smoothstep(-aa, aa, d2)) +\n",
            "      (smoothstep(-aa, aa, d3 + u_border_width) - smoothstep(-aa, aa, d3))\n",
            "    ) * 0.25;\n",
            "  }\n",
            "\n",
            "  float adjustedFill = fillMask * (1.0 - borderMask);\n",
            "  vec4 result = col * adjustedFill + u_border_color * borderMask;\n",
            "  result.a = (col.a * adjustedFill + u_border_color.a * borderMask) * u_opacity;\n",
            "  if (result.a < 0.001) discard;\n",
            "  fragColor = result;\n",
            "}\n",
        ]

        info.fragment_source("".join(frag_lines))

        return gpu.shader.create_from_info(info)
    except Exception as e:
        print(f"[BGUI] Multi-stop gradient shader creation failed: {e}")
        return None


def _get_gradient_shader():
    global _gradient_shader
    if _gradient_shader is None and _sdf_available is not False:
        _gradient_shader = _try_create_gradient_shader()
    return _gradient_shader


def invalidate_shaders():
    global _flat_shader, _smooth_shader, _sdf_shader, _shadow_shader, _inner_shadow_shader, _tex_sdf_shader, _gradient_shader, _sdf_available
    _flat_shader = None
    _smooth_shader = None
    _sdf_shader = None
    _shadow_shader = None
    _inner_shadow_shader = None
    _tex_sdf_shader = None
    _gradient_shader = None
    _sdf_available = None


# -- Tessellation helpers (fallback) --------------------------

_ARC_SEGMENTS = 8


def _rounded_rect_outline(x1, y1, x2, y2, radius):
    r = min(radius, (x2 - x1) / 2, (y2 - y1) / 2)
    pts = []
    seg = _ARC_SEGMENTS

    def arc(cx, cy, start, end):
        for i in range(seg + 1):
            a = start + (end - start) * (i / seg)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))

    arc(x2 - r, y1 + r, -math.pi / 2, 0)
    arc(x2 - r, y2 - r, 0, math.pi / 2)
    arc(x1 + r, y2 - r, math.pi / 2, math.pi)
    arc(x1 + r, y1 + r, math.pi, 3 * math.pi / 2)
    return pts


def _triangulate_fan(center, outline):
    tris = []
    n = len(outline)
    for i in range(n):
        tris.append(center)
        tris.append(outline[i])
        tris.append(outline[(i + 1) % n])
    return tris


class Renderer:
    """Stateful renderer � create per draw call with current region height.

    Uses SDF shaders for anti-aliased rounded rects, gradients, and shadows.
    Falls back to tessellated rendering if create_from_info() is unavailable.
    Supports scissor-rect clipping stack for overflow:hidden.
    """

    def __init__(self, region_height: float):
        self.region_height = region_height
        self._clip_stack: List[Rect] = []
        self._overlays: List = []

    def _flip_y(self, y: float) -> float:
        return self.region_height - y

    # -- Overlays (drawn after all widgets) ------------------

    def add_overlay(self, callback):
        """Schedule a drawing callback to run after all widgets draw."""
        self._overlays.append(callback)

    def flush_overlays(self):
        """Draw all scheduled overlays. Call after root.draw()."""
        for cb in self._overlays:
            cb(self)
        self._overlays.clear()

    # -- Clipping ---------------------------------------------

    def push_clip(self, rect: Rect):
        """Push a clip rect (in widget coords). Children are scissored to it."""
        # Intersect with current clip if nested
        if self._clip_stack:
            prev = self._clip_stack[-1]
            x1 = max(rect.x, prev.x)
            y1 = max(rect.y, prev.y)
            x2 = min(rect.right, prev.right)
            y2 = min(rect.bottom, prev.bottom)
            clipped = Rect(x1, y1, max(0, x2 - x1), max(0, y2 - y1))
        else:
            clipped = Rect(rect.x, rect.y, rect.width, rect.height)
        self._clip_stack.append(clipped)
        self._apply_scissor(clipped)

    def pop_clip(self):
        """Pop the current clip rect."""
        if self._clip_stack:
            self._clip_stack.pop()
        if self._clip_stack:
            self._apply_scissor(self._clip_stack[-1])
        else:
            gpu.state.scissor_test_set(False)

    def _apply_scissor(self, rect: Rect):
        """Set GPU scissor rect from widget-space Rect."""
        # Convert widget coords (top-down) to GL coords (bottom-up)
        gl_y = self._flip_y(rect.bottom)
        w = max(0, int(rect.width))
        h = max(0, int(rect.height))
        gpu.state.scissor_test_set(True)
        gpu.state.scissor_set(int(rect.x), int(gl_y), w, h)

    # -- SDF drawing (primary) --------------------------------

    def _make_sdf_quad(self, rect: Rect, expand: float = 0.0):
        """Build a screen-space quad with UV coords for SDF rendering."""
        x1 = rect.x - expand
        x2 = rect.right + expand
        y1 = self._flip_y(rect.bottom + expand)
        y2 = self._flip_y(rect.y - expand)

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        uvs = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
        indices = [(0, 1, 2), (0, 2, 3)]
        return verts, uvs, indices

    def draw_rounded_rect(self, rect: Rect, color: Color, radii,
                          border_color: Optional[Color] = None,
                          border_width: float = 0.0,
                          color2: Optional[Color] = None,
                          gradient_angle: float = 0.0,
                          border_color2: Optional[Color] = None,
                          border_gradient_angle: float = 0.0,
                          opacity: float = 1.0,
                          color3: Optional[Color] = None):
        """Draw a rounded rect with optional gradient and border.

        radii: float (uniform) or tuple (tl, tr, br, bl).
        Uses SDF if available, falls back to tessellated.
        """
        if isinstance(radii, (int, float)):
            radii = (radii, radii, radii, radii)
        shader = _get_sdf_shader()
        if shader:
            self._draw_sdf_rect(shader, rect, color, radii,
                                border_color, border_width,
                                color2, gradient_angle,
                                border_color2, border_gradient_angle,
                                opacity, color3=color3)
        else:
            self._draw_tessellated_rect(rect, color, radii,
                                        border_color, border_width)

    def _draw_sdf_rect(self, shader, rect: Rect, color: Color, radii: tuple,
                       border_color: Optional[Color], border_width: float,
                       color2: Optional[Color], gradient_angle: float,
                       border_color2: Optional[Color], border_gradient_angle: float,
                       opacity: float, color3: Optional[Color] = None):
        verts, uvs, indices = self._make_sdf_quad(rect)
        n = len(verts)

        fill = list(color)
        fill2 = list(color2) if color2 else [0, 0, 0, 0]
        fill3 = list(color3) if color3 else [0, 0, 0, 0]
        bc = list(border_color) if border_color else [0, 0, 0, 0]
        bc2 = list(border_color2) if border_color2 else [0, 0, 0, 0]
        params = (rect.width, rect.height, border_width, 0.0)
        params2 = (gradient_angle, opacity)
        params3 = (border_gradient_angle, 0.0)
        rads = tuple(radii)  # (tl, tr, br, bl)

        batch = batch_for_shader(shader, 'TRIS', {
            "pos": verts,
            "uv": uvs,
            "a_fill_color": [fill] * n,
            "a_fill_color_2": [fill2] * n,
            "a_fill_color_3": [fill3] * n,
            "a_border_color": [bc] * n,
            "a_border_color_2": [bc2] * n,
            "a_params": [params] * n,
            "a_params2": [params2] * n,
            "a_params3": [params3] * n,
            "a_radii": [rads] * n,
        }, indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    def _draw_tessellated_rect(self, rect: Rect, color: Color, radii,
                               border_color: Optional[Color],
                               border_width: float):
        """Fallback: CPU-tessellated rounded rect."""
        if isinstance(radii, (int, float)):
            radii = (radii, radii, radii, radii)
        # Use the max corner radius for the simple uniform tessellator
        radius = max(radii)
        max_r = min(rect.width, rect.height) / 2
        radius = min(radius, max_r)

        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)

        outline = _rounded_rect_outline(x1, y1, x2, y2, radius)
        center = ((x1 + x2) / 2, (y1 + y2) / 2)
        verts = _triangulate_fan(center, outline)

        shader = _get_flat_shader()
        batch = batch_for_shader(shader, 'TRIS', {"pos": verts})

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)

        if border_color and border_width > 0:
            loop = list(outline) + [outline[0]]
            batch_b = batch_for_shader(shader, 'LINE_STRIP', {"pos": loop})
            gpu.state.line_width_set(border_width)
            shader.uniform_float("color", border_color)
            batch_b.draw(shader)
            gpu.state.line_width_set(1.0)

        gpu.state.blend_set('NONE')

    # -- Multi-stop Gradient ----------------------------------

    def draw_multi_stop_gradient(self, rect: Rect, stops: list, radii=0,
                                 gradient_angle: float = 0.0,
                                 border_color: Optional[Color] = None,
                                 border_width: float = 0.0,
                                 opacity: float = 1.0):
        """Draw a multi-stop linear gradient inside a rounded rect.

        stops: list of (position, color) tuples, where position is 0.0-1.0
               and color is an RGBA tuple.  Up to 16 stops.
        radii: float (uniform) or tuple (tl, tr, br, bl).
        gradient_angle: degrees (0 = left?right, 90 = bottom?top).
        """
        if isinstance(radii, (int, float)):
            radii = (radii, radii, radii, radii)
        shader = _get_gradient_shader()
        if shader is None:
            # Fallback: draw first?last 2-color gradient via SDF shader
            if stops:
                self.draw_rounded_rect(rect, stops[0][1], radii,
                                       color2=stops[-1][1] if len(stops) > 1 else None,
                                       gradient_angle=gradient_angle,
                                       border_color=border_color,
                                       border_width=border_width,
                                       opacity=opacity)
            return

        sorted_stops = sorted(stops, key=lambda s: s[0])
        count = min(len(sorted_stops), _MAX_GRADIENT_STOPS)

        verts, uvs, indices = self._make_sdf_quad(rect)

        batch = batch_for_shader(shader, 'TRIS',
                                 {"pos": verts, "uv": uvs},
                                 indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("u_rect_size", (rect.width, rect.height))
        shader.uniform_float("u_radii", tuple(radii))
        shader.uniform_float("u_angle", gradient_angle)
        shader.uniform_float("u_opacity", opacity)
        shader.uniform_int("u_stop_count", count)
        shader.uniform_float("u_border_width", border_width)
        shader.uniform_float("u_border_color",
                             list(border_color) if border_color else [0, 0, 0, 0])

        # Set per-stop uniforms (pad unused slots with zeros)
        for i in range(_MAX_GRADIENT_STOPS):
            if i < count:
                shader.uniform_float(f"u_pos_{i}", sorted_stops[i][0])
                shader.uniform_float(f"u_col_{i}", list(sorted_stops[i][1]))
            else:
                shader.uniform_float(f"u_pos_{i}", 1.0)
                shader.uniform_float(f"u_col_{i}", [0, 0, 0, 0])

        batch.draw(shader)
        gpu.state.blend_set('NONE')

    # -- Box Shadow -------------------------------------------

    def draw_shadow(self, rect: Rect, shadow_color: Color,
                    blur: float, offset: Tuple[float, float] = (0, 0),
                    radius: float = 0.0):
        """Draw a box shadow behind a rect. SDF-based, soft edge."""
        shader = _get_shadow_shader()
        if not shader:
            return  # no fallback for shadows

        expand = blur + abs(offset[0]) + abs(offset[1])
        verts, uvs, indices = self._make_sdf_quad(rect, expand)
        batch = batch_for_shader(shader, 'TRIS',
                                 {"pos": verts, "uv": uvs}, indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("u_rect_size", (rect.width, rect.height))
        shader.uniform_float("u_shadow_offset", offset)
        shader.uniform_float("u_radius", radius)
        shader.uniform_float("u_blur", blur)
        shader.uniform_float("u_shadow_color", shadow_color)
        shader.uniform_float("u_expand", (expand, expand))
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    def draw_inner_shadow(self, rect: Rect, shadow_color: Color,
                          blur: float, offset: Tuple[float, float] = (0, 0),
                          radius: float = 0.0, spread: float = 0.0,
                          border_inset: float = 0.0):
        """Affinity Designer-style inner shadow.

        *blur*  = Radius � controls size and softness (single param).
        *offset* = directional shift (x, y).
        *spread* = Intensity � choke/expand before blur.
        *radius* = element corner radius.
        *border_inset* = stroke width (shadow clips behind it).
        """
        shader = _get_inner_shadow_shader()
        if not shader:
            return

        verts, uvs, indices = self._make_sdf_quad(rect, 0)
        batch = batch_for_shader(shader, 'TRIS',
                                 {"pos": verts, "uv": uvs}, indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("u_rect_size", (rect.width, rect.height))
        shader.uniform_float("u_shadow_offset", offset)
        shader.uniform_float("u_radius", radius)
        shader.uniform_float("u_blur", blur)
        shader.uniform_float("u_shadow_color", shadow_color)
        shader.uniform_float("u_spread", spread)
        shader.uniform_float("u_border_inset", border_inset)
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    # -- Simple rectangles ------------------------------------

    def draw_rect(self, rect: Rect, color: Color):
        shader = _get_flat_shader()
        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        indices = [(0, 1, 2), (0, 2, 3)]
        batch = batch_for_shader(shader, 'TRIS', {"pos": verts}, indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    def draw_rect_outline(self, rect: Rect, color: Color, width: float = 1.0):
        shader = _get_flat_shader()
        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)]
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})

        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(width)
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')

    # -- Gradient (simple fallback) ---------------------------

    def draw_gradient_rect(self, rect: Rect,
                           color_start: Color, color_end: Color,
                           direction: str = 'vertical'):
        """Draw a gradient rect. Use draw_rounded_rect with color2 for
        gradient rounded rects with SDF."""
        shader = _get_smooth_shader()
        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)

        if direction == 'vertical':
            colors = [color_start, color_start, color_end, color_end]
        else:
            colors = [color_start, color_end, color_end, color_start]

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        indices = [(0, 1, 2), (0, 2, 3)]
        batch = batch_for_shader(
            shader, 'TRIS', {"pos": verts, "color": colors}, indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    # -- Triangle ---------------------------------------------

    def draw_triangle(self, x1: float, y1: float,
                      x2: float, y2: float,
                      x3: float, y3: float,
                      color: Color = (1, 1, 1, 1)):
        """Draw a filled triangle given three vertices (top-down coords)."""
        verts = [
            (x1, self._flip_y(y1)),
            (x2, self._flip_y(y2)),
            (x3, self._flip_y(y3)),
        ]
        shader = _get_flat_shader()
        batch = batch_for_shader(shader, 'TRIS', {"pos": verts})
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    # -- Text -------------------------------------------------

    def draw_text(self, text: str, x: float, y: float,
                  size: float = 14, color: Color = (1, 1, 1, 1),
                  font_id: int = 0, clip_rect: Optional[Rect] = None,
                  font_weight: Optional[str] = None,
                  ref_height: Optional[float] = None) -> Tuple[float, float]:
        if font_weight is not None:
            font_id = _fonts.get(font_weight)
        elif font_id == 0:
            font_id = _fonts.get()  # use default custom font if loaded
        blf.size(font_id, size * ui_scale())
        blf.color(font_id, *color)
        # Use ref_height if provided for stable baseline, otherwise actual text height
        _, h = blf.dimensions(font_id, text)
        baseline_h = ref_height if ref_height is not None else h
        bl_y = self._flip_y(y) - baseline_h
        blf.position(font_id, x, bl_y, 0)

        # Apply text clipping if provided or if clip stack is active
        clip = clip_rect or (self._clip_stack[-1] if self._clip_stack else None)
        if clip:
            cl_x1 = clip.x
            cl_y1 = self._flip_y(clip.bottom)
            cl_x2 = clip.right
            cl_y2 = self._flip_y(clip.y)
            blf.clipping(font_id, cl_x1, cl_y1, cl_x2, cl_y2)
            blf.enable(font_id, blf.CLIPPING)

        gpu.state.blend_set('ALPHA')
        blf.draw(font_id, text)
        gpu.state.blend_set('NONE')

        if clip:
            blf.disable(font_id, blf.CLIPPING)

        return blf.dimensions(font_id, text)

    @staticmethod
    def measure_text(text: str, size: float = 14, font_id: int = 0,
                     font_weight: Optional[str] = None) -> Tuple[float, float]:
        if font_weight is not None:
            font_id = _fonts.get(font_weight)
        elif font_id == 0:
            font_id = _fonts.get()  # use default custom font if loaded
        blf.size(font_id, size * ui_scale())
        return blf.dimensions(font_id, text)

    # -- Text Gradient ----------------------------------------

    def draw_gradient_text(self, text: str, x: float, y: float,
                           color_start: Color, color_end: Color,
                           size: float = 14, font_id: int = 0,
                           clip_rect: Optional[Rect] = None,
                           font_weight: Optional[str] = None) -> Tuple[float, float]:
        """Draw text with per-character gradient interpolation."""
        if not text:
            return (0.0, 0.0)
        if font_weight is not None:
            font_id = _fonts.get(font_weight)
        elif font_id == 0:
            font_id = _fonts.get()
        blf.size(font_id, size * ui_scale())
        total_w, total_h = blf.dimensions(font_id, text)
        if total_w < 1:
            return (total_w, total_h)

        cx = x
        n = len(text)
        for i, ch in enumerate(text):
            t = i / max(1, n - 1)
            r = color_start[0] + (color_end[0] - color_start[0]) * t
            g = color_start[1] + (color_end[1] - color_start[1]) * t
            b = color_start[2] + (color_end[2] - color_start[2]) * t
            a = color_start[3] + (color_end[3] - color_start[3]) * t
            self.draw_text(ch, cx, y, size=size, color=(r, g, b, a),
                           font_id=font_id, clip_rect=clip_rect)
            cw, _ = blf.dimensions(font_id, ch)
            cx += cw
        return (total_w, total_h)

    # -- Image Rendering --------------------------------------

    @staticmethod
    def _cover_uvs(img_w, img_h, rect_w, rect_h):
        """Compute UV rect for 'cover' fit: scale uniformly to cover the
        target rect, cropping the excess.  Returns (u0, v0, u1, v1)."""
        img_aspect = img_w / max(img_h, 1)
        rect_aspect = rect_w / max(rect_h, 1)
        if img_aspect > rect_aspect:
            # Image wider than rect � crop horizontally
            u_range = rect_aspect / img_aspect
            u0 = (1.0 - u_range) * 0.5
            return (u0, 0.0, u0 + u_range, 1.0)
        else:
            # Image taller than rect � crop vertically
            v_range = img_aspect / rect_aspect
            v0 = (1.0 - v_range) * 0.5
            return (0.0, v0, 1.0, v0 + v_range)

    def draw_image(self, image, rect: Rect,
                   opacity: float = 1.0, border_radius: float = 0.0,
                   fit: str = 'fill'):
        """Draw a UIImage or bpy.types.Image in the given rect.

        fit: 'fill' (stretch) or 'cover' (uniform scale, crop excess).
        """
        # Accept UIImage (GPU-only) or bpy.types.Image
        from .widgets import UIImage
        if isinstance(image, UIImage):
            texture = image.gpu_texture
            img_size = image.size
        else:
            try:
                texture = gpu.texture.from_image(image)
            except Exception:
                return
            img_size = image.size if hasattr(image, 'size') else (0, 0)

        # Compute UVs for the requested fit mode
        if fit == 'cover' and img_size[0] > 0:
            uv_rect = self._cover_uvs(img_size[0], img_size[1],
                                      rect.width, rect.height)
        else:
            uv_rect = (0.0, 0.0, 1.0, 1.0)

        # Use SDF shader for rounded corners if needed
        if border_radius > 0:
            shader = _get_sdf_shader()
            if shader:
                self._draw_image_sdf(shader, rect, texture, opacity,
                                     border_radius, uv_rect)
                return

        # Simple textured quad via IMAGE shader
        self._draw_image_simple(rect, texture, opacity, uv_rect)

    def _draw_image_simple(self, rect: Rect, texture, opacity: float,
                           uv_rect: tuple = (0.0, 0.0, 1.0, 1.0)):
        """Draw textured quad using built-in IMAGE shader."""
        try:
            shader = gpu.shader.from_builtin('IMAGE')
        except Exception:
            return

        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)
        u0, v0, u1, v1 = uv_rect

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        uvs = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
        indices = [(0, 1, 2), (0, 2, 3)]

        batch = batch_for_shader(shader, 'TRIS',
                                 {"pos": verts, "texCoord": uvs},
                                 indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
        gpu.state.blend_set('NONE')

    def _draw_image_sdf(self, shader, rect: Rect, texture, opacity: float,
                        border_radius: float,
                        uv_rect: tuple = (0.0, 0.0, 1.0, 1.0)):
        """Draw rounded-corner image using SDF clip."""
        self.draw_texture_rounded(texture, rect,
                                  border_radius=border_radius, opacity=opacity,
                                  uv_rect=uv_rect)

    def draw_texture_rounded(self, texture, rect: Rect,
                             border_radius: float = 0.0,
                             opacity: float = 1.0,
                             uv_rect: tuple = (0.0, 0.0, 1.0, 1.0)):
        """Draw a GPUTexture inside a rounded rect using SDF clipping.

        uv_rect: (u0, v0, u1, v1) sub-region of the texture to sample.
        """
        shader = _get_tex_sdf_shader()
        if shader is None:
            # Fallback: draw without rounding
            self._draw_image_simple(rect, texture, opacity, uv_rect)
            return

        x1, x2 = rect.x, rect.right
        y1 = self._flip_y(rect.bottom)
        y2 = self._flip_y(rect.y)
        u0, v0, u1, v1 = uv_rect

        verts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        uvs = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
        sdf_uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]  # always 0?1 for SDF
        indices = [(0, 1, 2), (0, 2, 3)]

        batch = batch_for_shader(shader, 'TRIS',
                                 {"pos": verts, "uv": uvs,
                                  "sdf_uv": sdf_uvs},
                                 indices=indices)

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("u_rect_size", (rect.width, rect.height))
        shader.uniform_float("u_radius", border_radius)
        shader.uniform_float("u_opacity", opacity)
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
        gpu.state.blend_set('NONE')
