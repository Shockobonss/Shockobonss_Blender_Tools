# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Lightweight animation engine for smooth UI transitions.

Provides easing functions, color/float interpolation, a global
redraw timer, and a DOTween-inspired tweening system that can
animate any numeric property on any object.
"""
from __future__ import annotations
from typing import Any, Callable, Optional, Union
import time
import bpy


# -- Easing functions (t ? [0,1] ? [0,1]) -------------------

def linear(t: float) -> float:
    return t


def ease_out_cubic(t: float) -> float:
    return 1.0 - (1.0 - t) ** 3


def ease_in_cubic(t: float) -> float:
    return t * t * t


def ease_in_out_cubic(t: float) -> float:
    if t < 0.5:
        return 4.0 * t * t * t
    return 1.0 - (-2.0 * t + 2.0) ** 3 * 0.5


def ease_out_quad(t: float) -> float:
    return 1.0 - (1.0 - t) * (1.0 - t)


def ease_out_back(t: float) -> float:
    c = 1.70158
    return 1.0 + (c + 1.0) * ((t - 1.0) ** 3) + c * ((t - 1.0) ** 2)


def ease_out_expo(t: float) -> float:
    return 1.0 if t >= 1.0 else 1.0 - 2.0 ** (-10.0 * t)


# -- Interpolation -------------------------------------------

def lerp_float(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def lerp_color(a, b, t: float):
    """Lerp between two RGBA color tuples."""
    n = min(len(a), len(b))
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(n))


# -- Tween ----------------------------------------------------

class Tween:
    """Animates a single property on a target object over time.

    Usage::

        # Animate obj.thumb_t from 0 to 1 over 0.25s
        Tween(obj, 'thumb_t', 0.0, 1.0, 0.25, ease=ease_out_cubic)

        # Animate with callback
        Tween(obj, 'alpha', 1.0, 0.0, 0.3,
              on_complete=lambda tw: obj.destroy())

        # Color tween
        Tween(obj, 'track_color', red, green, 0.3, is_color=True)
    """

    __slots__ = (
        'target', 'prop', 'start', 'end', 'duration',
        'ease', 'on_update', 'on_complete',
        'is_color', '_start_time', '_killed',
    )

    def __init__(self, target: Any, prop: str,
                 start: Union[float, tuple], end: Union[float, tuple],
                 duration: float = 0.25,
                 ease: Callable[[float], float] = ease_out_cubic,
                 on_update: Optional[Callable[['Tween'], None]] = None,
                 on_complete: Optional[Callable[['Tween'], None]] = None,
                 is_color: bool = False):
        self.target = target
        self.prop = prop
        self.start = start
        self.end = end
        self.duration = max(duration, 0.001)
        self.ease = ease
        self.on_update = on_update
        self.on_complete = on_complete
        self.is_color = is_color
        self._start_time = time.perf_counter()
        self._killed = False

        # Auto-register
        TweenManager.add(self)

    def kill(self):
        """Stop this tween immediately without calling on_complete."""
        self._killed = True

    def complete(self):
        """Jump to the end value and fire on_complete."""
        self._apply(1.0)
        self._killed = True
        if self.on_complete:
            self.on_complete(self)

    def update(self) -> bool:
        """Advance the tween. Returns True if still alive."""
        if self._killed:
            return False
        elapsed = time.perf_counter() - self._start_time
        t = min(elapsed / self.duration, 1.0)
        eased = self.ease(t)
        self._apply(eased)
        if self.on_update:
            self.on_update(self)
        if t >= 1.0:
            if self.on_complete:
                self.on_complete(self)
            return False
        return True

    def _apply(self, eased: float):
        if self.is_color:
            val = lerp_color(self.start, self.end, eased)
        else:
            val = lerp_float(self.start, self.end, eased)
        setattr(self.target, self.prop, val)


class TweenManager:
    """Global singleton that drives all active tweens."""

    _tweens: list[Tween] = []

    @classmethod
    def add(cls, tween: Tween):
        # Kill any existing tween on the same target+prop
        for tw in cls._tweens:
            if tw.target is tween.target and tw.prop == tween.prop:
                tw.kill()
        cls._tweens.append(tween)
        request_anim()

    @classmethod
    def update(cls):
        """Called each frame from _anim_tick. Advances all tweens."""
        still_alive = []
        for tw in cls._tweens:
            if tw.update():
                still_alive.append(tw)
            else:
                release_anim()
        cls._tweens = still_alive

    @classmethod
    def kill_all(cls, target: Any = None):
        """Kill all tweens, or only those on a specific target."""
        for tw in cls._tweens:
            if target is None or tw.target is target:
                tw.kill()
                release_anim()
        cls._tweens = [tw for tw in cls._tweens if not tw._killed]

    @classmethod
    def reset(cls):
        cls._tweens.clear()


# -- Global animation timer ----------------------------------

_active_count: int = 0
_timer_running: bool = False


def request_anim():
    """Call when starting a new transition. Starts the redraw timer if needed."""
    global _active_count, _timer_running
    _active_count += 1
    if not _timer_running:
        _timer_running = True
        bpy.app.timers.register(_anim_tick, first_interval=1.0 / 60, persistent=False)


def release_anim():
    """Call when a transition completes."""
    global _active_count
    _active_count = max(0, _active_count - 1)


def _anim_tick():
    """Timer callback � update tweens and tag redraws for all GPU-panel spaces."""
    global _timer_running, _active_count

    # Drive all tweens
    TweenManager.update()

    if _active_count <= 0:
        _active_count = 0
        _timer_running = False
        return None  # Stop timer
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in ('VIEW_3D', 'IMAGE_EDITOR'):
                    for region in area.regions:
                        region.tag_redraw()
    except Exception:
        pass
    return 1.0 / 60  # ~60fps


def reset():
    """Reset animation state (call on addon unregister)."""
    global _active_count, _timer_running
    _active_count = 0
    _timer_running = False
    TweenManager.reset()
