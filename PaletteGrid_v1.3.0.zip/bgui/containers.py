# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 SavedPixel
# Licensed under GPL-3.0-or-later
# Commercial distribution outside authorized channels is prohibited
"""Container widgets for layout."""
from __future__ import annotations
from typing import Optional, List
from .core import (Widget, Style, Rect, EdgeInsets,
                   SizePolicy, Alignment, MainAxisAlignment, ui_scale)


def _distribute_main_axis(total_space: float, n_items: int,
                          main_align: MainAxisAlignment):
    """Return (start_offset, gap_between) for main-axis alignment."""
    if n_items <= 0 or total_space <= 0:
        return 0.0, 0.0
    if main_align == MainAxisAlignment.END:
        return total_space, 0.0
    if main_align == MainAxisAlignment.CENTER:
        return total_space / 2, 0.0
    if main_align == MainAxisAlignment.SPACE_BETWEEN:
        if n_items == 1:
            return 0.0, 0.0
        return 0.0, total_space / (n_items - 1)
    if main_align == MainAxisAlignment.SPACE_AROUND:
        g = total_space / n_items
        return g / 2, g
    if main_align == MainAxisAlignment.SPACE_EVENLY:
        g = total_space / (n_items + 1)
        return g, g
    return 0.0, 0.0


class Column(Widget):
    """Vertical stack � children laid out top to bottom."""

    def _measure_content_width(self) -> float:
        visible = [c for c in self.children if c.visible]
        return max((c.measure_width() for c in visible), default=0)

    def _measure_content_height(self) -> float:
        visible = [c for c in self.children if c.visible]
        if not visible:
            return 0
        total = sum(c.measure_height() for c in visible)
        sc = ui_scale()
        gaps = max(0, len(visible) - 1) * self.style.gap * sc
        return total + gaps

    def _layout_children(self):
        visible = [c for c in self.children if c.visible]
        if not visible:
            return
        cr = self.content_rect
        sc = ui_scale()
        gap = self.style.gap * sc
        align = self.style.alignment
        main_align = self.style.main_alignment

        # Measure natural sizes
        natural = [c.measure_height() for c in visible]
        total_gaps = max(0, len(visible) - 1) * gap
        total_natural = sum(natural) + total_gaps
        remaining = cr.height - total_natural

        # Flex grow
        flex_items = [(i, c.style.flex) for i, c in enumerate(visible) if c.style.flex > 0]
        total_flex = sum(f for _, f in flex_items)
        heights = list(natural)

        if remaining > 0 and total_flex > 0:
            for i, f in flex_items:
                heights[i] += remaining * (f / total_flex)
            remaining = 0
        elif remaining < 0:
            # Flex shrink: shrink proportionally by ratio of natural sizes
            shrinkable = sum(natural[i] for i in range(len(visible)))
            if shrinkable > 0:
                factor = min(1.0, (cr.height - total_gaps) / shrinkable)
                heights = [h * factor for h in heights]
                remaining = 0

        # Main-axis alignment uses leftover space (only if no flex grow happened)
        leftover = cr.height - sum(heights) - total_gaps
        start_off, extra_gap = _distribute_main_axis(
            max(0, leftover), len(visible), main_align)

        y = cr.y + start_off
        for idx, child in enumerate(visible):
            h = heights[idx]

            # Cross-axis alignment (width & x)
            # FILL children always get full width regardless of alignment
            if child.style.width_policy == SizePolicy.FILL or align == Alignment.STRETCH:
                w, x = cr.width, cr.x
            elif align == Alignment.CENTER:
                w = child.measure_width()
                x = cr.x + (cr.width - w) / 2
            elif align == Alignment.END:
                w = child.measure_width()
                x = cr.right - w
            else:
                w, x = child.measure_width(), cr.x

            child.layout(Rect(x, y, w, h))
            y += h + gap + extra_gap


class Row(Widget):
    """Horizontal stack � children laid out left to right."""

    def _measure_content_width(self) -> float:
        visible = [c for c in self.children if c.visible]
        if not visible:
            return 0
        total = sum(c.measure_width() for c in visible)
        sc = ui_scale()
        gaps = max(0, len(visible) - 1) * self.style.gap * sc
        return total + gaps

    def _measure_content_height(self) -> float:
        visible = [c for c in self.children if c.visible]
        return max((c.measure_height() for c in visible), default=0)

    def _layout_children(self):
        visible = [c for c in self.children if c.visible]
        if not visible:
            return
        cr = self.content_rect
        sc = ui_scale()
        gap = self.style.gap * sc
        align = self.style.alignment
        main_align = self.style.main_alignment

        natural = [c.measure_width() for c in visible]
        total_gaps = max(0, len(visible) - 1) * gap
        total_natural = sum(natural) + total_gaps
        remaining = cr.width - total_natural

        flex_items = [(i, c.style.flex) for i, c in enumerate(visible) if c.style.flex > 0]
        total_flex = sum(f for _, f in flex_items)
        widths = list(natural)

        if remaining > 0 and total_flex > 0:
            for i, f in flex_items:
                widths[i] += remaining * (f / total_flex)
            remaining = 0
        elif remaining < 0:
            shrinkable = sum(natural[i] for i in range(len(visible)))
            if shrinkable > 0:
                factor = min(1.0, (cr.width - total_gaps) / shrinkable)
                widths = [w * factor for w in widths]
                remaining = 0

        leftover = cr.width - sum(widths) - total_gaps
        start_off, extra_gap = _distribute_main_axis(
            max(0, leftover), len(visible), main_align)

        x = cr.x + start_off
        for idx, child in enumerate(visible):
            w = widths[idx]

            # FILL children always get full height regardless of alignment
            if child.style.height_policy == SizePolicy.FILL or align == Alignment.STRETCH:
                h, y = cr.height, cr.y
            elif align == Alignment.CENTER:
                h = child.measure_height()
                y = cr.y + (cr.height - h) / 2
            elif align == Alignment.END:
                h = child.measure_height()
                y = cr.bottom - h
            else:
                h, y = child.measure_height(), cr.y

            child.layout(Rect(x, y, w, h))
            x += w + gap + extra_gap


class Grid(Widget):
    """Grid layout with fixed or auto-calculated columns."""

    def __init__(self, columns: int = 0, cell_width: Optional[float] = None,
                 cell_height: Optional[float] = None, **kwargs):
        super().__init__(**kwargs)
        self.columns = columns
        self.cell_width = cell_width
        self.cell_height = cell_height
        self._last_layout_cols: int = 0

    def _effective_columns(self, available_width: float) -> int:
        if self.columns > 0:
            return self.columns
        if self.cell_width and self.cell_width > 0:
            sc = ui_scale()
            gap = self.style.gap * sc
            cw = self.cell_width * sc
            return max(1, int((available_width + gap) / (cw + gap)))
        visible = [c for c in self.children if c.visible]
        return max(1, len(visible))

    def _measure_content_width(self) -> float:
        if self.cell_width:
            sc = ui_scale()
            cols = self.columns if self.columns > 0 else len(self.children)
            return cols * self.cell_width * sc + max(0, cols - 1) * self.style.gap * sc
        return 0

    def _measure_content_height(self) -> float:
        visible = [c for c in self.children if c.visible]
        if not visible:
            return 0
        # Use cached column count from layout (accurate after first layout)
        if self._last_layout_cols > 0:
            cols = self._last_layout_cols
        elif self.columns > 0:
            cols = self.columns
        else:
            cols = len(visible)
        rows = (len(visible) + cols - 1) // cols
        sc = ui_scale()
        ch = (self.cell_height * sc) if self.cell_height else (
            visible[0].measure_height() if visible else 0)
        return rows * ch + max(0, rows - 1) * self.style.gap * sc

    def layout(self, available: Rect):
        """Two-pass layout: determine columns from width, then correct height."""
        # First pass: normal layout (determines width ? effective columns)
        super().layout(available)
        # After _layout_children, _last_layout_cols is set.
        # Re-check if height needs correction for auto-columns.
        if self.columns <= 0 and self.cell_width and self._last_layout_cols > 0:
            correct_h = self.measure_height()
            if abs(correct_h - self.rect.height) > 0.5:
                pad = self.style.padding or EdgeInsets()
                sc = ui_scale()
                self.rect = Rect(self.rect.x, self.rect.y,
                                 self.rect.width, correct_h)
                self.content_rect = self.rect.inset(
                    pad.top * sc, pad.right * sc, pad.bottom * sc, pad.left * sc)
                self._layout_children()

    def _layout_children(self):
        visible = [c for c in self.children if c.visible]
        if not visible:
            return
        cr = self.content_rect
        sc = ui_scale()
        gap = self.style.gap * sc
        cols = self._effective_columns(cr.width)
        self._last_layout_cols = cols
        cw = (self.cell_width * sc) if self.cell_width else (
            (cr.width - (cols - 1) * gap) / cols)
        ch = (self.cell_height * sc) if self.cell_height else (
            visible[0].measure_height() if visible else cw)

        for i, child in enumerate(visible):
            col = i % cols
            row = i // cols
            x = cr.x + col * (cw + gap)
            y = cr.y + row * (ch + gap)
            child.layout(Rect(x, y, cw, ch))


class Box(Widget):
    """Single-child container with background / border / padding."""

    def _measure_content_width(self) -> float:
        if self.children:
            return self.children[0].measure_width()
        return 0

    def _measure_content_height(self) -> float:
        if self.children:
            return self.children[0].measure_height()
        return 0

    def _layout_children(self):
        if self.children:
            self.children[0].layout(self.content_rect)


class Spacer(Widget):
    """Invisible flexible space � pushes siblings apart."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.style.flex == 0:
            self.style.flex = 1.0

    def draw(self, renderer):
        pass
